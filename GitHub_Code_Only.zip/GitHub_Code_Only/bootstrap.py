"""Install the source release and fetch its checksum-pinned Jumper runtime."""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import time
import urllib.request
import venv
import zipfile

ROOT=Path(__file__).resolve().parent
REPO=ROOT/'upstream/jumper'
TEMP=ROOT/'.cache/tmp';TEMP.mkdir(parents=True,exist_ok=True)
os.environ['TEMP']=str(TEMP);os.environ['TMP']=str(TEMP)
os.environ['PIP_CACHE_DIR']=str(ROOT/'.cache/pip')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def verify_assets():
    manifest=json.loads((ROOT/'assets/manifest.json').read_text('utf-8'))
    for name,value in manifest.items():
        if sha(ROOT/name)!=value:
            raise RuntimeError(f'Packaged asset checksum mismatch: {name}')


def fetch(local_source=None):
    spec=json.loads((ROOT/'assets/upstream.json').read_text('utf-8'))
    files=spec['files']
    REPO.mkdir(parents=True,exist_ok=True)
    pending=[name for name,value in files.items() if not (REPO/name).is_file() or sha(REPO/name)!=value]
    if not pending:
        print('Pinned Jumper runtime already verified.',flush=True)
        return
    if local_source:
        source=Path(local_source).resolve()
        commit=subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'],text=True).strip()
        if commit!=spec['commit']:
            raise RuntimeError('Local Jumper checkout has the wrong commit.')
        blobs=subprocess.Popen(['git','-C',str(source),'cat-file','--batch'],stdin=subprocess.PIPE,stdout=subprocess.PIPE)
        try:
            for name in pending:
                data=(source/name).read_bytes()
                if hashlib.sha256(data).hexdigest()!=files[name]:
                    blobs.stdin.write(f'{commit}:{name}\n'.encode());blobs.stdin.flush()
                    header=blobs.stdout.readline().decode().split()
                    if len(header)!=3 or header[1]!='blob':raise RuntimeError(f'Missing Git blob: {name}')
                    data=blobs.stdout.read(int(header[2]));assert blobs.stdout.read(1)==b'\n'
                if hashlib.sha256(data).hexdigest()!=files[name]:
                    raise RuntimeError(f'Local upstream checksum mismatch: {name}')
                dest=REPO/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
        finally:
            blobs.stdin.close();blobs.wait();blobs.stdout.close()
    else:
        temp=ROOT/'.cache/downloads';temp.mkdir(parents=True,exist_ok=True)
        # Temporary download is never part of the upload payload.
        with tempfile.TemporaryDirectory(dir=temp) as scratch:
            archive=Path(scratch)/'jumper.zip'
            print('Downloading the pinned upstream archive; this may take several minutes.',flush=True)
            request=urllib.request.Request(spec['archive_url'],headers={'User-Agent':'DspGPR-Crab-Reproduction'})
            total=0;last=time.monotonic()
            with urllib.request.urlopen(request,timeout=60) as response,archive.open('wb') as dest:
                while True:
                    block=response.read(1024*1024)
                    if not block:break
                    dest.write(block);total+=len(block)
                    if time.monotonic()-last>5:
                        print(f'Downloaded {total/1e6:.1f} MB',flush=True);last=time.monotonic()
            with zipfile.ZipFile(archive) as zipped:
                prefix=f"jumper-{spec['commit']}/"
                for name in pending:
                    dest=(REPO/name).resolve()
                    if not dest.is_relative_to(REPO.resolve()):
                        raise RuntimeError(f'Unsafe archive path: {name}')
                    data=zipped.read(prefix+name)
                    if hashlib.sha256(data).hexdigest()!=files[name]:
                        raise RuntimeError(f'Downloaded upstream checksum mismatch: {name}')
                    dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
    for name,value in files.items():
        if sha(REPO/name)!=value:raise RuntimeError(f'Upstream validation failed: {name}')
    print(f"Verified {len(files)} upstream files at {spec['commit'][:12]}.",flush=True)


def check():
    verify_assets()
    for name in ['mjrl','mjlab','tasks']:
        module=__import__(name)
        location=Path(module.__file__).resolve()
        if not location.is_relative_to(REPO.resolve()):
            raise RuntimeError(f'{name} imports a different checkout: {location}')
        print(f'{name}: {location}',flush=True)
    import mujoco
    import numpy as np
    import torch
    import onnxruntime
    from crab_defense.native import ClawRuntime
    runtime=ClawRuntime()
    try:print('Original controller reference passed:',runtime.reference,flush=True)
    finally:runtime.close()
    print('Versions:',sys.version.split()[0],mujoco.__version__,np.__version__,torch.__version__,onnxruntime.__version__,flush=True)


def setup(local_source=None):
    if not (3,10)<=sys.version_info[:2]<(3,14) or sys.maxsize<=2**32:
        raise RuntimeError('Use 64-bit Python 3.10-3.13; Python 3.12 is recommended.')
    verify_assets();fetch(local_source)
    environment=ROOT/'.venv';python=environment/('Scripts/python.exe' if os.name=='nt' else 'bin/python')
    if not python.is_file():venv.EnvBuilder(with_pip=True).create(environment)
    subprocess.run([str(python),'-c','import sys; print("Installing into",sys.prefix)'],check=True)
    subprocess.run([str(python),'-m','pip','install','--upgrade','pip','setuptools','wheel'],check=True)
    subprocess.run([str(python),'-m','pip','install','torch','torchvision','--index-url','https://download.pytorch.org/whl/cpu'],check=True)
    subprocess.run([str(python),'-m','pip','install','-e',str(REPO),'-r',str(ROOT/'requirements.txt')],check=True)
    subprocess.run([str(python),'-m','pip','check'],check=True)
    subprocess.run([str(python),'-B',str(Path(__file__).resolve()),'--check'],cwd=ROOT,check=True)
    print('Ready. Run generate_videos.cmd or .venv/bin/python run_videos.py',flush=True)


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--check',action='store_true');p.add_argument('--fetch-only',action='store_true');p.add_argument('--upstream-source',type=Path);a=p.parse_args()
    if a.check:check()
    elif a.fetch_only:verify_assets();fetch(a.upstream_source)
    else:setup(a.upstream_source)
