"""Resource competition with observable claw threats and contact-based defense."""
