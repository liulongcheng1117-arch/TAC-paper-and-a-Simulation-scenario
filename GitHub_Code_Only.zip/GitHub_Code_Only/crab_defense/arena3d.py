"""Run the original 3D terrain and 22-joint robots with conditional claw control."""

import argparse
import hashlib
import json
from dataclasses import asdict
from pathlib import Path
from time import perf_counter, sleep

import imageio.v2 as imageio
import mujoco
import numpy as np
from PIL import Image, ImageDraw, ImageFont
from scipy.optimize import nnls
from threadpoolctl import threadpool_limits

from .native import ClawRuntime
from .policy3d import (
    NativeConfig,
    NativePolicy,
    feature_objective,
    features,
    moments,
    plans,
)
from .world3d import ArticulatedArena, ReactivePopulation

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "outputs" / "claw_goal_3d"
METHODS = ["pose_cv", "dual_gp", "dual_dro", "phase_mpc", "full_gp"]
NAMES = {"pose_cv": "CV-MPC", "dual_gp": "双单点 GPR", "dual_dro": "双单点 GPR＋分布鲁棒", "phase_mpc": "阶段 MPC", "full_gp": "全历史 GP"}


def fingerprint():
    files = ["crab_defense/arena3d.py", "crab_defense/world3d.py", "crab_defense/policy3d.py", "crab_defense/prediction.py",
             "crab_defense/native.py", "crab_defense/contacts.py", "crab_defense/navigation3d.py", "crab_sim/multi_crab.py", "crab_interaction/arena.py"]
    return {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest() for name in files}


def advance(world, controls, cfg, callback=None):
    world.command(controls, cfg)
    for step in range(round(cfg.dt / world.control_dt)):
        if step % 20 == 0:
            world.aim_update()
        yaw = world.yaws
        body = np.c_[np.cos(yaw) * controls[:, 0] + np.sin(yaw) * controls[:, 1],
                     -np.sin(yaw) * controls[:, 0] + np.cos(yaw) * controls[:, 1], controls[:, 2]]
        world.step(body)
        if callback is not None:
            callback(world)
    return world.observe()


def picture(world, method, elapsed, benefit, goal_dwell=0.):
    world.render(1280, 720)
    camera = mujoco.MjvCamera()
    camera.lookat[:] = [0, .15, .05]
    camera.distance, camera.azimuth, camera.elevation = 4.8, 105, -40
    option = mujoco.MjvOption()
    option.geomgroup[1] = 0
    world._renderer.update_scene(world.data, camera=camera, scene_option=option)
    image = Image.fromarray(world._renderer.render())
    draw = ImageDraw.Draw(image)
    font = ImageFont.truetype("C:/Windows/Fonts/msyh.ttc", 22)
    small = ImageFont.truetype("C:/Windows/Fonts/msyh.ttc", 18)
    draw.rectangle((0, 0, 1280, 95), fill="#121d2a")
    draw.text((18, 10), f"原版三维机器人 · 原场地、原关节、真实碰撞 | {NAMES[method]} | {elapsed:.1f}s", font=font, fill="white")
    distance = np.linalg.norm(world.positions[0, :2] - [world.sides[0] * 1.6, .45])
    draw.text((18, 45), f"目标：对侧绿色区域   距中心 {distance:.2f}m   区内稳定停留 {goal_dwell:.1f}s", font=small, fill="#cde0f5")
    draw.text((18, 71), f"蓝：论文方法   得分 {benefit - world.ledger.loss[0]:.2f}   受击 {world.ledger.hit_count[0]}   被夹 {world.ledger.grasp_count[0]}", font=small, fill="#cde0f5")
    return np.asarray(image)


def calibrate(players, cfg, runtime, start):
    errors, variances = [[] for _ in range(cfg.horizon)], [[] for _ in range(cfg.horizon)]
    for seed in (51000, 51001):
        world = ArticulatedArena(seed, players, runtime, start)
        try:
            x, previous = world.warmup(), np.zeros((players, 6))
            population = ReactivePopulation(seed, world, cfg)
            policy = NativePolicy("dual_gp", players, int(world.sides[0]), cfg)
            tick, rng = 0, np.random.default_rng(seed)
            for probe in range(8):
                candidates, _ = plans(x, previous, policy.side, cfg)
                selected = candidates[int(rng.integers(len(candidates)))][None]
                forecast = policy.model.forecast(tick, x, previous, selected)
                center, variance = moments(forecast, cfg, policy.nodes, policy.goal)
                for k in range(cfg.horizon):
                    applied = population.choose(tick, x, previous)
                    applied[0] = selected[0, k]
                    successor = advance(world, applied, cfg)
                    truth = features(forecast.own[0, k], successor[1:], policy.goal)
                    errors[k].append(float(np.sum((truth - center[0, k])**2)))
                    variances[k].append(float(variance[0, k]))
                    policy.model.observe(tick, x, previous, applied, successor)
                    x, previous, tick = successor, applied, tick + 1
                print(f"3D calibration seed {seed}: {probe + 1}/8 probes", flush=True)
        finally:
            world.close()
    scale = max(float(np.max(variances)), 1e-10)
    fit = [nnls(np.c_[np.ones(len(v)), np.asarray(v) / scale], e)[0].tolist() for v, e in zip(variances, errors)]
    return {"domain": "original articulated MuJoCo", "source_sha256": fingerprint(), "players": players, "start": start,
            "config": asdict(cfg), "seeds": [51000, 51001], "samples_per_horizon": len(errors[0]),
            "variance_scale": scale, "moment_fit": fit,
            "interpretation": "independent native empirical moments; NOT a theorem confidence or safety certificate"}


def run(seed, players, method, seconds, cfg, runtime, calibration=None, record=False, live=False, start="original", stop_on_goal=False):
    world = ArticulatedArena(seed, players, runtime, start)
    base = OUT / f"native-{start}-n{players}-{seed}-{method}"
    writer = imageio.get_writer(base.with_suffix(".mp4"), fps=10, codec="libx264", quality=8) if record else None
    viewer = None
    traces, frame_states, benefit, cost, last_frame = [], [], 0., 0., -1
    source, began = fingerprint(), perf_counter()
    goal_dwell, longest_goal_dwell, first_entry, reached_at = 0., 0., None, None
    try:
        x, previous = world.warmup(), np.zeros((players, 6))
        origin = float(world.data.time)
        population = ReactivePopulation(seed, world, cfg)
        policy = NativePolicy(method, players, int(world.sides[0]), cfg, calibration)
        if live:
            import mujoco.viewer
            viewer = mujoco.viewer.launch_passive(world.model, world.data)
            viewer.cam.lookat[:], viewer.cam.distance = [0, .15, .05], 4.8
            viewer.cam.azimuth, viewer.cam.elevation = 105, -40
            viewer.opt.geomgroup[1] = 0
        started = perf_counter()

        def display(plant):
            nonlocal last_frame
            elapsed = float(plant.data.time) - origin
            frame = round(elapsed * 1000) // 100
            if writer is not None and frame != last_frame:
                writer.append_data(picture(plant, method, elapsed, benefit, goal_dwell))
                frame_states.append(plant.data.qpos.copy())
                last_frame = frame
            if viewer is not None:
                if not viewer.is_running():
                    raise InterruptedError("Viewer closed by user")
                if plant.tick % 4 == 0:
                    viewer.sync()
                sleep(max(0, started + elapsed - perf_counter()))

        for tick in range(round(seconds / cfg.dt)):
            applied = population.choose(tick, x, previous)
            applied[0], info = policy.choose(tick, x, previous)
            old_loss = world.ledger.loss[0]
            successor = advance(world, applied, cfg, display if record or live else None)
            elapsed = float(world.data.time) - origin
            goal_distance = float(np.linalg.norm(successor[0, :2] - policy.goal))
            measured_speed = float(np.linalg.norm(successor[0, :2] - x[0, :2]) / cfg.dt)
            in_goal = goal_distance <= cfg.goal_radius
            stable = (in_goal and measured_speed <= cfg.goal_speed_mps and np.rad2deg(world.tilts[0]) <= cfg.goal_tilt_deg
                      and world.positions[0, 2] >= cfg.goal_height_m and world.fsms[0].running_policy)
            if in_goal and first_entry is None:
                first_entry = elapsed
            goal_dwell = goal_dwell + cfg.dt if stable else 0.
            longest_goal_dwell = max(longest_goal_dwell, goal_dwell)
            if reached_at is None and goal_dwell + 1e-9 >= cfg.goal_dwell_s:
                reached_at = elapsed
            phi = features(successor[0], successor[1:], policy.goal)
            realized = float(feature_objective(successor[0], phi, applied[0], policy.goal)[0])
            food = np.exp(-np.sum((successor[:, :2] - policy.goal)**2, -1) / (2 * .6**2))
            benefit += float(cfg.dt * 3 * food[0] / (1 + food[1:].sum()))
            cost += cfg.dt * realized + float(world.ledger.loss[0] - old_loss)
            policy.model.observe(tick, x, previous, applied, successor)
            traces.append({"time": float(world.data.time) - origin, "state": successor.tolist(), "control": applied.tolist(),
                           "positions_xyz": world.positions.tolist(), "jaw_points_xyz": world.tips.tolist(),
                           "joints": world.data.qpos[world.q_adr].tolist(), "decision": info,
                           "benefit": benefit, "contact_loss": world.ledger.loss.tolist(), "cost": cost,
                           "goal_distance_m": goal_distance, "measured_speed_mps": measured_speed, "goal_stable_dwell_s": goal_dwell})
            x, previous = successor, applied
            if (tick + 1) % 5 == 0:
                print(f"Native 3D {method}: {(tick + 1) * cfg.dt:.1f}/{seconds:.1f}s, goal={goal_distance:.2f}m, hold={goal_dwell:.1f}s, contact loss={world.ledger.loss.round(2).tolist()}", flush=True)
            if stop_on_goal and goal_dwell + 1e-9 >= cfg.goal_dwell_s + 10:
                break
        result = {"domain": "original articulated 3D MuJoCo", "seed": seed, "players": players, "method": method, "start": start,
                  "source_sha256": source, "config": asdict(cfg), "physics": world.report(), "ledger": world.ledger.report(),
                  "cost": cost, "resource_benefit": benefit, "point_score": benefit - float(world.ledger.loss[0]),
                  "goal": {"center": policy.goal.tolist(), "visible_radius_m": .65, "arrival_radius_m": cfg.goal_radius,
                           "dwell_requirement_s": cfg.goal_dwell_s, "hold_after_arrival_s": 10.,
                           "first_entry_s": first_entry, "reached_at_s": reached_at, "longest_stable_dwell_s": longest_goal_dwell,
                           "final_stable_dwell_s": goal_dwell, "final_distance_m": goal_distance,
                           "stable_success": bool(goal_dwell + 1e-9 >= cfg.goal_dwell_s + 10)},
                  "terrain_origin": "unchanged crab_interaction.Arena rocks, resources and boundary boxes",
                  "plant": "original 22 joints / original ONNX five-foot policy / original torque-speed-thermal servo",
                  "no_proxy_contact_solver": True, "no_plant_pose_overwrite": True, "trace": traces,
                  "npc_events_for_evaluation_only": population.events, "wall_seconds": perf_counter() - began,
                  "ik_error_median_m": float(np.median(world.ik_errors)) if world.ik_errors else None,
                  "comparison_status": "engineering native integration; no statistical superiority claim"}
        assert source == fingerprint(), "Source changed while simulation was running"
        base.with_suffix(".json").write_text(json.dumps(result), "utf-8")
        if frame_states:
            np.savez_compressed(str(base) + "-render-states.npz", qpos=np.asarray(frame_states), fps=10)
        print(json.dumps({k: result[k] for k in ("domain", "method", "point_score", "cost", "wall_seconds", "goal")}), flush=True)
        return result
    finally:
        if writer is not None:
            writer.close()
        if viewer is not None:
            viewer.close()
        world.close()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--methods", nargs="+", choices=METHODS, default=["dual_dro"])
    parser.add_argument("--robots", type=int, default=4)
    parser.add_argument("--seed", type=int, default=54000)
    parser.add_argument("--seconds", type=float, default=90)
    parser.add_argument("--count", type=int, default=1)
    parser.add_argument("--stop-on-goal", action="store_true")
    parser.add_argument("--start", choices=["original", "encounter"], default="original")
    parser.add_argument("--record", action="store_true")
    parser.add_argument("--live", action="store_true")
    parser.add_argument("--calibrate", action="store_true")
    parser.add_argument("--calibrate-only", action="store_true")
    args = parser.parse_args()
    OUT.mkdir(parents=True, exist_ok=True)
    cfg, runtime = NativeConfig(), ClawRuntime()
    path = OUT / f"calibration-{args.start}-n{args.robots}.json"
    try:
        with threadpool_limits(limits=1):
            if args.calibrate or args.calibrate_only:
                path.write_text(json.dumps(calibrate(args.robots, cfg, runtime, args.start), indent=2), "utf-8")
            calibration = json.loads(path.read_text("utf-8")) if path.exists() else None
            if "dual_dro" in args.methods and (not calibration or calibration["source_sha256"] != fingerprint()):
                raise ValueError("Run --calibrate for this native scene; proxy calibration is never used")
            if not args.calibrate_only:
                for seed in range(args.seed, args.seed + args.count):
                    for method in args.methods:
                        run(seed, args.robots, method, args.seconds, cfg, runtime, calibration, args.record, args.live, args.start, args.stop_on_goal)
    finally:
        runtime.close()


if __name__ == "__main__":
    main()
