"""Contact evidence and a non-elimination score ledger.

No target pose, velocity, weld or contact mask is changed by this observer.
Single-surface contact is never classified as a grasp.
"""

from dataclasses import asdict, dataclass

import numpy as np


@dataclass(frozen=True)
class Scoring:
    hit_loss: float = 3.0
    grasp_entry_loss: float = 5.0
    held_loss_per_second: float = 2.0
    grasp_dwell_s: float = 0.12
    release_grace_s: float = 0.05
    regrasp_cooldown_s: float = 0.50
    hit_cooldown_s: float = 0.45
    minimum_grasp_force_N: float = 0.03
    minimum_hit_force_N: float = 0.5
    minimum_hit_speed_mps: float = 0.15
    maximum_jaw_span_m: float = 0.08
    maximum_grasp_slip_mps: float = 0.15
    instability_loss: float = 4.
    instability_tilt_rad: float = float(np.deg2rad(35))
    instability_height_m: float = .065
    instability_dwell_s: float = .10


@dataclass
class SurfaceContact:
    attacker: int
    target: int
    side: str
    jaw: str  # fixed / moving
    target_body: int
    point: np.ndarray
    normal_toward_target: np.ndarray
    force_N: float
    relative_speed_mps: float
    target_is_claw: bool = False


class ContactLedger:
    def __init__(self, players, cfg=None):
        self.cfg = cfg or Scoring()
        self.loss = np.zeros(players)
        self.hit_count = np.zeros(players, dtype=int)
        self.grasp_count = np.zeros(players, dtype=int)
        self.held_seconds = np.zeros(players)
        self.grips = {}
        self.last_hit = {}
        self.last_pressure = {}
        self.events = []
        self.unstable_seconds = np.zeros(players)
        self.instability_count = np.zeros(players, int)
        self.unstable = np.zeros(players, bool)

    def observe_stability(self, now, dt, tilts, heights):
        bad = (np.asarray(tilts) > self.cfg.instability_tilt_rad) | (np.asarray(heights) < self.cfg.instability_height_m)
        self.unstable_seconds = np.where(bad, self.unstable_seconds + dt, 0.)
        onset = (self.unstable_seconds >= self.cfg.instability_dwell_s) & ~self.unstable
        for target in np.flatnonzero(onset):
            self.loss[target] += self.cfg.instability_loss
            self.instability_count[target] += 1
            self.events.append({"time": now, "event": "instability", "target": int(target)})
        self.unstable = bad & (self.unstable | onset)

    def step(self, now, dt, contacts, closing):
        grouped = {}
        for c in contacts:
            if c.attacker == c.target:
                continue
            key = c.attacker, c.target, c.side
            grouped.setdefault(key, []).append(c)
        for key, cs in grouped.items():
            pressure = [c for c in cs if not c.target_is_claw and c.force_N >= self.cfg.minimum_hit_force_N]
            if pressure:
                separated = now - self.last_pressure.get(key, -1e9) > self.cfg.release_grace_s
                self.last_pressure[key] = now
                if (separated and any(c.relative_speed_mps >= self.cfg.minimum_hit_speed_mps for c in pressure)
                        and now - self.last_hit.get(key, -1e9) >= self.cfg.hit_cooldown_s):
                    self.last_hit[key] = now
                    attacker, target, _ = key
                    self.hit_count[target] += 1
                    self.loss[target] += self.cfg.hit_loss
                    self.events.append({"time": now, "event": "claw_hit", "attacker": attacker, "target": target})
        for key in set(grouped) | set(self.grips):
            attacker, target, side = key
            state = self.grips.setdefault(key, {"dwell": 0., "gap": 0., "active": False, "last_entry": -1e9})
            cs = grouped.get(key, [])
            stable_pair = False
            if closing.get((attacker, side), 0) >= 0.6:
                fixed = [c for c in cs if c.jaw == "fixed"]
                moving = [c for c in cs if c.jaw == "moving"]
                for a in fixed:
                    for b in moving:
                        stable_pair |= (a.target_body == b.target_body
                                        and min(a.force_N, b.force_N) >= self.cfg.minimum_grasp_force_N
                                        and max(a.relative_speed_mps, b.relative_speed_mps) <= self.cfg.maximum_grasp_slip_mps
                                        and np.linalg.norm(a.point - b.point) <= self.cfg.maximum_jaw_span_m
                                        and np.dot(a.normal_toward_target, b.normal_toward_target) < -0.4)
            if stable_pair:
                state["dwell"] += dt
                state["gap"] = 0.
                if (not state["active"] and state["dwell"] + 1e-10 >= self.cfg.grasp_dwell_s
                        and now - state["last_entry"] >= self.cfg.regrasp_cooldown_s):
                    state["active"] = True
                    state["last_entry"] = now
                    self.grasp_count[target] += 1
                    self.loss[target] += self.cfg.grasp_entry_loss
                    self.events.append({"time": now, "event": "grasp_established", "attacker": attacker, "target": target})
                if state["active"]:
                    self.held_seconds[target] += dt
                    self.loss[target] += dt * self.cfg.held_loss_per_second
            else:
                state["dwell"] = 0.
                state["gap"] += dt
                if state["active"] and (closing.get((attacker, side), 0) < 0.6 or state["gap"] > self.cfg.release_grace_s):
                    state["active"] = False
                    self.events.append({"time": now, "event": "grasp_released", "attacker": attacker, "target": target})

    def report(self):
        return {"rule": "resource competition; received contact losses; no elimination",
                "scoring": asdict(self.cfg), "loss": self.loss.tolist(), "hit_count": self.hit_count.tolist(),
                "grasp_count": self.grasp_count.tolist(), "held_seconds": self.held_seconds.tolist(),
                "instability_count": self.instability_count.tolist(), "events": self.events}
