"""Reduced-order claw game: shared resources, strike, parry, grasp and escape.

State x=[px,py,heading,extension,closure,guard_height]. Control is the rate of
these six coordinates. No policy type/phase/private goal is in the observation.
This is a kinematic/contact proxy, separate from the original articulated robot.
"""

from dataclasses import dataclass

import numpy as np


@dataclass
class Game:
    dt: float = 0.10
    horizon: int = 12
    steps: int = 360
    encounter: str = "foraging"
    body_radius: float = 0.13
    jaw_capture_radius: float = 0.045
    grasp_dwell: float = 0.12
    hit_loss: float = 3.
    grasp_loss: float = 5.
    held_rate: float = 2.
    limits = np.array([0.30, 0.30, 1.8, 2.4, 4., 3.])
    state_scale = np.array([0.6, 0.6, 1., 1., 1., 1.])
    food = np.array([0.70, 0.0])
    resources = np.array([[0.70, 0.0], [0.65, 0.72], [0.65, -0.72]])
    values = np.array([3., 2.4, 2.4])


def wrap(x):
    return np.arctan2(np.sin(x), np.cos(x))


def limited(u, cfg):
    u = np.clip(u, -cfg.limits, cfg.limits)
    norm = np.linalg.norm(u[..., :2], axis=-1, keepdims=True)
    u[..., :2] *= np.minimum(1, 0.30 / np.maximum(norm, 1e-12))
    return u


def transition(x, u, cfg):
    y = x + cfg.dt * u
    y[..., :2] = np.clip(y[..., :2], [-1.8 + cfg.body_radius, -1.25 + cfg.body_radius],
                         [1.8 - cfg.body_radius, 1.25 - cfg.body_radius])
    y[..., 3:] = np.clip(y[..., 3:], 0, 1)
    return y


def tips(x):
    e, c = np.clip(x[..., 3], 0, 1), np.clip(x[..., 4], 0, 1)
    r = 0.12 + 0.11 * e + 0.04 * e * c
    return x[..., :2] + r[..., None] * np.stack((np.cos(x[..., 2]), np.sin(x[..., 2])), axis=-1)


def initial(seed, players, cfg=None):
    if not 2 <= players <= 8:
        raise ValueError("Use 2..8 actors")
    rng = np.random.default_rng(np.random.SeedSequence([seed, 407]))
    x = np.zeros((players, 6))
    starts = [[-0.85, 0], [0.05, 0.32], [0.45, -0.42], [0.90, 0.50],
              [1.3, -0.40], [-0.15, -0.75], [1.25, 0.85], [-0.80, 0.85]]
    x[:, :2] = np.asarray(starts[:players]) + rng.uniform(-0.04, 0.04, (players, 2))
    x[1:, 2] = np.arctan2(-x[1:, 1], -0.6 - x[1:, 0])
    x[:, 3] = 0.08
    x[:, 5] = 0.4
    if cfg is not None and cfg.encounter == "grapple":
        x[0, :2], x[1, :2] = [.33, -.015], [.78, .015]
        x[0, 2], x[1, 2] = 0., np.pi
        x[0, 3:], x[1, 3:] = [.70, 0., .80], [.70, .35, .15]
    return x


class Population:
    def __init__(self, seed, players, cfg):
        rng = np.random.default_rng(np.random.SeedSequence([seed, 1021]))
        self.bold = rng.beta(.7, .7, players)
        self.grappler = rng.uniform(0, 1, players)
        self.feint = rng.uniform(0.15, 0.8, players)
        self.speed = rng.uniform(.17, .29, players)
        self.turn_gain = rng.uniform(1.3, 3.5, players)
        preferred = rng.integers(0, 3, players)
        self.foods = cfg.resources[preferred] + rng.uniform(-.16, .16, (players, 2))
        self.strike_at = rng.uniform(.42, .56, players)
        if cfg.encounter == "grapple":
            self.grappler[1], self.bold[1] = rng.uniform(.7, .98), rng.uniform(.65, .95)
            self.foods[1] = cfg.food + rng.uniform(-.05, .05, 2)
        self.seed, self.cfg = seed, cfg

    def controls(self, tick, x, previous, reactive=True):
        out, cfg = np.zeros_like(x), self.cfg
        rng = np.random.default_rng(np.random.SeedSequence([self.seed, tick, 221]))
        for j in range(1, len(x)):
            others = [i for i in range(len(x)) if i != j]
            distances = np.linalg.norm(x[others, :2] - x[j, :2], axis=1)
            # Visibility/public state only; no designated-method identity.
            weights = np.exp(-distances**2 / (2 * .7**2))
            resource_competition = np.exp(-np.sum((x[others, :2] - self.foods[j])**2, axis=1) / (2 * .45**2))
            target = others[int(np.argmax(weights * (.3 + resource_competition)))]
            delta = x[target, :2] - x[j, :2]
            distance = np.linalg.norm(delta)
            threatened = float(x[target, 3] * (0.4 + x[target, 4]))
            attention = 1 / (1 + np.exp(np.clip(10 * (distance - .85), -40, 40)))
            urge = self.bold[j] * attention
            movement = self.foods[j] - x[j, :2]
            movement /= max(np.linalg.norm(movement), .15)
            if reactive:
                chase = delta / max(distance, .08)
                retreat = np.clip((threatened - .45) * (1 - self.bold[j]) * 2, 0, 1)
                movement = (1 - urge) * movement + urge * chase - retreat * chase
            out[j, :2] = movement * self.speed[j]
            target_heading = np.arctan2(delta[1], delta[0])
            out[j, 2] = self.turn_gain[j] * wrap(target_heading - x[j, 2]) if reactive else 0.
            contest = np.exp(-np.sum((x[target, :2] - self.foods[j])**2) / (2 * .45**2))
            active = reactive and distance < 0.95 and self.bold[j] > .20 and (contest > .25 or threatened > .8)
            direction = 1 if previous[j, 3] >= 0 else -1
            if x[j, 3] > .93:
                direction = -1
            if x[j, 3] < .12:
                direction = 1
            # Feints are conditional on observable defense; repeated current
            # joint velocity is insufficient to decide whether it will finish.
            if active and x[j, 3] > self.feint[j] and x[target, 5] * x[target, 3] > .45:
                direction = -1
            rate = .8 if x[j, 3] < .34 else .12 if x[j, 3] < self.strike_at[j] else 2.3
            out[j, 3] = (rate if direction > 0 else -1.5) if active else -.8 * x[j, 3]
            if active and direction > 0:
                # Slow visible windup, then a lunge: CV of both body and claw
                # cannot infer this acceleration from the current rate alone.
                out[j, :2] *= .25 if x[j, 3] < self.strike_at[j] else 1.0
            desired_close = float(active and x[j, 3] > .55 and distance < .62 and self.grappler[j] > .3)
            out[j, 4] = 4 * (desired_close - x[j, 4])
            tip_gap = np.linalg.norm(tips(x[j]) - tips(x[target]))
            if active and self.grappler[j] > .3 and x[j, 3] > .55 and tip_gap < .12:
                # Aim, slow and squeeze rather than charging through the hand.
                out[j, :2] *= .15
                heading = np.array([np.cos(x[j, 2]), np.sin(x[j, 2])])
                reach = np.dot(tips(x[target]) - x[j, :2], heading)
                target_e = np.clip((reach - .12) / (.11 + .04 * x[j, 4]), .12, .95)
                out[j, 3] = np.clip((target_e - x[j, 3]) / cfg.dt, -1, 1)
                out[j, 4] = 4 * (1 - x[j, 4])
            desired_guard = .95 if threatened > .7 and self.bold[j] < .65 else .15
            out[j, 5] = 3 * (desired_guard - x[j, 5])
            out[j, :2] += rng.uniform(-.008, .008, 2)
            # Shared local body separation; aggression concerns claws, not
            # deliberately overlapping body roots in this reduced model.
            for i, d in zip(others, distances):
                out[j, :2] += .15 * (x[j, :2] - x[i, :2]) / max(d, .01) * np.exp(-(d / .25)**2)
        return limited(out, cfg)


class ContactProxy:
    """Documented reduced-order grasp/contact state; not rigid-body evidence.

Capture needs closing jaws, a near hand/appendage, low relative motion and dwell.
No positions are teleported or welded. A held actor's effective travel is
limited by a reduced friction model; lateral/withdrawal movement can release it.
    """
    def __init__(self, players, cfg):
        self.cfg = cfg
        self.loss = np.zeros(players)
        self.hits = np.zeros(players, int)
        self.blocks = np.zeros(players, int)
        self.grasps = np.zeros(players, int)
        self.held_seconds = np.zeros(players)
        self.last_hit = np.full((players, players), -1e6)
        self.dwell = np.zeros((players, players))
        self.held = np.zeros((players, players), bool)
        self.events = []

    def affect(self, x, controls):
        result = controls.copy()
        for attacker, target in zip(*np.where(self.held)):
            away = x[target, :2] - x[attacker, :2]
            away /= max(np.linalg.norm(away), .01)
            lateral = result[target, :2] - away * np.dot(result[target, :2], away)
            # Forceful lateral withdrawal/turning breaks the reduced capture.
            if np.linalg.norm(lateral) > .19 or abs(result[target, 2]) > 1.2:
                self.held[attacker, target] = False
                self.dwell[attacker, target] = 0
            else:
                result[target, :2] *= .30
        # A reduced contact solver projects velocities, never teleports roots.
        # This prevents passing through another body's center while claws act.
        for _ in range(6):
            for a in range(len(x)):
                for b in range(a + 1, len(x)):
                    delta = x[b, :2] - x[a, :2]
                    distance = np.linalg.norm(delta)
                    normal = delta / max(distance, 1e-8)
                    relative = np.dot(result[b, :2] - result[a, :2], normal)
                    minimum = (2 * self.cfg.body_radius - distance) / self.cfg.dt
                    if relative < minimum:
                        correction = (minimum - relative) / 2
                        result[a, :2] -= correction * normal
                        result[b, :2] += correction * normal
            result = limited(result, self.cfg)
        return result

    def update(self, tick, before, after, controls):
        cfg, n = self.cfg, len(after)
        tip0, tip1 = tips(before), tips(after)
        for a in range(n):
            for b in range(n):
                if a == b:
                    continue
                segment = tip1[a] - tip0[a]
                denominator = max(np.dot(segment, segment), 1e-12)
                t_body = np.clip(np.dot(after[b, :2] - tip0[a], segment) / denominator, 0, 1)
                t_guard = np.clip(np.dot(tip1[b] - tip0[a], segment) / denominator, 0, 1)
                body_d = np.linalg.norm(tip0[a] + t_body * segment - after[b, :2])
                guard_d = np.linalg.norm(tip0[a] + t_guard * segment - tip1[b])
                moving = np.linalg.norm(segment) / cfg.dt > .16
                extended = max(before[a, 3], after[a, 3]) > .45
                shielded = (after[b, 5] > .6 and after[b, 3] > .6 and guard_d < .08 and t_guard <= t_body)
                if extended and moving and body_d < cfg.body_radius and tick - self.last_hit[a, b] > 5:
                    self.last_hit[a, b] = tick
                    if shielded:
                        self.blocks[b] += 1
                        self.events.append({"tick": tick, "event": "parry", "attacker": a, "target": b})
                    else:
                        self.hits[b] += 1
                        self.loss[b] += cfg.hit_loss
                        self.events.append({"tick": tick, "event": "hit", "attacker": a, "target": b})
                # Pinch the observed opponent hand, not an arbitrary body-radius
                # overlap. Closure during extension opens a narrow capture window.
                hand_gap = np.linalg.norm(tip1[a] - tip1[b])
                closing = after[a, 4] > .45 and controls[a, 4] >= -.1
                measured = (after[:, :2] - before[:, :2]) / cfg.dt
                slow = np.linalg.norm(measured[a] - measured[b]) < .22
                capture = extended and closing and hand_gap < cfg.jaw_capture_radius and slow
                if capture:
                    self.dwell[a, b] += cfg.dt
                    if self.dwell[a, b] >= cfg.grasp_dwell and not self.held[a, b]:
                        self.held[a, b] = True
                        self.grasps[b] += 1
                        self.loss[b] += cfg.grasp_loss
                        self.events.append({"tick": tick, "event": "grasp", "attacker": a, "target": b})
                elif not self.held[a, b]:
                    self.dwell[a, b] = 0
                if self.held[a, b]:
                    if after[a, 4] < .25 or hand_gap > .16:
                        self.held[a, b] = False
                        self.dwell[a, b] = 0
                    else:
                        self.held_seconds[b] += cfg.dt
                        self.loss[b] += cfg.held_rate * cfg.dt


def interaction_features(own, others, cfg):
    p, peer = own[..., :2], others[..., :2]
    food = np.exp(-np.sum((peer[..., None, :] - cfg.resources)**2, axis=-1) / (2 * .34**2))
    body = np.exp(-np.sum((p[..., None, :] - peer)**2, axis=-1) / (2 * .18**2))
    attack_tip = tips(others)
    active = np.clip(others[..., 3], 0, 1)
    close = np.clip(others[..., 4], 0, 1)
    shield = tips(own)
    near_body = np.exp(-np.sum((p[..., None, :] - attack_tip)**2, axis=-1) / (2 * .16**2))
    near_shield = np.exp(-np.sum((shield[..., None, :] - attack_tip)**2, axis=-1) / (2 * .10**2))
    guard = np.clip(own[..., 3] * own[..., 5], 0, 1)
    strike = active * near_body * (1 - .85 * guard[..., None] * near_shield)
    grasp = active * close * near_shield
    return np.concatenate((food, body[..., None], strike[..., None], grasp[..., None]), axis=-1)


def feature_cost(own, features, controls, cfg):
    """Affine tangent majorizer and coefficient norm in feature coordinates.

The sharing loss -a/(1+B) is concave in B>=0. Its tangent at predicted mean
occupancy is a global upper bound, with slope a/(1+Bmean)^2. Physical costs and
CV predictions at a point are unchanged. Feature-space W1 is a declared new
transport metric, not an undocumented scaling of the original state radius.
    """
    p = own[..., :2]
    own_food = np.exp(-np.sum((p[..., None, :] - cfg.resources)**2, axis=-1) / (2 * .34**2))
    other_food = features[..., :3].sum(-2)
    effort = .15 * np.sum(controls[..., :2]**2, axis=-1) + .025 * np.sum(controls[..., 2:]**2, axis=-1)
    stance = .10 * own[..., 3]**2 + .05 * own[..., 4]**2
    risk = np.sum(features[..., 3:] * np.array([2., 3., 3.]), axis=(-1, -2))
    slopes = cfg.values * own_food / (1 + other_food)**2
    lipschitz = np.sqrt(features.shape[-2] * (np.sum(slopes**2, axis=-1) + 22))
    return .12 + effort + stance + risk - np.sum(cfg.values * own_food / (1 + other_food), axis=-1), lipschitz


def stage_cost(own, others, controls, cfg):
    return feature_cost(own, interaction_features(own, others, cfg), controls, cfg)[0]


def uniform_lipschitz(players, cfg):
    """Valid global bound in normalized opponent coordinates, no risk multiplier.

Clipped activation/closure are 1-Lipschitz. Tip Jacobian norm bounded by
sqrt(.6²+.27²+.15²+.04²); Gaussian spatial derivative <=exp(-1/2)/width.
Product gradients bounded using all factors in [0,1].
    """
    c = np.sqrt(.6**2 + .27**2 + .15**2 + .04**2)
    g = np.exp(-.5)
    sharing = cfg.values.sum() * g / .34 * .6
    body = 2 * g / .18 * .6
    strike = 3 * (1 + c * g * (1 / .16 + .85 / .10))
    grasp = 3 * (2 + c * g / .10)
    return np.sqrt(players - 1) * (sharing + body + strike + grasp)
