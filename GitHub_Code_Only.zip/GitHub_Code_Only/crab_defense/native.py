"""Consume the unmodified original claw FSM/operator and torque dynamics."""

import argparse
import json
from pathlib import Path

import imageio.v2 as imageio
import mujoco
import numpy as np

from crab_sim.multi_crab import BundleRuntime, CrabConfig, MultiCrabWorld

from .contacts import ContactLedger, SurfaceContact

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "outputs" / "claw_defense"


class OperatorBridge:
    """Physical twist -> original raw pad, original mode bindings, no new keys."""
    def __init__(self, fsm, layouts):
        self.fsm, self.layouts = fsm, layouts
        self.request = {"side": "none", "preset": "stow", "close": 0.}
        self.last_mode = "locomotion"

    def __getattr__(self, name):
        return getattr(self.fsm, name)

    def set_command(self, vx, vy, yaw, now_us):
        desired = "claw_" + self.request["side"] if self.request["side"] != "none" else "locomotion"
        buttons = []
        if desired != self.last_mode:
            entering = desired if desired != "locomotion" else self.last_mode
            buttons = ["LB" if entering == "claw_left" else "RB"]
            self.last_mode = desired
        mode = self.fsm.mode if self.fsm.mode in self.layouts else "locomotion"
        ranges = self.layouts[mode]["command_ranges"]["twist"]
        def axis(value, key):
            bounds = ranges[key]
            return float(np.clip(value / (bounds[1] if value >= 0 else -bounds[0]), -1, 1))
        x, y, z = axis(vx, "lin_vel_x"), axis(vy, "lin_vel_y"), axis(yaw, "ang_vel_z")
        # Original split Rx: yaw in the second half, twist returned to zero.
        rx = -np.sign(z) * (0.5 + 0.5 * abs(z)) if abs(z) > 1e-8 else 0.
        active = mode in ("claw_left", "claw_right")
        preset = self.request["preset"] if active else "stow"
        dy = 1 if preset == "up" else -1 if preset == "down" else 0
        dx = -1 if preset == "web" else 0
        amount = float(self.request["close"]) if active else 0.
        self.fsm.set_pad_frame(buttons, {"Ly": -x, "Lx": -y, "Rx": float(rx),
                                       "LT": amount if desired == "claw_left" else 0.,
                                       "RT": amount if desired == "claw_right" else 0.},
                               dpad_x=dx, dpad_y=dy, connected=True, now_us=now_us)


class ClawRuntime(BundleRuntime):
    def new_fsm(self):
        limits = self.layout["joint_limits"]
        fsm = self.module.Fsm((self.root / self.manifest["fsm"]).read_text("utf-8"), self.contracts,
                              {"joint_names": self.wire, "joint_pos_lo": [limits[n][0] for n in self.wire],
                               "joint_pos_hi": [limits[n][1] for n in self.wire], "output_rate_hz": self.control_hz},
                              trajectories=self.trajectories, operators=True)
        return OperatorBridge(fsm, self.layouts)


class ClawWorld(MultiCrabWorld):
    def __init__(self, configs, **kwargs):
        super().__init__(configs, **kwargs)
        self.ledger = ContactLedger(len(configs))
        self.contact_diagnostics = {"jaw_contact_substeps": {"fixed": 0, "moving": 0}, "opposed_pair_substeps": 0,
                                    "maximum_grasp_dwell_s": 0.}
        self.surfaces = {}
        for g in range(self.model.ngeom):
            name = self.model.geom(g).name
            if not self.model.geom_contype[g] or self.geom_owner[g] < 0:
                continue
            for side, prefix in (("left", "LF_"), ("right", "RF_")):
                if prefix + "finger" in name:
                    self.surfaces[g] = (side, "moving")
                elif prefix + "palm" in name:
                    self.surfaces[g] = (side, "fixed")
        self.tip_bodies = [[self.model.body(cfg.name + "/" + p + "finger_tip_link").id
                            for p in ("LF_", "RF_")] for cfg in configs]

    def primitives(self, commands):
        for fsm, command in zip(self.fsms, commands):
            fsm.request = dict(command)

    @property
    def tips(self):
        return self.data.xpos[np.asarray(self.tip_bodies)].copy()

    def _record_cross_contacts(self):
        super()._record_cross_contacts()
        if not hasattr(self, "ledger"):
            return
        observations, force = [], np.zeros(6)
        for index, contact in enumerate(self.data.contact):
            for first, second, sign in ((int(contact.geom1), int(contact.geom2), 1),
                                        (int(contact.geom2), int(contact.geom1), -1)):
                attacker, target = self.geom_owner[first], self.geom_owner[second]
                if first not in self.surfaces or target < 0 or attacker == target:
                    continue
                source = self.fsms[attacker]
                side, jaw = self.surfaces[first]
                if source.mode != "claw_" + side or not source.running_policy:
                    continue
                if source.request["preset"] == "stow" and source.request["close"] < 0.6:
                    continue
                mujoco.mj_contactForce(self.model, self.data, index, force)
                a, b = int(self.model.geom_bodyid[first]), int(self.model.geom_bodyid[second])
                va, vb = np.zeros(6), np.zeros(6)
                mujoco.mj_objectVelocity(self.model, self.data, mujoco.mjtObj.mjOBJ_BODY, a, va, 0)
                mujoco.mj_objectVelocity(self.model, self.data, mujoco.mjtObj.mjOBJ_BODY, b, vb, 0)
                va_point = va[3:] + np.cross(va[:3], contact.pos - self.data.xpos[a])
                vb_point = vb[3:] + np.cross(vb[:3], contact.pos - self.data.xpos[b])
                self.contact_diagnostics["jaw_contact_substeps"][jaw] += 1
                observations.append(SurfaceContact(int(attacker), int(target), side, jaw, int(self.model.body_weldid[b]),
                                                   contact.pos.copy(), sign * contact.frame[:3].copy(),
                                                   float(np.linalg.norm(force[:3])), float(np.linalg.norm(va_point - vb_point)),
                                                   second in self.surfaces))
        closing = {(i, fsm.request["side"]): fsm.request["close"] for i, fsm in enumerate(self.fsms)}
        self.ledger.step(float(self.data.time), self.model.opt.timestep, observations, closing)
        self.ledger.observe_stability(float(self.data.time), self.model.opt.timestep, self.tilts, self.positions[:, 2])
        self.contact_diagnostics["maximum_grasp_dwell_s"] = max(self.contact_diagnostics["maximum_grasp_dwell_s"],
            max((s["dwell"] for s in self.ledger.grips.values()), default=0.))
        for key in {(c.attacker, c.target, c.side, c.target_body) for c in observations}:
            group = [c for c in observations if (c.attacker, c.target, c.side, c.target_body) == key]
            if any(a.jaw != b.jaw and np.dot(a.normal_toward_target, b.normal_toward_target) < -.4 for a in group for b in group):
                self.contact_diagnostics["opposed_pair_substeps"] += 1


def primitive_probe():
    OUT.mkdir(parents=True, exist_ok=True)
    runtime = ClawRuntime()
    world = ClawWorld([CrabConfig("probe", (0, 0), (0.1, 0.45, 0.95))], runtime=runtime)
    stages = [("stand", "none", "stow", 0), ("left_stow", "left", "stow", 0),
              ("thumb_up", "left", "up", 0), ("web_up", "left", "web", 0),
              ("thumb_down", "left", "down", 0), ("close", "left", "down", 1),
              ("release", "left", "down", 0), ("right_stow", "right", "stow", 0),
              ("right_extend", "right", "web", 0)]
    rows = []
    writer = imageio.get_writer(OUT / "original_claw_primitives.mp4", fps=10, codec="libx264", quality=8)
    try:
        for label, side, preset, close in stages:
            world.primitives([{"side": side, "preset": preset, "close": close}])
            samples = []
            for k in range(600):
                world.step(np.zeros((1, 3)))
                if k % 20 == 0:
                    from PIL import Image, ImageDraw
                    frame = Image.fromarray(world.render(800, 600))
                    ImageDraw.Draw(frame).text((14, 14), f"Original FSM | {label} | mode={world.fsms[0].mode}", fill="white")
                    writer.append_data(np.asarray(frame))
                if k % 10 == 0:
                    samples.append({"time": float(world.data.time), "tips": world.tips[0].tolist(),
                                    "base": world.positions[0].tolist(), "joints": world.data.qpos[world.q_adr[0]].tolist(),
                                    "mode": world.fsms[0].mode, "running": world.fsms[0].running_policy})
            row = {"stage": label, "side": side, "preset": preset, "close": close, "samples": samples}
            rows.append(row)
            print(label, "mode", samples[-1]["mode"], "running", samples[-1]["running"], "tips", samples[-1]["tips"], flush=True)
        report = {"domain": "original 22-joint physics; unmodified bundle and original controls",
                  "stages": rows, "physics": world.report(), "contacts": world.ledger.report()}
        (OUT / "primitive_probe.json").write_text(json.dumps(report), "utf-8")
        return report
    finally:
        writer.close()
        world.close()
        runtime.close()


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--probe", action="store_true")
    parser.parse_args()
    primitive_probe()
