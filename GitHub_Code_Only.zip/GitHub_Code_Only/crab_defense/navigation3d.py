"""Map guidance for the ORIGINAL 3D plant; this is not a simulation engine.

An inflated public map gives a geodesic cost-to-go and feasible reference paths.
The robot still moves exclusively through the original leg policy and MuJoCo.
"""

import heapq

import numpy as np
from scipy.ndimage import distance_transform_edt, map_coordinates

from crab_interaction.arena import Arena, bounded


class GoalNavigation:
    def __init__(self, side, resolution=.05, clearance=.26):
        self.side, self.resolution, self.clearance = side, resolution, clearance
        self.goal = np.array([side * 1.6, .45])
        self.lo, self.hi = np.array([-1.95, -1.45]), np.array([1.95, 1.85])
        self.shape = np.round((self.hi - self.lo) / resolution).astype(int) + 1
        ix, iy = np.meshgrid(np.arange(self.shape[0]), np.arange(self.shape[1]), indexing="ij")
        self.points = self.lo + resolution * np.stack((ix, iy), -1)
        self.free = Arena().clearance(self.points) >= clearance
        self.moves = [(a, b) for a in (-1, 0, 1) for b in (-1, 0, 1) if a or b]
        self.cache = {}
        self.filled = {}
        self.goal_field = self.field(self.goal)
        self.north_phase = 0

    def cell(self, p):
        return np.clip(np.round((p - self.lo) / self.resolution).astype(int), 0, self.shape - 1)

    def field(self, target):
        key = tuple(np.round(target, 3))
        if key in self.cache:
            return self.cache[key]
        root = tuple(self.cell(np.asarray(target)))
        if not self.free[root]:
            distance = np.linalg.norm(self.points - target, axis=-1)
            root = np.unravel_index(np.where(self.free, distance, np.inf).argmin(), distance.shape)
        distance = np.full(tuple(self.shape), np.inf)
        distance[root] = 0.
        heap = [(0., *root)]
        while heap:
            cost, i, j = heapq.heappop(heap)
            if cost > distance[i, j] + 1e-12:
                continue
            for di, dj in self.moves:
                a, b = i + di, j + dj
                if not (0 <= a < self.shape[0] and 0 <= b < self.shape[1] and self.free[a, b]):
                    continue
                if di and dj and (not self.free[i + di, j] or not self.free[i, j + dj]):
                    continue
                updated = cost + self.resolution * np.hypot(di, dj)
                if updated < distance[a, b] - 1e-12:
                    distance[a, b] = updated
                    heapq.heappush(heap, (updated, a, b))
        self.cache[key] = distance
        return distance

    def distance(self, p):
        return self.distance_to(p, self.goal)

    def distance_to(self, p, target):
        p = np.asarray(p)
        coordinates = np.moveaxis((p - self.lo) / self.resolution, -1, 0)
        key = tuple(np.round(target, 3))
        if key not in self.filled:
            field = self.field(target)
            missing = ~np.isfinite(field)
            distance, nearest = distance_transform_edt(missing, return_indices=True)
            self.filled[key] = field[tuple(nearest)] + self.resolution * distance
        field = self.filled[key]
        return map_coordinates(field, coordinates.reshape(2, -1), order=1, mode="nearest").reshape(p.shape[:-1])

    def path(self, start, target):
        field = self.field(target)
        cell = self.cell(start)
        if not self.free[tuple(cell)]:
            d = np.linalg.norm(self.points - start, axis=-1)
            cell = np.array(np.unravel_index(np.where(self.free, d, np.inf).argmin(), d.shape))
        path = [np.asarray(start), self.points[tuple(cell)]]
        for _ in range(int(np.prod(self.shape))):
            i, j = cell
            if field[i, j] < self.resolution / 2:
                break
            options = []
            for di, dj in self.moves:
                a, b = i + di, j + dj
                if not (0 <= a < self.shape[0] and 0 <= b < self.shape[1] and self.free[a, b]):
                    continue
                if di and dj and (not self.free[i + di, j] or not self.free[i, j + dj]):
                    continue
                options.append((field[a, b], a, b))
            if not options:
                raise ValueError("No feasible map path from current state")
            _, a, b = min(options)
            if field[a, b] >= field[i, j] - 1e-10:
                raise ValueError("Map path cannot make progress")
            cell = np.array([a, b])
            path.append(self.points[a, b])
        path.append(np.asarray(target))
        return np.asarray(path)

    def north_target(self, p):
        gates = [np.array([-self.side * .98, 1.55]), np.array([self.side * .98, 1.55]), self.goal]
        if self.side * p[0] > .98:
            self.north_phase = 2
        # Geometric progress is retained across replanning, avoiding the old
        # condition that sent a partially crossed robot back to its first gate.
        if self.north_phase == 0 and (np.linalg.norm(p - gates[0]) < .22 or (p[1] > 1.3 and self.side * p[0] > -.9)):
            self.north_phase = 1
        if self.north_phase == 1 and (np.linalg.norm(p - gates[1]) < .22 or self.side * p[0] > .98):
            self.north_phase = 2
        return gates[self.north_phase]

    @staticmethod
    def follow(position, path, maximum=.18):
        position = np.asarray(position)
        delta = path[1:] - path[:-1]
        denom = np.sum(delta**2, -1)
        fraction = np.clip(np.sum((position[..., None, :] - path[:-1]) * delta, -1) / np.maximum(denom, 1e-12), 0, 1)
        projected = path[:-1] + fraction[..., None] * delta
        nearest = np.sum((position[..., None, :] - projected)**2, -1).argmin(-1)
        index = np.minimum(nearest + 3, len(path) - 1)
        target = path[index]
        return bounded((target - position) / .5, maximum)

    def xy_plans(self, p, previous, cfg, force_north=False):
        direct = self.path(p, self.goal)
        north = self.path(p, self.north_target(p))
        paths = {"direct": direct, "north": north}
        targets = {"direct": self.goal, "north": self.north_target(p)}
        for route, offset in (("north_high", .18), ("north_low", -.18)):
            targets[route] = self.north_target(p) + [0., offset]
            paths[route] = self.path(p, targets[route])
        for route, offset in (("flank_up", [.10 * self.side, .22]), ("flank_down", [.10 * self.side, -.22])):
            targets[route] = self.goal + offset
            paths[route] = self.path(p, targets[route])
        labels = [("direct", 0), ("direct", 3), ("north", 0), ("north", 3), ("north_high", 0), ("north_low", 0), ("flank_up", 0), ("flank_down", 0), ("hold", cfg.horizon), ("retreat", 3)]
        result = []
        for route, wait in labels:
            state, velocity = np.asarray(p).copy(), np.asarray(previous).copy()
            controls = []
            for k in range(cfg.horizon):
                if route == "hold" or k < wait and route != "retreat":
                    desired = np.zeros(2)
                elif route == "retreat" and k < wait:
                    desired = bounded(np.array([-self.side * .20, -.0]), .12)
                else:
                    reference = paths[route if route in paths else "direct"]
                    desired = self.follow(state, reference)
                    target = targets[route if route in targets else "direct"]
                    if not route.startswith("north") and np.linalg.norm(state - target) < .22:
                        desired = bounded(1.2 * (target - state), .12)
                velocity += bounded(desired - velocity, .09)
                state = state + cfg.dt * velocity
                controls.append(velocity.copy())
            result.append(controls)
        allowed = np.array([not force_north or route.startswith("north") or route in ("hold", "retreat") for route, _ in labels])
        return np.asarray(result)[allowed], [label for label, use in zip(labels, allowed) if use]

    def feasible(self, own, initial):
        before = np.concatenate((np.broadcast_to(initial, own[:, :1, :2].shape), own[:, :-1, :2]), axis=1)
        segment = before[:, :, None] + np.linspace(0, 1, 5)[None, None, :, None] * (own[..., :2] - before)[:, :, None]
        clearance = Arena().clearance(segment).min(axis=(1, 2))
        current = float(Arena().clearance(initial))
        # If contact tracking has encroached on the margin, allow recovery.
        threshold = min(self.clearance - .035, current - .005)
        return clearance >= threshold
