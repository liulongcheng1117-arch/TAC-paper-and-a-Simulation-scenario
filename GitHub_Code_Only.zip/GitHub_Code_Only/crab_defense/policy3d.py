"""High-level conditional learning; the plant is the original articulated world.

Euler propagation below is only the MPC's internal prediction model. Successors
used for learning and scores come exclusively from MuJoCo, never this function.
"""

from dataclasses import dataclass
from time import perf_counter

import numpy as np
from scipy.special import ndtri
from scipy.stats import qmc

from crab_interaction.arena import Arena

from .navigation3d import GoalNavigation
from .prediction import DualPoseGP, PoseCV


@dataclass
class NativeConfig:
    dt: float = .4
    horizon: int = 8
    goal_radius: float = .40
    goal_dwell_s: float = 5.
    goal_speed_mps: float = .10
    goal_tilt_deg: float = 15.
    goal_height_m: float = .08
    limits = np.array([.18, .18, .65, 1., .7, 1.])
    state_scale = np.array([.6, .6, 1., 1., 1., 1.])
    postures = np.array([[.35, 0., .35], [.90, .65, .45], [.92, 1., .35], [.85, 0., .95]])


def wrap(x):
    return np.arctan2(np.sin(x), np.cos(x))


def predict_step(x, u, cfg):
    y = x + cfg.dt * u
    y[..., 3:] = np.clip(y[..., 3:], 0, 1)
    return y


def hand_point(x):
    e, c, h = np.moveaxis(np.clip(x[..., 3:], 0, 1), -1, 0)
    r = .12 + .11 * e + .04 * e * c
    xy = x[..., :2] + r[..., None] * np.stack((np.cos(x[..., 2]), np.sin(x[..., 2])), -1)
    return np.concatenate((xy, (.04 + .14 * h)[..., None]), -1)


def features(own, others, goal):
    food = np.exp(-np.sum((others[..., :2] - goal)**2, -1) / (2 * .6**2))
    body = np.exp(-np.sum((own[..., None, :2] - others[..., :2])**2, -1) / (2 * .24**2))
    other_hand, own_hand = hand_point(others), hand_point(own)
    torso = np.concatenate((own[..., :2], np.full(own.shape[:-1] + (1,), .10)), -1)
    near_torso = np.exp(-np.sum((other_hand - torso[..., None, :])**2, -1) / (2 * .12**2))
    near_hand = np.exp(-np.sum((other_hand - own_hand[..., None, :])**2, -1) / (2 * .085**2))
    e, close = np.clip(others[..., 3], 0, 1), np.clip(others[..., 4], 0, 1)
    guard_height = np.exp(-((own_hand[..., 2] - .10) / .055)**2)
    guard = np.clip(own[..., 3], 0, 1) * guard_height
    strike = e * near_torso * (1 - .85 * guard[..., None] * near_hand)
    grasp = e * close * near_hand
    return np.stack((food, body, strike, grasp), -1)


def feature_objective(own, phi, u, goal):
    a = 3 * np.exp(-np.sum((own[..., :2] - goal)**2, -1) / (2 * .6**2))
    occupied = phi[..., 0].sum(-1)
    slope = a / (1 + occupied)**2
    base = .08 + .15 * np.sum(u[..., :2]**2, -1) + .025 * np.sum(u[..., 2:]**2, -1)
    risk = np.sum(phi[..., 1:] * [12., 3., 3.], axis=(-1, -2))
    lipschitz = np.sqrt(phi.shape[-2] * (slope**2 + 162))
    return base + risk - a / (1 + occupied), lipschitz


def moments(pred, cfg, nodes, goal):
    if np.any(pred.variance):
        samples = pred.others[:, :, None] + np.sqrt(pred.variance)[:, :, None] * cfg.state_scale * nodes[None, None]
        values = features(pred.own[:, :, None], samples, goal)
        return values.mean(2), values.var(2).sum(axis=(-1, -2))
    value = features(pred.own, pred.others, goal)
    return value, np.zeros(value.shape[:2])


def plans(x, previous, side, cfg, continuation=None, navigation=None, force_north=False, goal_hold=False):
    navigation = navigation or GoalNavigation(side)
    xy, route_labels = navigation.xy_plans(x[0, :2], previous[0, :2], cfg, force_north)
    xy = np.clip(xy, -cfg.limits[:2], cfg.limits[:2])
    if goal_hold:
        xy *= np.minimum(1, .06 / np.maximum(np.linalg.norm(xy, axis=-1, keepdims=True), 1e-12))
    output = np.zeros((len(xy) * 4, cfg.horizon, 6))
    output[..., :2] = np.repeat(xy, 4, axis=0)
    target = np.tile(cfg.postures, (len(xy), 1))
    labels = [(str(r), int(wait), 0, posture) for r, wait in route_labels for posture in range(4)]
    state = np.broadcast_to(x[0], (len(output), 6)).copy()
    nearest = 1 + np.argmin(np.linalg.norm(x[1:, :2] - x[0, :2], axis=1))
    for k in range(cfg.horizon):
        bearing = np.arctan2(x[nearest, 1] - state[:, 1], x[nearest, 0] - state[:, 0])
        output[:, k, 2] = np.clip(2 * wrap(bearing - state[:, 2]), -.65, .65)
        output[:, k, 3:] = np.clip((target - state[:, 3:]) / cfg.dt, -cfg.limits[3:], cfg.limits[3:])
        state = predict_step(state, output[:, k], cfg)
    if continuation is not None and not force_north:
        shifted = np.r_[continuation[1:], continuation[-1:]].copy()
        if goal_hold:
            shifted[:, :2] *= np.minimum(1, .06 / np.maximum(np.linalg.norm(shifted[:, :2], axis=-1, keepdims=True), 1e-12))
        output = np.concatenate((output, shifted[None]))
        labels.append(("continuation", 0, -1, -1))
    return output, labels


class NativePolicy:
    def __init__(self, method, players, side, cfg, calibration=None):
        self.method, self.cfg, self.side, self.calibration = method, cfg, side, calibration
        self.goal = np.array([side * 1.6, .45])
        self.continuation = None
        self.navigation = GoalNavigation(side)
        self.progress = []
        self.north_committed = False
        self.last_route = "direct"
        self.goal_hold = False
        if method in ("pose_cv", "phase_mpc"):
            self.model = PoseCV(players, cfg, phase=method == "phase_mpc", transition_fn=predict_step)
        else:
            if method == "dual_dro" and (not calibration or calibration.get("domain") != "original articulated MuJoCo"):
                raise ValueError("Native DRO requires independently recorded native calibration")
            self.model = DualPoseGP(players, cfg, full=method == "full_gp", transition_fn=predict_step)
        self.nodes = ndtri(qmc.Sobol(d=6 * (players - 1), scramble=True, seed=773).random_base2(4)).reshape(16, players - 1, 6)

    def choose(self, tick, x, previous):
        start = perf_counter()
        remaining = float(self.navigation.distance(x[0, :2]))
        radial_distance = np.linalg.norm(x[0, :2] - self.goal)
        if radial_distance < .34:
            self.goal_hold = True
        elif radial_distance > .44:
            self.goal_hold = False
        self.progress.append(remaining)
        self.navigation.north_target(x[0, :2])
        if not self.north_committed and self.navigation.north_phase < 2 and len(self.progress) > 25 and remaining > .4 and min(self.progress[-10:]) > min(self.progress[-25:-10]) - .08:
            self.north_committed = True
        force_north = self.north_committed and self.navigation.north_phase < 2
        actions, labels = plans(x, previous, self.side, self.cfg, self.continuation, self.navigation, force_north, self.goal_hold)
        pred = self.model.forecast(tick, x, previous, actions)
        phi, variance = moments(pred, self.cfg, self.nodes, self.goal)
        expected, lipschitz = feature_objective(pred.own, phi, actions, self.goal)
        penalty = np.zeros_like(expected)
        if self.method == "dual_dro":
            fit = np.asarray(self.calibration["moment_fit"])
            mean_error = np.max(fit[:, 0, None, None] + fit[:, 1, None, None] * variance[None] / self.calibration["variance_scale"], axis=0)
            pred.radius = np.where(pred.reused, pred.radius, np.sqrt(mean_error + variance))
            penalty = lipschitz * pred.radius
        clearance = Arena().clearance(pred.own[..., :2])
        terrain_cost = 35 * np.maximum(.23 - clearance, 0)**2
        distances = self.navigation.distance_to(pred.own[..., :2], self.navigation.north_target(x[0, :2])) if force_north else self.navigation.distance(pred.own[..., :2])
        # Own-state task shaping does not change the opponent Lipschitz term.
        navigation_cost = 2.0 * np.maximum(distances - .25, 0)
        terminal = np.maximum(distances[:, -1] - .25, 0) / .18
        objective = self.cfg.dt * (expected + penalty + terrain_cost + navigation_cost).sum(1) + terminal
        if self.goal_hold:
            # Region keeping is an own-state task term, leaving L*Theta intact.
            radius2 = np.sum((pred.own[..., :2] - self.goal)**2, axis=-1)
            objective += self.cfg.dt * (8 * radius2 + 2 * np.sum(actions[..., :2]**2, axis=-1)).sum(1)
        feasible = self.navigation.feasible(pred.own, x[0, :2])
        if self.goal_hold:
            within_region = np.linalg.norm(pred.own[..., :2] - self.goal, axis=-1).max(1) < .38
            if np.any(feasible & within_region):
                feasible &= within_region
        if np.any(feasible):
            objective = np.where(feasible, objective, np.inf)
        # A receding horizon must not repeatedly plan "wait now, move later".
        # This is an own-policy task constraint, shared by every method; it does
        # not change GP beliefs, the ambiguity radius or its Lipschitz weight.
        target = self.navigation.north_target(x[0, :2]) if force_north else self.goal
        current_potential = float(self.navigation.distance_to(x[0, :2], target))
        early_progress = current_potential - distances[:, min(1, self.cfg.horizon - 1)]
        progressive = feasible & (early_progress > .012)
        progress_required = np.linalg.norm(x[0, :2] - self.goal) > self.cfg.goal_radius
        if progress_required and np.any(progressive):
            objective = np.where(progressive, objective, np.inf)
        elif progress_required and np.any(feasible):
            best_progress = np.max(early_progress[feasible])
            objective = np.where(feasible & (early_progress >= best_progress - .005), objective, np.inf)
        chosen = int(objective.argmin())
        self.model.commit(chosen)
        self.continuation = actions[chosen].copy()
        info = {"choice": labels[chosen], "expected": float(expected[chosen].sum() * self.cfg.dt),
                "regularizer": float(penalty[chosen].sum() * self.cfg.dt), "work": self.model.work,
                "decision_ms": (perf_counter() - start) * 1000, "goal_geodesic_m": remaining,
                "navigation_cost": float(navigation_cost[chosen].sum() * self.cfg.dt), "force_north": bool(force_north),
                "feasible_candidates": int(feasible.sum()), "progressive_candidates": int(progressive.sum()),
                "goal_hold_mode": bool(self.goal_hold)}
        return actions[chosen, 0].copy(), info
