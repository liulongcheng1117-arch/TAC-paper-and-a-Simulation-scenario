"""Two synchronized single-point GPs on observable pose/control innovations."""

from dataclasses import dataclass

import numpy as np
from scipy.linalg import cho_factor, cho_solve

from .game import transition


@dataclass
class Prediction:
    own: np.ndarray
    others: np.ndarray
    inputs: np.ndarray
    variance: np.ndarray  # normalized state, diagonal per opponent/coordinate
    radius: np.ndarray
    reused: np.ndarray | None = None


class DualPoseGP:
    """CV input prior + known plant prior + TWO single-point innovation GPs.

Input mean m_u(q)=u_previous; labels u_s-u_(s-1). State labels are the residual
to the known one-step plant using ACTUALLY executed u_s. Both labels belong to
the same nearest completed public transition. This specified prior is a
deployment extension, not the paper's unchanged zero-mean absolute-state GP.
"""
    def __init__(self, players, cfg, full=False, radius_fn=None, factorized=True, transition_fn=None):
        self.players, self.cfg, self.full, self.radius_fn = players, cfg, full, radius_fn
        self.transition = transition_fn or transition
        self.x, self.yu, self.yr, self.times = [], [], [], []
        self.memory = 256
        self.scale = np.r_[np.tile(cfg.state_scale, players), np.tile(cfg.limits, players)]
        self.length = 2.5
        self.su, self.sr, self.nu, self.nr = .25, .006, .08, .20
        self.arrays, self.factors, self.tree, self.pending = None, None, None, None
        self.last_rates = np.zeros((players, 6))
        self.factorized = factorized and not full
        self.local_indices = [np.r_[np.arange(6), np.arange(6 * j, 6 * (j + 1)),
                                   np.arange(6 * players, 6 * players + 6),
                                   np.arange(6 * (players + j), 6 * (players + j + 1))]
                              for j in range(1, players)]
        self.work = {}

    def observe(self, tick, x, previous, applied, successor):
        if self.times and tick <= self.times[-1]:
            raise ValueError("Completed transitions must be causal and increasing")
        self.x.append(np.r_[x.ravel(), previous.ravel()] / self.scale)
        self.yu.append(((applied[1:] - previous[1:]) / self.cfg.limits).ravel())
        self.yr.append(((successor[1:] - self.transition(x, applied, self.cfg)[1:]) / self.cfg.state_scale).ravel())
        self.times.append(tick)
        for a in (self.x, self.yu, self.yr, self.times):
            if len(a) > self.memory:
                del a[0]
        h, yu, yr = np.asarray(self.x), np.asarray(self.yu), np.asarray(self.yr)
        self.arrays = h, np.sum(h * h, 1), yu, yr
        self.local_history = np.stack([h[:, idx] for idx in self.local_indices])
        self.local_norm = np.sum(self.local_history**2, -1)
        self.last_rates = (successor - x) / self.cfg.dt
        if self.full:
            distance = np.maximum(np.sum(h * h, 1)[:, None] + np.sum(h * h, 1) - 2 * h @ h.T, 0)
            kernel = np.exp(-distance / self.length**2)
            self.factors = [cho_factor(kernel + np.eye(len(h)) * noise**2, lower=True, check_finite=False)
                            for noise in (self.nu, self.nr)]

    def posterior(self, query):
        b, j = len(query), self.players - 1
        if self.arrays is None:
            return np.zeros((b, j, 6)), np.zeros((b, j, 6)), np.full((b, j), self.su**2), np.full((b, j), self.sr**2)
        h, h2, yu, yr = self.arrays
        if self.factorized:
            q = np.stack([query[:, idx] for idx in self.local_indices])
            distance = np.maximum(np.sum(q**2, -1)[..., None] + self.local_norm[:, None]
                                  - 2 * q @ self.local_history.transpose(0, 2, 1), 0)
            nearest = distance.argmin(-1)
            anchors = self.local_history[np.arange(j)[:, None], nearest]
            corr = np.exp(-np.sum((q - anchors)**2, -1) / self.length**2).T
            labels_u = yu.reshape(len(h), j, 6)[nearest.T, np.arange(j)[None]]
            labels_r = yr.reshape(len(h), j, 6)[nearest.T, np.arange(j)[None]]
            gu, gr = corr / (1 + self.nu**2), corr / (1 + self.nr**2)
            return (gu[..., None] * labels_u, gr[..., None] * labels_r,
                    self.su**2 * (1 - corr * gu), self.sr**2 * (1 - corr * gr))
        distances = np.maximum(np.sum(query * query, 1)[:, None] + h2 - 2 * query @ h.T, 0)
        if self.full:
            cross = np.exp(-distances / self.length**2)
            result = []
            variances = []
            for label, factor, std in zip((yu, yr), self.factors, (self.su, self.sr)):
                result.append((cross @ cho_solve(factor, label, check_finite=False)).reshape(b, j, 6))
                variances.append(std**2 * np.maximum(1 - np.sum(cross * cho_solve(factor, cross.T, check_finite=False).T, 1), 0))
            return *result, *(np.repeat(v[:, None], j, 1) for v in variances)
        nearest = distances.argmin(1)
        corr = np.exp(-np.sum((query - h[nearest])**2, 1) / self.length**2)
        gu, gr = corr / (1 + self.nu**2), corr / (1 + self.nr**2)
        return ((gu[:, None] * yu[nearest]).reshape(b, j, 6),
                (gr[:, None] * yr[nearest]).reshape(b, j, 6),
                np.repeat((self.su**2 * np.maximum(1 - corr * gu, 0))[:, None], j, 1),
                np.repeat((self.sr**2 * np.maximum(1 - corr * gr, 0))[:, None], j, 1))

    @staticmethod
    def key(time, state_prefix, control_prefix):
        return time, np.round(np.concatenate((state_prefix, control_prefix), -1), 11).tobytes()

    def forecast(self, tick, x, previous, plans):
        if self.times and self.times[-1] >= tick:
            raise ValueError("Future transition leaked into decision")
        b, h, _ = plans.shape
        own, pos = [], np.broadcast_to(x[0], (b, 6)).copy()
        for k in range(h):
            pos = self.transition(pos, plans[:, k], self.cfg)
            own.append(pos.copy())
        own = np.stack(own, 1)
        before = np.concatenate((np.broadcast_to(x[0], (b, 1, 6)), own[:, :-1]), 1)
        past_u = np.concatenate((np.broadcast_to(previous[0], (b, 1, 6)), plans[:, :-1]), 1)
        packed = np.round(np.concatenate((before, past_u), -1), 11)
        cache, resets, misses = {}, 0, 0
        if self.tree is not None and tick == self.tree[0] + 1:
            _old_tick, old_plans, old, applied_own = self.tree
            innovation = np.linalg.norm((x[1:] - old.others[0, 0]) / self.cfg.state_scale) / np.sqrt(6 * (self.players - 1))
            if innovation > .08:
                resets = 1
            else:
                for c in range(len(old_plans)):
                    if not (np.allclose(old_plans[c, 0], applied_own, atol=1e-11, rtol=0)
                            and np.allclose(previous[0], applied_own, atol=1e-11, rtol=0)
                            and np.allclose(old.own[c, 0], x[0], atol=1e-11, rtol=0)):
                        misses += 1
                        continue
                    for k in range(h - 1):
                        key = self.key(tick + k + 1, old.own[c, :k + 1], old_plans[c, :k + 1])
                        cache[key] = (old.others[c, k + 1], old.inputs[c, k + 1], old.variance[c, k + 1], old.radius[c, k + 1])
        others = np.empty((b, h, self.players - 1, 6))
        inputs = np.empty_like(others)
        variance = np.empty((b, h, self.players - 1, 6))
        radius = np.zeros((b, h))
        reused = np.zeros((b, h), bool)
        work = {"new_queries": 0, "temporal_hits": 0, "prefix_hits": 0, "innovation_resets": resets, "condition_misses": misses}
        for k in range(h):
            groups = {}
            for c in range(b):
                key = tick + k + 1, packed[c, :k + 1].tobytes()
                groups.setdefault(key, []).append(c)
            new = [(key, rows) for key, rows in groups.items() if key not in cache]
            memo = {}
            if new:
                ids = np.array([rows[0] for _, rows in new])
                peers = others[ids, k - 1] if k else np.broadcast_to(x[1:], (len(ids), self.players - 1, 6))
                old_u = inputs[ids, k - 1] if k else np.broadcast_to(previous[1:], peers.shape)
                state = np.concatenate((before[ids, k, None], peers), 1)
                command = np.concatenate((past_u[ids, k, None], old_u), 1)
                q = np.concatenate((state.reshape(len(ids), -1), command.reshape(len(ids), -1)), -1) / self.scale
                du, residual, vu, vr = self.posterior(q)
                predicted_u = np.clip(old_u + du * self.cfg.limits, -self.cfg.limits, self.cfg.limits)
                predicted = self.transition(peers, predicted_u, self.cfg) + residual * self.cfg.state_scale
                predicted[..., 3:] = np.clip(predicted[..., 3:], 0, 1)
                v = (self.cfg.dt * self.cfg.limits / self.cfg.state_scale * np.sqrt(vu[..., None]) + np.sqrt(vr[..., None]))**2
                r = np.asarray(self.radius_fn(v, k)) if self.radius_fn else np.zeros(len(ids))
                for i, (key, rows) in enumerate(new):
                    memo[key] = predicted[i], predicted_u[i], v[i], r[i]
                work["new_queries"] += len(ids)
            for key, rows in groups.items():
                values = cache.get(key)
                if values is None:
                    values = memo[key]
                    work["prefix_hits"] += len(rows) - 1
                else:
                    work["temporal_hits"] += len(rows)
                    reused[rows, k] = True
                for out, value in zip((others, inputs, variance, radius), values):
                    out[rows, k] = value
        self.work = work
        result = Prediction(own, others, inputs, variance, radius, reused)
        self.pending = tick, plans.copy(), result
        return result

    def commit(self, selected):
        self.tree = (*self.pending, self.pending[1][selected, 0].copy())


class PoseCV:
    """Constant measured rates of BODY AND CLAW, not body trajectory alone."""
    def __init__(self, players, cfg, phase=False, transition_fn=None):
        self.players, self.cfg, self.phase = players, cfg, phase
        self.transition = transition_fn or transition
        self.last_rates = np.zeros((players, 6))
        self.strike_at = np.full(players - 1, .55)
        self.work = {}

    def observe(self, tick, x, previous, applied, successor):
        self.last_rates = (successor - x) / self.cfg.dt
        accelerated = (applied[1:, 3] > 1.) & (previous[1:, 3] < .3) & (x[1:, 3] > .3)
        self.strike_at[accelerated] = .6 * self.strike_at[accelerated] + .4 * x[1:, 3][accelerated]

    def forecast(self, tick, x, previous, plans):
        b, h, _ = plans.shape
        own, peer, us = np.broadcast_to(x[0], (b, 6)).copy(), np.broadcast_to(x[1:], (b, self.players - 1, 6)).copy(), np.broadcast_to(self.last_rates[1:], (b, self.players - 1, 6)).copy()
        po, oo, cu = [], [], []
        for k in range(h):
            if self.phase:
                # Classical event/phase extrapolation with joint limits and
                # visible windup/retraction; no private phase or trait input.
                us[..., 3] = np.where(peer[..., 3] > .93, -np.maximum(abs(us[..., 3]), 1), us[..., 3])
                us[..., 3] = np.where((peer[..., 3] < .10) & (us[..., 3] < 0), 0, us[..., 3])
                us[..., 3] = np.where((peer[..., 3] >= self.strike_at) & (us[..., 3] >= 0), 2.3, us[..., 3])
                us[..., 4] = np.where((peer[..., 3] > .65) & (us[..., 3] > 0), np.maximum(us[..., 4], 2), us[..., 4])
            peer = self.transition(peer, us, self.cfg)
            own = self.transition(own, plans[:, k], self.cfg)
            po.append(peer.copy())
            oo.append(own.copy())
            cu.append(us.copy())
        self.work = {"new_queries": 0, "temporal_hits": 0, "prefix_hits": 0, "innovation_resets": 0}
        return Prediction(np.stack(oo, 1), np.stack(po, 1), np.stack(cu, 1), np.zeros((b, h, self.players - 1, 6)), np.zeros((b, h)))

    def commit(self, selected):
        pass
