"""Paired native experiments with genuinely randomized, unoccupied starts.

The map, robots, controllers, contact rules and hidden reaction laws are exactly
those of the successful territorial experiment. Only initial positions change.
"""

import argparse
import hashlib
import importlib.util
import json
import sys

import numpy as np
from scipy.optimize import nnls
from threadpoolctl import threadpool_limits

from crab_interaction.arena import Arena

from .arena3d import advance
from .native import ClawRuntime
from .policy3d import NativeConfig, features, moments, plans
from .strategy_experiment import ROOT
from .territorial_strategy import TerritorialPolicy, TerritorialPopulation
from .territorial_strategy import engine as territorial_engine
from .territorial_strategy import fingerprint as territorial_fingerprint

RUNS = ROOT / ".cache" / "randomized_strategy"
EXPORT = ROOT / "outputs" / "randomized_strategy"
TEST_SEEDS = tuple(range(66000, 66012))
CALIBRATION_SEEDS = tuple(range(64000, 64004))
METHODS = ("pose_cv", "dual_gp", "dual_dro")


def random_positions(seed, players=4):
    if players != 4:
        raise ValueError("The randomized study uses four crabs")
    rng = np.random.default_rng(np.random.SeedSequence([seed, 310771]))
    terrain, accepted = Arena(), []
    for _ in range(20000):
        point = rng.uniform([-1.9, -1.4], [1.9, 1.8])
        if terrain.clearance(point) < .30:
            continue
        if np.min(np.linalg.norm(terrain.foods - point, axis=-1)) < .85:
            continue
        if accepted and np.min(np.linalg.norm(np.asarray(accepted) - point, axis=-1)) < .65:
            continue
        accepted.append(point)
        if len(accepted) == players:
            # No color or method gets priority in the sequential sampler.
            return np.asarray(accepted)[rng.permutation(players)]
    raise RuntimeError("Unable to sample a separated four-crab layout")


_spec = importlib.util.spec_from_file_location("crab_defense._randomized_world", ROOT / "crab_defense/world3d.py")
_world = importlib.util.module_from_spec(_spec)
sys.modules[_spec.name] = _world
_spec.loader.exec_module(_world)
_world.initial_positions = random_positions


class RandomizedArena(_world.ArticulatedArena):
    def __init__(self, seed, players, runtime, start="original"):
        if start != "original":
            raise ValueError("Randomized native starts do not use encounter overrides")
        super().__init__(seed, players, runtime, start)
        self.sides[0] = 1  # The known focal task remains the RIGHT resource.
        self.layout_seed = seed
        self.initial_public_state = None

    def warmup(self):
        state = super().warmup()
        self.initial_public_state = state.copy()
        assert np.min(np.linalg.norm(state[:, None, :2] - Arena.foods[None], axis=-1)) > .65
        return state

    def report(self):
        result = super().report()
        result["initialization"] = {"seed": self.layout_seed,
            "protocol": "all four positions sampled in free terrain; shuffled colors; both green regions initially empty",
            "spawn_xy": [list(c.xy) for c in self.configs],
            "initial_public_state": self.initial_public_state.tolist(),
            "minimum_map_clearance_m": .30, "minimum_pair_distance_m": .65,
            "minimum_distance_to_either_green_center_m": .85, "visible_green_radius_m": .65}
        return result


def fingerprint():
    result = territorial_fingerprint()
    result["crab_defense/randomized_strategy.py"] = hashlib.sha256((ROOT / "crab_defense/randomized_strategy.py").read_bytes()).hexdigest()
    return result


def engine(visual=False):
    module = territorial_engine(visual)
    module.ArticulatedArena = RandomizedArena
    module.OUT, module.fingerprint = RUNS, fingerprint
    return module


def calibrate(cfg, runtime):
    errors, variances = [[] for _ in range(cfg.horizon)], [[] for _ in range(cfg.horizon)]
    position = [[] for _ in range(cfg.horizon)]
    for seed in CALIBRATION_SEEDS:
        world = RandomizedArena(seed, 4, runtime)
        try:
            x, previous = world.warmup(), np.zeros((4, 6))
            population, tick = TerritorialPopulation(seed, world, cfg), 0
            policy, rng = TerritorialPolicy("dual_gp", 4, 1, cfg), np.random.default_rng(seed)
            for probe in range(12):
                options, _ = plans(x, previous, 1, cfg, navigation=policy.navigation)
                selected = options[int(rng.integers(len(options)))][None]
                forecast = policy.model.forecast(tick, x, previous, selected)
                center, variance = moments(forecast, cfg, policy.nodes, policy.goal)
                for k in range(cfg.horizon):
                    applied = population.choose(tick, x, previous)
                    applied[0] = selected[0, k]
                    successor = advance(world, applied, cfg)
                    truth = features(forecast.own[0, k], successor[1:], policy.goal)
                    errors[k].append(float(np.sum((truth - center[0, k])**2)))
                    variances[k].append(float(variance[0, k]))
                    sigma = np.maximum(np.sqrt(forecast.variance[0, k, :, :2]) * cfg.state_scale[:2], .003)
                    position[k].extend(np.linalg.norm((successor[1:, :2] - forecast.others[0, k, :, :2]) / sigma, axis=-1).tolist())
                    policy.model.observe(tick, x, previous, applied, successor)
                    x, previous, tick = successor, applied, tick + 1
                print(f"Random-start calibration {seed}: {probe + 1}/12", flush=True)
        finally:
            world.close()
    scale = max(float(np.max(variances)), 1e-10)
    fits = [nnls(np.c_[np.ones(len(v)), np.asarray(v) / scale], e)[0].tolist() for v, e in zip(variances, errors)]
    bands = [float(np.sort(p)[min(len(p) - 1, int(np.ceil((len(p) + 1) * .90)) - 1)]) for p in position]
    return {"domain": "original articulated MuJoCo", "source_sha256": fingerprint(), "seeds": list(CALIBRATION_SEEDS),
            "moment_fit": fits, "variance_scale": scale, "position_scale90": bands,
            "probes_per_seed": 12, "scenario": "all actors start outside both green regions, broad random free-space positions",
            "uncertainty": "independent empirical calibration, not a theoretical safety certificate"}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--methods", nargs="+", choices=METHODS, default=list(METHODS))
    parser.add_argument("--seed", type=int, default=66000)
    parser.add_argument("--count", type=int, default=1)
    parser.add_argument("--seconds", type=float, default=120)
    parser.add_argument("--calibrate-only", action="store_true")
    parser.add_argument("--record", action="store_true")
    args = parser.parse_args()
    RUNS.mkdir(parents=True, exist_ok=True)
    runtime, cfg = ClawRuntime(), NativeConfig()
    path = RUNS / "calibration.json"
    try:
        with threadpool_limits(limits=1):
            if args.calibrate_only:
                path.write_text(json.dumps(calibrate(cfg, runtime), indent=2), "utf-8")
            else:
                calibration = json.loads(path.read_text("utf-8"))
                assert calibration["source_sha256"] == fingerprint()
                runner = engine(args.record)
                for seed in range(args.seed, args.seed + args.count):
                    for method in args.methods:
                        runner.run(seed, 4, method, args.seconds, cfg, runtime, calibration, args.record, False, "original", False)
    finally:
        runtime.close()


if __name__ == "__main__":
    main()
