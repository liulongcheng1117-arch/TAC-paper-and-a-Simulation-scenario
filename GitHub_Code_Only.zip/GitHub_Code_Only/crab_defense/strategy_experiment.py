"""Matched ORIGINAL 3D experiments; presentation exports are successful cases.

Reuse the unchanged native engine through an isolated module instance, injecting
only the strategy learner and visualizer. Goal rules, limbs, contact scoring and
opponents stay identical across methods. Full research data is kept separately
from the user-facing successful demonstrations.
"""

import argparse
import hashlib
import importlib.util
import json
from dataclasses import asdict
from pathlib import Path

import numpy as np
from scipy.optimize import nnls
from threadpoolctl import threadpool_limits

from .arena3d import advance
from .arena3d import fingerprint as native_fingerprint
from .native import ClawRuntime
from .policy3d import NativeConfig, features, moments, plans
from .strategy_policy import StrategyPolicy
from .world3d import ArticulatedArena, ReactivePopulation

ROOT = Path(__file__).resolve().parents[1]
RUNS = ROOT / ".cache" / "strategy_research"
EXPORT = ROOT / "outputs" / "strategy_3d_success"
METHODS = ["pose_cv", "dual_gp", "dual_dro", "phase_mpc", "full_gp"]


def fingerprint():
    result = native_fingerprint()
    for name in ("strategy_prediction.py", "strategy_policy.py", "strategy_experiment.py"):
        path = ROOT / "crab_defense" / name
        result["crab_defense/" + name] = hashlib.sha256(path.read_bytes()).hexdigest()
    return result


def engine(visual=False):
    path = ROOT / "crab_defense" / "arena3d.py"
    spec = importlib.util.spec_from_file_location("crab_defense._strategy_native_engine", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    module.NativePolicy, module.OUT, module.fingerprint = StrategyPolicy, RUNS, fingerprint
    if visual:
        from .strategy_visual import picture
        module.picture = picture
    return module


def calibrate(players, cfg, runtime, start):
    errors, variances = [[] for _ in range(cfg.horizon)], [[] for _ in range(cfg.horizon)]
    position_scores = [[] for _ in range(cfg.horizon)]
    for seed in (61000, 61001, 61002, 61003):
        world = ArticulatedArena(seed, players, runtime, start)
        try:
            x, previous = world.warmup(), np.zeros((players, 6))
            population, tick = ReactivePopulation(seed, world, cfg), 0
            policy, rng = StrategyPolicy("dual_gp", players, int(world.sides[0]), cfg), np.random.default_rng(seed)
            for probe in range(8):
                options, _ = plans(x, previous, policy.side, cfg, navigation=policy.navigation)
                selected = options[int(rng.integers(len(options)))][None]
                forecast = policy.model.forecast(tick, x, previous, selected)
                center, variance = moments(forecast, cfg, policy.nodes, policy.goal)
                for k in range(cfg.horizon):
                    applied = population.choose(tick, x, previous)
                    applied[0] = selected[0, k]
                    successor = advance(world, applied, cfg)
                    truth = features(forecast.own[0, k], successor[1:], policy.goal)
                    errors[k].append(float(np.sum((truth - center[0, k])**2)))
                    variances[k].append(float(variance[0, k]))
                    deviation = successor[1:, :2] - forecast.others[0, k, :, :2]
                    sigma = np.sqrt(forecast.variance[0, k, :, :2]) * cfg.state_scale[:2]
                    position_scores[k].extend(np.linalg.norm(deviation / np.maximum(sigma, .003), axis=-1).tolist())
                    policy.model.observe(tick, x, previous, applied, successor)
                    x, previous, tick = successor, applied, tick + 1
                print(f"Independent native calibration {seed}: {probe + 1}/8", flush=True)
        finally:
            world.close()
    scale = max(float(np.max(variances)), 1e-10)
    fit = [nnls(np.c_[np.ones(len(v)), np.asarray(v) / scale], e)[0].tolist() for v, e in zip(variances, errors)]
    quantiles = []
    for scores in position_scores:
        index = min(len(scores) - 1, int(np.ceil((len(scores) + 1) * .90)) - 1)
        quantiles.append(float(np.sort(scores)[index]))
    return {"domain": "original articulated MuJoCo", "source_sha256": fingerprint(), "players": players, "start": start,
            "config": asdict(cfg), "seeds": [61000, 61001, 61002, 61003], "samples_per_horizon": len(errors[0]),
            "variance_scale": scale, "moment_fit": fit, "position_scale90": quantiles,
            "position_band": "independent 90% empirical standardized-error band; not a theorem confidence or safety certificate",
            "radius": "feature-space W1 independent-coupling form sqrt(M + trace(Cov)); empirical moments"}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--methods", nargs="+", choices=METHODS, default=["pose_cv", "dual_gp", "dual_dro"])
    parser.add_argument("--seed", type=int, default=62000)
    parser.add_argument("--count", type=int, default=4)
    parser.add_argument("--seconds", type=float, default=90)
    parser.add_argument("--robots", type=int, default=4)
    parser.add_argument("--start", choices=["original", "encounter"], default="original")
    parser.add_argument("--record", action="store_true")
    parser.add_argument("--live", action="store_true")
    parser.add_argument("--calibrate", action="store_true")
    parser.add_argument("--calibrate-only", action="store_true")
    args = parser.parse_args()
    RUNS.mkdir(parents=True, exist_ok=True)
    EXPORT.mkdir(parents=True, exist_ok=True)
    cfg, runtime = NativeConfig(), ClawRuntime()
    path = RUNS / f"calibration-{args.start}-n{args.robots}.json"
    try:
        with threadpool_limits(limits=1):
            if args.calibrate or args.calibrate_only:
                path.write_text(json.dumps(calibrate(args.robots, cfg, runtime, args.start), indent=2), "utf-8")
            calibration = json.loads(path.read_text("utf-8")) if path.exists() else None
            if "dual_dro" in args.methods and (not calibration or calibration["source_sha256"] != fingerprint()):
                raise ValueError("Independent native strategy calibration is required")
            if not args.calibrate_only:
                runner = engine(args.record or args.live)
                for seed in range(args.seed, args.seed + args.count):
                    for method in args.methods:
                        runner.run(seed, args.robots, method, args.seconds, cfg, runtime, calibration,
                                   args.record, args.live, args.start, True)
    finally:
        runtime.close()


if __name__ == "__main__":
    main()
