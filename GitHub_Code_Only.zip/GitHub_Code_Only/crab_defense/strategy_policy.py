"""Observable strategy decisions, using the SAME goal/constraint controller.

The recorder wraps forecast/commit and never recomputes or changes the chosen
decision. The original successful goal controller and its snapshot stay intact.
"""

import importlib.util
from pathlib import Path
import sys
from time import perf_counter

import numpy as np

from crab_interaction.arena import Arena

from .policy3d import feature_objective as original_objective, moments
from .strategy_prediction import InteractionDualGP

ACTIVE_POLICY = None


def feature_objective(own, phi, u, goal):
    expected, _ = original_objective(own, phi, u, goal)
    a = 3 * np.exp(-np.sum((own[..., :2] - goal)**2, -1) / (2 * .6**2))
    # For every nonnegative resource-occupancy feature: |d cost / d occupancy|
    # <= a. Use this GLOBAL bound, rather than the gradient at the mean.
    return expected, np.sqrt(phi.shape[-2] * (a**2 + 12**2 + 3**2 + 3**2))


# Give the upgraded controller its own module globals. The original successful
# goal controller, its calibration and its launchers must retain their behavior.
_spec = importlib.util.spec_from_file_location("crab_defense._strategy_policy_impl", Path(__file__).with_name("policy3d.py"))
_policy = importlib.util.module_from_spec(_spec)
sys.modules[_spec.name] = _policy
_spec.loader.exec_module(_policy)
_policy.feature_objective = feature_objective
NativePolicy = _policy.NativePolicy


class ForecastRecorder:
    def __init__(self, model):
        self.model, self.prediction, self.actions, self.selected = model, None, None, None

    def __getattr__(self, name):
        return getattr(self.model, name)

    def forecast(self, tick, x, previous, actions):
        self.actions = actions
        self.prediction = self.model.forecast(tick, x, previous, actions)
        return self.prediction

    def commit(self, selected):
        self.selected = selected
        self.model.commit(selected)


class StrategyPolicy(NativePolicy):
    def __init__(self, method, players, side, cfg, calibration=None):
        super().__init__(method, players, side, cfg, calibration)
        if method in ("dual_gp", "dual_dro"):
            self.model = InteractionDualGP(players, cfg, transition_fn=self.model.transition)
        self.model = ForecastRecorder(self.model)
        self.last_packet = None
        global ACTIVE_POLICY
        ACTIVE_POLICY = self

    def choose(self, tick, x, previous):
        controls, info = super().choose(tick, x, previous)
        explain_start = perf_counter()
        pred, actions, chosen = self.model.prediction, self.model.actions, self.model.selected
        phi, _variance = moments(pred, self.cfg, self.nodes, self.goal)
        expected, lipschitz = feature_objective(pred.own, phi, actions, self.goal)
        regularizer = lipschitz * pred.radius if self.method == "dual_dro" else np.zeros_like(expected)
        target = self.navigation.north_target(x[0, :2]) if info["force_north"] else self.goal
        distance = self.navigation.distance_to(pred.own[..., :2], target)
        navigation = 2 * np.maximum(distance - .25, 0)
        terrain = 35 * np.maximum(.23 - Arena().clearance(pred.own[..., :2]), 0)**2
        terminal = np.maximum(distance[:, -1] - .25, 0) / .18
        task = self.cfg.dt * (navigation + terrain).sum(1) + terminal
        if self.goal_hold:
            task += self.cfg.dt * (8 * np.sum((pred.own[..., :2] - self.goal)**2, -1)
                                   + 2 * np.sum(actions[..., :2]**2, -1)).sum(1)
        nominal = self.cfg.dt * expected.sum(1)
        robust = self.cfg.dt * regularizer.sum(1)
        total = nominal + robust + task
        feasible = self.navigation.feasible(pred.own, x[0, :2])
        if self.goal_hold:
            inside = np.linalg.norm(pred.own[..., :2] - self.goal, axis=-1).max(1) < .38
            if np.any(feasible & inside):
                feasible &= inside
        early = float(self.navigation.distance_to(x[0, :2], target)) - distance[:, 1]
        progressive = feasible & (early > .012)
        if np.linalg.norm(x[0, :2] - self.goal) > self.cfg.goal_radius:
            if np.any(progressive):
                feasible &= progressive
            elif np.any(feasible):
                feasible &= early >= np.max(early[feasible]) - .005
        if not np.any(feasible):
            feasible[:] = True
        _, route_labels = self.navigation.xy_plans(x[0, :2], previous[0, :2], self.cfg, info["force_north"])
        labels = [(route, wait, posture) for route, wait in route_labels for posture in range(4)]
        if len(actions) > len(labels):
            labels.append(("continuation", 0, -1))
        masked = np.where(feasible, total, np.inf)
        assert np.isclose(total[chosen], masked.min(), rtol=1e-8, atol=1e-8), "Explanation differs from executed objective"
        ranked = np.argsort(masked)
        # Contrast one different hand posture and one different route. Their
        # predictions are genuinely evaluated branches, not artistic arrows.
        display = [chosen]
        for condition in (lambda i: labels[i][2] != labels[chosen][2], lambda i: labels[i][0] != labels[chosen][0]):
            match = next((int(i) for i in ranked if feasible[i] and i not in display and condition(i)), None)
            if match is not None:
                display.append(match)
        for i in ranked:
            if len(display) >= 3:
                break
            if feasible[i] and int(i) not in display:
                display.append(int(i))
        spatial_difference = max((float(np.linalg.norm(pred.others[c, :, :, :2] - pred.others[chosen, :, :, :2], axis=-1).max())
                                  for c in display), default=0.)
        packet = {"selected": int(chosen), "labels": labels, "feasible": feasible.tolist(),
                  "expected": nominal.tolist(), "regularizer": robust.tolist(), "task": task.tolist(), "total": total.tolist(),
                  "ranked": [int(i) for i in ranked if feasible[i]], "display": display,
                  "own": pred.own[display].tolist(), "opponents": pred.others[display].tolist(),
                  "variance": pred.variance[display].tolist(), "theta": pred.radius[display].tolist(),
                  "candidate_reaction_spread_m": spatial_difference,
                  "empirical_position_scale": self.calibration.get("position_scale90", [2.] * self.cfg.horizon) if self.calibration else [2.] * self.cfg.horizon,
                  "nominal_winner": int(np.where(feasible, nominal + task, np.inf).argmin()),
                  "prior_samples": getattr(self.model, "sample_count", 0), "work": dict(self.model.work)}
        self.last_packet = packet
        info["explanation"] = packet
        info["explanation_ms"] = (perf_counter() - explain_start) * 1000
        return controls, info
