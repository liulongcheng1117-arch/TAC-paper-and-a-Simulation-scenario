"""Semiparametric two-single-point GP with public interaction features.

A small recursive least-squares input PRIOR is learned from completed public
transitions. Both GP corrections still use the SAME one historical anchor.
No opponent label, goal, phase, future input or private parameter is available.
"""

import numpy as np

from .prediction import DualPoseGP


class InteractionDualGP(DualPoseGP):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        dim = self.encode(np.zeros((1, len(self.scale)))).shape[-1]
        self.weights = np.zeros((self.players - 1, dim, 6))
        # CV is the cold-start prior; learned coefficients add interaction.
        self.inverse = np.broadcast_to(np.eye(dim) * .3, (self.players - 1, dim, dim)).copy()
        self.forgetting = .995
        self.sample_count = 0

    def encode(self, query):
        output = []
        for idx in self.local_indices:
            q = query[:, idx]
            own, peer = q[:, :6], q[:, 6:12]
            delta = own[:, :2] - peer[:, :2]
            distance2 = np.sum((.6 * delta)**2, -1)
            near = np.exp(-distance2 / (2 * .65**2))
            threat = own[:, 3] * (.4 + own[:, 4])
            relative_velocity = q[:, 12:14] - q[:, 18:20]
            approach = -np.sum(delta * relative_velocity, -1) / np.maximum(np.linalg.norm(delta, axis=-1), .1)
            # Periodic encoding avoids treating headings separated by 2pi as
            # unrelated. Relative position exposes game response conditions.
            feature = np.c_[np.ones(len(q)), delta, peer[:, :2],
                            np.sin(own[:, 2]), np.cos(own[:, 2]), np.sin(peer[:, 2]), np.cos(peer[:, 2]),
                            own[:, 3:], peer[:, 3:], q[:, 12:], near,
                            near * threat, near * approach, near * own[:, 5],
                            near[:, None] * delta]
            output.append(feature)
        return np.stack(output)

    def prior(self, query):
        feature = self.encode(query)
        cold = query[:, 6 * self.players:].reshape(len(query), self.players, 6)[:, 1:].copy()
        # Native claw commands are rates to a held posture, not inertial
        # velocities; a damped rate is the declared cold-start actuator prior.
        cold[..., 3:] *= .35
        correction = np.einsum("jbd,jdk->bjk", feature, self.weights)
        return np.clip(cold + correction, -1, 1), feature

    def observe(self, tick, x, previous, applied, successor):
        query = np.r_[x.ravel(), previous.ravel()][None] / self.scale
        mean, feature = self.prior(query)
        label = applied[1:] / self.cfg.limits
        for j in range(self.players - 1):
            f, covariance = feature[j, 0], self.inverse[j]
            projected = covariance @ f
            gain = projected / (self.forgetting + np.dot(f, projected))
            self.weights[j] += np.outer(gain, label[j] - mean[0, j])
            self.inverse[j] = (covariance - np.outer(gain, projected)) / self.forgetting
        self.sample_count += 1
        super().observe(tick, x, previous, applied, successor)
        history, _, innovations, residuals = self.arrays
        mean, encoded = self.prior(history)
        previous = history[:, 6 * self.players:].reshape(len(history), self.players, 6)[:, 1:]
        self.history_features = encoded
        self.history_norm = np.sum(encoded**2, -1)
        self.history_input_residual = previous + innovations.reshape(len(history), self.players - 1, 6) - mean
        self.history_state_residual = residuals.reshape(len(history), self.players - 1, 6)

    def posterior(self, query):
        mean, feature = self.prior(query)
        b, j = len(query), self.players - 1
        previous = query[:, 6 * self.players:].reshape(b, self.players, 6)[:, 1:]
        if self.arrays is None:
            return mean - previous, np.zeros((b, j, 6)), np.full((b, j), self.su**2), np.full((b, j), self.sr**2)
        distance = np.maximum(np.sum(feature**2, -1)[..., None] + self.history_norm[:, None]
                              - 2 * feature @ self.history_features.transpose(0, 2, 1), 0)
        nearest = distance.argmin(-1)
        corr = np.exp(-np.min(distance, -1) / self.length**2).T
        gu, gr = corr / (1 + self.nu**2), corr / (1 + self.nr**2)
        row, col = nearest.T, np.arange(j)[None]
        errors = self.history_input_residual[row, col]
        predicted = np.clip(mean + gu[..., None] * errors, -1, 1)
        state_error = self.history_state_residual[row, col]
        return (predicted - previous, gr[..., None] * state_error,
                self.su**2 * (1 - corr * gu), self.sr**2 * (1 - corr * gr))
