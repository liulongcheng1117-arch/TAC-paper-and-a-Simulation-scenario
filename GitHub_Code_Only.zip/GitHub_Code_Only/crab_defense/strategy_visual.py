"""Original 3D rendering with real forecast overlays and an auditable score UI."""

from itertools import pairwise

import mujoco
import numpy as np
from PIL import Image, ImageDraw, ImageFont

from . import strategy_policy
from .policy3d import hand_point

NAMES = {"pose_cv": "CV-MPC", "dual_gp": "本文双单点 GPR", "dual_dro": "本文分布鲁棒学习", "phase_mpc": "阶段 MPC", "full_gp": "全历史 GP"}
ROUTES = {"direct": "通道", "north": "绕行", "north_high": "上绕", "north_low": "下绕", "flank_up": "上侧接近", "flank_down": "下侧接近", "hold": "保持", "retreat": "退让", "continuation": "续接"}
POSTURES = {0: "收钳", 1: "防御", 2: "夹持", 3: "抬钳", -1: "延续"}
COLORS = [np.array([.10, .80, 1., .95]), np.array([1., .70, .15, .90]), np.array([.76, .35, 1., .80])]
LIVE_VIEW = None
CAMERA = {"distance": 5.0, "azimuth": 105., "elevation": -57.}


def geom(scene, kind, position, size, rgba):
    if scene.ngeom >= scene.maxgeom:
        return None
    g = scene.geoms[scene.ngeom]
    mujoco.mjv_initGeom(g, kind, np.asarray(size, dtype=float), np.asarray(position, dtype=float), np.eye(3).ravel(), np.asarray(rgba, dtype=np.float32))
    scene.ngeom += 1
    return g


def line(scene, a, b, color, radius=.007):
    if np.linalg.norm(np.asarray(a) - b) < 1e-6:
        return
    g = geom(scene, mujoco.mjtGeom.mjGEOM_CAPSULE, a, [radius, radius, radius], color)
    if g is not None:
        mujoco.mjv_connector(g, mujoco.mjtGeom.mjGEOM_CAPSULE, radius, np.asarray(a, dtype=float), np.asarray(b, dtype=float))


def picture(world, method, elapsed, benefit, goal_dwell=0.):
    world.render(1280, 720)
    camera = mujoco.MjvCamera()
    camera.lookat[:] = [0, .15, .05]
    camera.distance, camera.azimuth, camera.elevation = CAMERA["distance"], CAMERA["azimuth"], CAMERA["elevation"]
    option = mujoco.MjvOption()
    option.geomgroup[1] = 0
    world._renderer.update_scene(world.data, camera=camera, scene_option=option)
    policy = strategy_policy.ACTIVE_POLICY
    packet = policy.last_packet if policy is not None else None
    if packet is not None:
        own, peers, variance = (np.asarray(packet[key]) for key in ("own", "opponents", "variance"))
        scene = world._renderer.scene
        for branch in range(len(own)):
            color = COLORS[branch]
            path = np.c_[own[branch, :, :2], np.full(len(own[branch]), .025 + .008 * branch)]
            for a, b in pairwise(path):
                line(scene, a, b, color, .010 if branch == 0 else .006)
            # Nearest opponent body and its carried claw, in physical 3D units.
            near = int(np.argmin(np.linalg.norm(peers[branch, 0, :, :2] - own[branch, 0, :2], axis=-1)))
            path = np.c_[peers[branch, :, near, :2], np.full(len(own[branch]), .07)]
            for a, b in pairwise(path):
                line(scene, a, b, color)
            claw = hand_point(peers[branch, :, near])
            for a, b in pairwise(claw):
                line(scene, a, b, color, .005)
        if np.any(variance):
            for j in range(peers.shape[2]):
                for k in (0, min(3, peers.shape[1] - 1), peers.shape[1] - 1):
                    q = packet["empirical_position_scale"][k]
                    radii = np.maximum(np.sqrt(variance[0, k, j, :2]) * policy.cfg.state_scale[:2], .003) * q
                    angles = np.linspace(0, 2 * np.pi, 25)
                    ring = np.c_[peers[0, k, j, 0] + radii[0] * np.cos(angles),
                                 peers[0, k, j, 1] + radii[1] * np.sin(angles), np.full(len(angles), .028)]
                    for a, b in pairwise(ring):
                        line(scene, a, b, [1., .70, .18, .6], .002)
    frame = world._renderer.render()
    canvas = Image.new("RGB", (1728, 832), "#101b2a")
    canvas.paste(Image.fromarray(frame), (0, 112))
    draw = ImageDraw.Draw(canvas)
    title = ImageFont.truetype("C:/Windows/Fonts/msyh.ttc", 25)
    font = ImageFont.truetype("C:/Windows/Fonts/msyh.ttc", 18)
    tiny = ImageFont.truetype("C:/Windows/Fonts/msyh.ttc", 15)
    draw.text((18, 12), f"原版三维博弈交互 | {NAMES[method]} | {elapsed:.1f}s", font=title, fill="white")
    distance = np.linalg.norm(world.positions[0, :2] - [world.sides[0] * 1.6, .45])
    draw.text((18, 53), f"蓝蟹距目标 {distance:.2f}m   稳定停留 {goal_dwell:.1f}s   受击 {world.ledger.hit_count[0]}   被夹 {world.ledger.grasp_count[0]}", font=font, fill="#d0dff1")
    draw.text((18, 83), "红=资源防守 黄=激进 紫=谨慎 | 彩线=条件预测 橙圈=90%经验位置带 | 原版关节与真实碰撞", font=tiny, fill="#b6c8dd")
    draw.rectangle((1280, 0, 1728, 832), fill="#152235")
    draw.text((1298, 16), "候选动作与目标评分", font=title, fill="white")
    if packet is not None:
        draw.text((1298, 59), "总分越低越好；全部方案使用同一规则", font=tiny, fill="#b7c9dd")
        for px, label in ((1298, "动作"), (1430, "期望"), (1505, "鲁棒项"), (1580, "任务项"), (1652, "总分")):
            draw.text((px, 91), label, font=tiny, fill="#cfe1f7")
        for row, index in enumerate(packet["ranked"][:6]):
            route, wait, posture = packet["labels"][index]
            text = ROUTES.get(route, route) + "/" + POSTURES[posture]
            if wait:
                text += "等"
            color = "#64dcff" if index == packet["selected"] else "#c5d3e6"
            y = 128 + row * 55
            if index == packet["selected"]:
                draw.rounded_rectangle((1290, y - 6, 1715, y + 43), radius=6, fill="#24415a")
            draw.text((1299, y), text, font=tiny, fill=color)
            draw.text((1430, y), f"{packet['expected'][index]:.2f}", font=tiny, fill=color)
            draw.text((1505, y), f"{packet['regularizer'][index]:.2f}", font=tiny, fill=color)
            draw.text((1580, y), f"{packet['task'][index]:.2f}", font=tiny, fill=color)
            draw.text((1652, y), f"{packet['total'][index]:.2f}", font=tiny, fill=color)
        y = 486
        draw.text((1298, y), "为什么这样选", font=font, fill="white")
        chosen = packet["selected"]
        same = chosen == packet["nominal_winner"]
        lines = ["自身策略引起的对手预测差异：",
                 f"最大 {packet['candidate_reaction_spread_m']:.3f} 米",
                 f"鲁棒项改变本次选择：{'否' if same else '是'}",
                 f"已学习公开转移：{packet['prior_samples']}",
                 f"本步单点查询：{packet['work']['new_queries']}",
                 f"同前缀共享：{packet['work']['prefix_hits']}",
                 f"节省预测节点：{packet['work']['prefix_hits'] / max(packet['work']['new_queries'] + packet['work']['prefix_hits'], 1):.1%}"]
        for k, text in enumerate(lines):
            draw.text((1298, y + 38 + 28 * k), text, font=font if k < 3 else tiny, fill="#c5d8ee")
        draw.text((1298, 757), "预测带由独立样本标定", font=tiny, fill="#ffc976")
        draw.text((1298, 782), "总分＝期望交互＋鲁棒项＋导航任务项", font=tiny, fill="#b7c9dd")
    frame = np.asarray(canvas)
    if LIVE_VIEW is not None:
        LIVE_VIEW.show(frame, elapsed)
    return frame
