"""Persistent shared-resource game in the UNCHANGED articulated 3D terrain.

An unknown defender may yield to a visible claw threat, a bold crab may counter
attack, and a shy one gives way. Reactions are to public cues, never to a method
identity. Private profiles are visible only to the evaluation simulator.
"""

import argparse
import hashlib
import json

import numpy as np
from scipy.optimize import nnls
from threadpoolctl import threadpool_limits

from .arena3d import advance
from .native import ClawRuntime
from .policy3d import NativeConfig, features, moments, plans
from .strategy_experiment import ROOT
from .strategy_experiment import engine as base_engine
from .strategy_experiment import fingerprint as base_fingerprint
from .strategy_policy import ForecastRecorder, StrategyPolicy
from .strategy_prediction import InteractionDualGP
from .world3d import ArticulatedArena, ReactivePopulation

RUNS = ROOT / ".cache" / "territorial_research"


class CrowdInteractionGP(InteractionDualGP):
    def encode(self, query):
        local = super().encode(query)
        states = query[:, :6 * self.players].reshape(len(query), self.players, 6)
        extra = []
        for j in range(1, self.players):
            others = [i for i in range(self.players) if i != j]
            delta = states[:, others, :2] - states[:, j, None, :2]
            distance2 = np.sum((.6 * delta)**2, -1)
            attention = np.exp(-distance2 / (2 * .65**2))
            threat = states[:, others, 3] * (.4 + states[:, others, 4])
            weight = attention / np.maximum(attention.sum(1, keepdims=True), 1e-8)
            extra.append(np.c_[attention.max(1), np.sum(weight * threat, 1),
                               np.sum(weight[..., None] * delta, 1), weight[:, 0]])
        return np.concatenate((local, np.stack(extra)), -1)


class TerritorialPopulation(ReactivePopulation):
    def __init__(self, seed, world, cfg):
        super().__init__(seed, world, cfg)
        rng = np.random.default_rng(np.random.SeedSequence([seed, 77211]))
        # Shared region, heterogeneous PRIVATE reactions, including competition
        # between NPCs. No actor is told which method controls the blue robot.
        self.routes.sides[1:] = 1
        for j in range(1, len(world.configs)):
            self.bold[j] = rng.uniform(.35, .65) if j % 3 == 1 else rng.uniform(.75, .95) if j % 3 == 2 else rng.uniform(.05, .25)
        self.yield_at = rng.uniform(.40, .85, len(world.configs))
        self.response_gain = rng.uniform(.7, 1.3, len(world.configs))

    def choose(self, tick, x, previous):
        out = super().choose(tick, x, previous)
        for j in range(1, len(x)):
            distance = np.linalg.norm(x[:, :2] - x[j, :2], axis=-1)
            distance[j] = np.inf
            other = int(distance.argmin())
            d = distance[other]
            if d > .95:
                continue
            toward = (x[other, :2] - x[j, :2]) / max(d, .05)
            threat = x[other, 3] * (.4 + x[other, 4])
            approach = float(np.dot(previous[other, :2] - previous[j, :2], -toward))
            response = np.tanh(4 * (self.yield_at[j] - threat + .35 * approach))
            attention = np.exp(-(d / .8)**2)
            # Smooth unknown strategy response: predicting the OTHER robot as
            # constant-velocity loses its dependence on our candidate posture.
            strength = (.10 + .05 * self.bold[j]) * self.response_gain[j]
            out[j, :2] = (1 - .75 * attention) * out[j, :2] + attention * strength * response * toward
            if threat > self.yield_at[j] and self.bold[j] < .7:
                target = np.array([.85, .3, .75])
                out[j, 3:] = (target - x[j, 3:]) / self.cfg.dt
        return np.clip(out, -self.cfg.limits, self.cfg.limits)


class TerritorialPolicy(StrategyPolicy):
    def __init__(self, method, players, side, cfg, calibration=None):
        super().__init__(method, players, side, cfg, calibration)
        if method in ("dual_gp", "dual_dro"):
            self.model = ForecastRecorder(CrowdInteractionGP(players, cfg, transition_fn=self.model.transition))


def fingerprint():
    result = base_fingerprint()
    result["crab_defense/territorial_strategy.py"] = hashlib.sha256((ROOT / "crab_defense/territorial_strategy.py").read_bytes()).hexdigest()
    return result


def engine(visual=False):
    module = base_engine(visual)
    module.NativePolicy, module.ReactivePopulation = TerritorialPolicy, TerritorialPopulation
    module.OUT, module.fingerprint = RUNS, fingerprint
    return module


def calibrate(cfg, runtime):
    errors, variances = [[] for _ in range(cfg.horizon)], [[] for _ in range(cfg.horizon)]
    position = [[] for _ in range(cfg.horizon)]
    for seed in range(64000, 64004):
        world = ArticulatedArena(seed, 4, runtime)
        try:
            x, previous = world.warmup(), np.zeros((4, 6))
            population, tick = TerritorialPopulation(seed, world, cfg), 0
            policy, rng = TerritorialPolicy("dual_gp", 4, 1, cfg), np.random.default_rng(seed)
            for probe in range(8):
                options, _ = plans(x, previous, 1, cfg, navigation=policy.navigation)
                selected = options[int(rng.integers(len(options)))][None]
                forecast = policy.model.forecast(tick, x, previous, selected)
                center, variance = moments(forecast, cfg, policy.nodes, policy.goal)
                for k in range(cfg.horizon):
                    applied = population.choose(tick, x, previous)
                    applied[0] = selected[0, k]
                    successor = advance(world, applied, cfg)
                    truth = features(forecast.own[0, k], successor[1:], policy.goal)
                    errors[k].append(float(np.sum((truth - center[0, k])**2)))
                    variances[k].append(float(variance[0, k]))
                    sigma = np.maximum(np.sqrt(forecast.variance[0, k, :, :2]) * cfg.state_scale[:2], .003)
                    position[k].extend(np.linalg.norm((successor[1:, :2] - forecast.others[0, k, :, :2]) / sigma, axis=-1).tolist())
                    policy.model.observe(tick, x, previous, applied, successor)
                    x, previous, tick = successor, applied, tick + 1
                print(f"Native shared-region calibration {seed}: {probe + 1}/8", flush=True)
        finally:
            world.close()
    scale = max(float(np.max(variances)), 1e-10)
    fits = [nnls(np.c_[np.ones(len(v)), np.asarray(v) / scale], e)[0].tolist() for v, e in zip(variances, errors)]
    bands = [float(np.sort(p)[min(len(p) - 1, int(np.ceil((len(p) + 1) * .90)) - 1)]) for p in position]
    return {"domain": "original articulated MuJoCo", "source_sha256": fingerprint(), "seeds": list(range(64000, 64004)),
            "moment_fit": fits, "variance_scale": scale, "position_scale90": bands,
            "scenario": "same native map; persistent shared region; private heterogeneous public-cue response laws",
            "uncertainty": "empirical calibration; no theorem confidence or safety certificate"}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--methods", nargs="+", default=["pose_cv", "dual_gp", "dual_dro"])
    parser.add_argument("--seed", type=int, default=65000)
    parser.add_argument("--count", type=int, default=1)
    parser.add_argument("--seconds", type=float, default=90)
    parser.add_argument("--calibrate-only", action="store_true")
    parser.add_argument("--record", action="store_true")
    parser.add_argument("--live", action="store_true")
    args = parser.parse_args()
    RUNS.mkdir(parents=True, exist_ok=True)
    runtime, cfg = ClawRuntime(), NativeConfig()
    path = RUNS / "calibration.json"
    try:
        with threadpool_limits(limits=1):
            if args.calibrate_only:
                path.write_text(json.dumps(calibrate(cfg, runtime), indent=2), "utf-8")
            else:
                calibration = json.loads(path.read_text("utf-8"))
                assert calibration["source_sha256"] == fingerprint(), "Shared-region native calibration required"
                runner = engine(args.record or args.live)
                for seed in range(args.seed, args.seed + args.count):
                    for method in args.methods:
                        runner.run(seed, 4, method, args.seconds, cfg, runtime, calibration, args.record, args.live, "original", False)
    finally:
        runtime.close()


if __name__ == "__main__":
    main()
