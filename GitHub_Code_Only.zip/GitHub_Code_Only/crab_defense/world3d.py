"""Original 22-joint plants, original terrain and original five-foot support.

Only carried-arm joint TARGETS are overlaid. All body motion and all contact
forces come from the original MuJoCo model and original bounded servo law.
"""

import mujoco
import numpy as np
from scipy.optimize import least_squares

from crab_interaction.arena import Arena, Opponents, initial_positions
from crab_sim.multi_crab import CrabConfig

from .contacts import ContactLedger
from .native import ClawWorld
from .policy3d import hand_point, predict_step, wrap


class ArticulatedArena(ClawWorld):
    def __init__(self, seed, players, runtime, start="original"):
        terrain = Arena()
        positions = initial_positions(seed, players)
        if start == "encounter":
            slots = [[-.40, -.02], [.40, .02], [-1.3, -.1], [1.3, -.1]]
            positions[:min(players, 4)] = slots[:min(players, 4)]
        colors = [(0.08, .40, .96), (.96, .12, .10), (.98, .73, .10), (.64, .29, .92), (.1, .8, .55), (.95, .3, .6)]
        self.sides = np.where(positions[:, 0] < 0, 1, -1)
        configs = [CrabConfig(f"crab_{i}", tuple(p), colors[i % len(colors)], yaw=0. if self.sides[i] > 0 else np.pi)
                   for i, p in enumerate(positions)]
        boundaries = np.array([[-2.28, -2.20, -1.78, 2.18], [2.20, 2.28, -1.78, 2.18],
                               [-2.20, 2.20, -1.78, -1.70], [-2.20, 2.20, 2.10, 2.18]])
        super().__init__(configs, runtime=runtime, resources=terrain.foods, resource_radius=.65,
                         obstacles=np.r_[terrain.rocks, boundaries])
        self.active_sides = ["left" if i % 2 == 0 else "right" for i in range(players)]
        self.arm = []
        for i, side in enumerate(self.active_sides):
            prefix = "LF_" if side == "left" else "RF_"
            name = configs[i].name + "/"
            wire = [runtime.wire.index(f"{prefix}J{k}_joint") for k in range(4)]
            joint = [self.model.joint(name + f"{prefix}J{k}_joint").id for k in range(4)]
            self.arm.append({"wire": wire, "q": self.q_adr[i, wire], "bounds": self.model.jnt_range[joint].T.copy(),
                             "fixed": self.model.body(name + prefix + "palm_grip_insert_link").id,
                             "moving": self.model.body(name + prefix + "finger_grip_insert_link").id,
                             "finger": self.q_adr[i, runtime.wire.index(prefix + "J4_joint")]})
        self.scratch = mujoco.MjData(self.model)
        self.aims = [None] * players
        self.requested = None
        self.previous_observation = None
        self.jaw = np.zeros(players)
        self.ik_errors = []

    def observe(self):
        p = self.positions[:, :2]
        points = np.asarray([(self.data.xpos[a["fixed"]] + self.data.xpos[a["moving"]]) / 2 for a in self.arm])
        delta = points[:, :2] - p
        heading = np.arctan2(delta[:, 1], delta[:, 0])
        if self.previous_observation is not None:
            heading = self.previous_observation[:, 2] + wrap(heading - self.previous_observation[:, 2])
        finger = np.array([self.data.qpos[a["finger"]] for a in self.arm])
        close = np.clip(1 - np.abs(finger) / 1.0472, 0, 1)
        e = np.clip((np.linalg.norm(delta, axis=1) - .12) / (.11 + .04 * close), 0, 1)
        height = np.clip((points[:, 2] - .04) / .14, 0, 1)
        self.previous_observation = np.c_[p, heading, e, close, height]
        return self.previous_observation.copy()

    def warmup(self):
        for step in range(1000):
            self.primitives([{"side": "none" if step < 400 else s, "preset": "web", "close": 0.} for s in self.active_sides])
            self.step(np.zeros((len(self.configs), 3)))
        self.ledger = ContactLedger(len(self.configs))
        return self.observe()

    def command(self, controls, cfg):
        observed = self.observe()
        self.requested = predict_step(observed, np.clip(controls, -cfg.limits, cfg.limits), cfg)
        self.jaw = self.requested[:, 4].copy()

    def aim_update(self):
        if self.requested is None:
            return
        state = self.observe()
        desired = hand_point(self.requested)
        desired[:, :2] += state[:, :2] - self.requested[:, :2]
        actual = np.array([(self.data.xpos[a["fixed"]] + self.data.xpos[a["moving"]]) / 2 for a in self.arm])
        for i, arm in enumerate(self.arm):
            target = desired[i].copy()
            # Public geometric aiming: identical low-level skill for all methods.
            distances = np.linalg.norm(actual - actual[i], axis=1)
            distances[i] = np.inf
            other = int(distances.argmin())
            if self.jaw[i] > .6 and distances[other] < .13:
                target = self.data.xpos[self.arm[other]["fixed"]].copy()
            self.scratch.qpos[:] = self.data.qpos
            start = self.data.qpos[arm["q"]].copy()
            lower, upper = arm["bounds"][0] + .005, arm["bounds"][1] - .005
            start = np.clip(start, lower + 1e-7, upper - 1e-7)

            def residual(q, arm=arm, target=target, start=start):
                self.scratch.qpos[arm["q"]] = q
                mujoco.mj_kinematics(self.model, self.scratch)
                fixed, moving = self.scratch.xpos[arm["fixed"]], self.scratch.xpos[arm["moving"]]
                axis = moving - fixed
                axis /= max(np.linalg.norm(axis), 1e-8)
                return np.r_[80 * ((fixed + moving) / 2 - target), 2 * (axis - [0, 0, 1]), .03 * (q - start)]

            fit = least_squares(residual, start, bounds=(lower, upper), max_nfev=12, ftol=1e-4)
            self.aims[i] = start + np.clip(fit.x - start, -.28, .28)
            self.ik_errors.append(float(np.linalg.norm(residual(fit.x)[:3]) / 80))
        self.primitives([{"side": s, "preset": "up", "close": float(c)} for s, c in zip(self.active_sides, self.jaw)])
        # state has been measured; no state is written back into the plant.
        return state

    def _servo_substep(self):
        if hasattr(self, "aims"):
            for i, aim in enumerate(self.aims):
                if aim is not None:
                    self.targets[i, self.arm[i]["wire"]] = aim
                    self.kp[i, self.arm[i]["wire"]], self.kd[i, self.arm[i]["wire"]] = 3., .3
        super()._servo_substep()


class ReactivePopulation:
    def __init__(self, seed, world, cfg):
        self.cfg = cfg
        self.routes = Opponents(seed, world.positions[:, :2], Arena(dt=cfg.dt, speed=.18))
        rng = np.random.default_rng(np.random.SeedSequence([seed, 9411]))
        n = len(world.configs)
        self.bold = self.routes.boldness.copy()
        self.grappler = rng.uniform(0, 1, n)
        self.windup = rng.uniform(.6, 1.3, n)
        self.phase = ["forage"] * n
        self.clock = np.zeros(n)
        self.events = []

    def choose(self, tick, x, previous):
        out = np.zeros_like(x)
        out[:, :2] = self.routes.choose(tick, x[:, :2], previous[:, :2])
        for i in range(1, len(x)):
            distance = np.linalg.norm(x[:, :2] - x[i, :2], axis=1)
            distance[i] = np.inf
            other = int(distance.argmin())
            d = distance[other]
            old_phase = self.phase[i]
            threat = x[other, 3] * (.4 + x[other, 4])
            self.clock[i] += self.cfg.dt
            if self.phase[i] == "forage" and d < .8:
                self.phase[i] = "windup" if self.bold[i] > .3 else "evade"
                self.clock[i] = 0.
            elif self.phase[i] == "windup" and self.clock[i] >= self.windup[i]:
                self.phase[i] = "evade" if threat > .65 and self.bold[i] < .65 else "clamp" if self.grappler[i] > .4 else "strike"
                self.clock[i] = 0.
            elif self.phase[i] in ("strike", "clamp") and (self.clock[i] > 1.4 or d > .85):
                self.phase[i], self.clock[i] = "recover", 0.
            elif self.phase[i] in ("recover", "evade") and self.clock[i] > 1.4:
                self.phase[i], self.clock[i] = "forage", 0.
            if self.phase[i] != old_phase:
                self.events.append({"tick": tick, "actor": i, "phase": self.phase[i]})
            phase = self.phase[i]
            target = np.array([.35, 0., .35])
            if phase == "windup":
                target = np.array([.90, 0., .95])
                out[i, :2] *= .25
            elif phase in ("strike", "clamp"):
                target = np.array([.95, float(phase == "clamp"), .30])
                delta = x[other, :2] - x[i, :2]
                out[i, :2] = delta / max(d, .05) * (.08 if phase == "clamp" else .16)
            elif phase == "evade":
                target = np.array([.90, .65, .45])
                away = (x[i, :2] - x[other, :2]) / max(d, .05)
                out[i, :2] = .14 * away
            if d < .85:
                bearing = np.arctan2(x[other, 1] - x[i, 1], x[other, 0] - x[i, 0])
                out[i, 2] = 2 * wrap(bearing - x[i, 2])
            out[i, 3:] = (target - x[i, 3:]) / self.cfg.dt
        return np.clip(out, -self.cfg.limits, self.cfg.limits)
