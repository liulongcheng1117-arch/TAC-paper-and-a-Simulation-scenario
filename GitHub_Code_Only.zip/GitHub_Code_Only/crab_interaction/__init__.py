"""Strategy-conditioned interaction experiments, separate from legacy results."""
