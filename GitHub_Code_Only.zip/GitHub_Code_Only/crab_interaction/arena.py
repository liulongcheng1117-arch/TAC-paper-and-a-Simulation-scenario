"""A public-map bottleneck foraging game and private reactive opponents.

This module is a high-level kinematic research model, not rigid-body physics.
All controllers use positions and PREVIOUS executed inputs. Random traits and
correlated disturbances are private; no controller receives a method identity.
"""

from dataclasses import dataclass

import numpy as np


@dataclass
class Arena:
    dt: float = 0.4
    horizon: int = 16
    steps: int = 125
    speed: float = 0.22
    radius: float = 0.18
    strategic: bool = True
    foods = np.array([[-1.6, 0.45], [1.6, 0.45]])
    # xmin,xmax,ymin,ymax; the northern recess is the passing bay.
    rocks = np.array([[-0.65, -0.30, 0.32, 1.05], [0.30, 0.65, 0.32, 1.05],
                      [-0.30, 0.30, 0.90, 1.05], [-0.65, 0.65, -1.7, -0.32]])

    def clearance(self, points):
        p = np.asarray(points)
        r = self.rocks
        d = np.maximum(np.maximum(r[:, [0, 2]] - p[..., None, :],
                                  p[..., None, :] - r[:, [1, 3]]), 0)
        obstacle = np.linalg.norm(d, axis=-1).min(-1)
        boundary = np.minimum(2.2 - np.abs(p[..., 0]), np.minimum(p[..., 1] + 1.7, 2.1 - p[..., 1]))
        return np.minimum(obstacle, boundary)


def bounded(vector, maximum):
    v = np.asarray(vector)
    return v * np.minimum(1, maximum / np.maximum(np.linalg.norm(v, axis=-1, keepdims=True), 1e-12))


def waypoint(p, side, route, offset=None):
    """Public collision-free route waypoints, evaluated for many candidates."""
    p = np.asarray(p)
    target = np.broadcast_to(np.array([side * 1.6, 0.45]), p.shape).copy()
    if offset is not None:
        target += offset
    unfinished = side * p[..., 0] < 0.9
    if route == "bypass":
        lane = 1.78 if side > 0 else 1.33
        target[unfinished] = [side * 0.96, lane]
        before = unfinished & (p[..., 1] < lane - 0.05)
        target[before] = [-side * 0.96, lane]
    else:
        target[unfinished] = [side * 0.96, 0]
        before = unfinished & (side * p[..., 0] < -0.94)
        target[before] = [-side * 0.90, 0]
        pocket = unfinished & (np.abs(p[..., 0]) < 0.3) & (p[..., 1] > 0.10)
        target[pocket] = [0, 0]
    return target


def candidates(position, previous, side, cfg, continuation=None):
    labels = [(r, w, s) for r in ("direct", "bypass") for w in (0, 4)
              for s in range(3)] + [("retreat", 12, 1), ("hold", cfg.horizon, 1)]
    stations = np.array([[-0.12 * side, -0.43], [-0.30 * side, 0], [-0.12 * side, 0.43]])
    routes = np.array([r for r, _, _ in labels])
    waits = np.array([w for _, w, _ in labels])
    offsets = stations[[s for _, _, s in labels]]
    p, u = (np.broadcast_to(a, (len(labels), 2)).copy() for a in (position, previous))
    output = np.empty((len(labels), cfg.horizon, 2))
    for k in range(cfg.horizon):
        target = np.empty_like(p)
        for route in ("direct", "bypass"):
            mask = (routes == route) | ((routes == "retreat") if route == "direct" else False) | (routes == "hold")
            target[mask] = waypoint(p[mask], side, route, offsets[mask])
        retreating = (routes == "retreat") & (k < waits)
        target[retreating] = [-side * 0.98, -0.62]
        pocket = retreating & (np.abs(p[:, 0]) < 0.25)
        target[pocket] = [0, 0.64]
        desired = bounded((target - p) / cfg.dt, cfg.speed)
        desired[((routes != "retreat") & (k < waits)) | (routes == "hold")] = 0
        u = u + bounded(desired - u, 0.10)
        p = p + cfg.dt * u
        output[:, k] = u
    if continuation is not None:
        output = np.concatenate((output, np.r_[continuation[1:], continuation[-1:]][None]), axis=0)
        labels.append(("continuation", 0, -1))
    return np.asarray(output), labels


def stage_cost(own, peers, controls, cfg):
    """Common realized cost; Gaussian sharing, congestion, effort, proximity.

Own goal progress is a TERMINAL term, not silently added here. The regularizer
is NEVER added to the realized comparison cost.
    """
    food = cfg.foods[1]
    a = np.exp(-np.sum((own - food)**2, axis=-1) / (2 * 0.60**2))
    b = np.exp(-np.sum((peers - food)**2, axis=-1) / (2 * 0.60**2)).sum(-1)
    distance2 = np.sum((own[..., None, :] - peers)**2, axis=-1)
    conflict = np.exp(-distance2 / (2 * 0.24**2)).sum(-1)
    return 0.08 + 0.15 * np.sum(controls**2, axis=-1) + 12 * conflict - 3.0 * a / (1 + b)


def lipschitz(own, cfg, opponents):
    """Global Euclidean opponent-state Lipschitz bound in METRES.

    Each peer gradient: food-sharing <=3*a*exp(-1/2)/.60;
proximity <=12*exp(-1/2)/.24. Joint norm <=sqrt(n-1)*bound.
The nonlinear objective makes E ell + L Theta an upper-bound surrogate.
    """
    a = np.exp(-np.sum((own - cfg.foods[1])**2, axis=-1) / (2 * 0.60**2))
    return np.sqrt(opponents) * np.exp(-0.5) * (3 * a / 0.60 + 12 / 0.24)


class Opponents:
    def __init__(self, seed, positions, cfg, reactive=True):
        rng = np.random.default_rng(np.random.SeedSequence([seed, 1931]))
        n = len(positions)
        self.sides = np.where(positions[:, 0] < 0, 1, -1)
        self.boldness = np.clip(rng.beta(0.65, 0.65, n), 0.04, 0.96)
        self.speeds = rng.uniform(0.14, cfg.speed, n)
        self.vigilance = rng.uniform(1.15, 1.85, n)
        self.delays = rng.integers(0, 3, n)
        self.inertia = rng.uniform(0.25, 0.6, n)
        self.bypass = rng.random(n) < 0.2
        angle = rng.uniform(0, 2 * np.pi, n)
        self.food_offsets = np.c_[np.cos(angle), np.sin(angle)] * rng.uniform(0.2, 0.43, (n, 1))
        self.food_offsets[:, 0] = np.clip(self.food_offsets[:, 0], -0.30, 0.30)
        self.history = []
        self.noise = np.zeros((n, 2))
        self.seed, self.cfg, self.reactive = seed, cfg, reactive

    def choose(self, tick, positions, previous):
        p, cfg = np.asarray(positions), self.cfg
        self.history.append((p.copy(), previous.copy()))
        self.history = self.history[-4:]
        # Random stream indexed by time, not number of queries/method decisions.
        rng = np.random.default_rng(np.random.SeedSequence([self.seed, tick, 771]))
        self.noise = 0.85 * self.noise + rng.uniform(-0.004, 0.004, p.shape)
        output = np.zeros_like(p)
        for j in range(1, len(p)):
            obs, last = self.history[max(0, len(self.history) - 1 - self.delays[j])]
            side = self.sides[j]
            route = "bypass" if self.bypass[j] else "direct"
            target = waypoint(p[j:j + 1], side, route, self.food_offsets[j])[0]
            desired = bounded((target - p[j]) / cfg.dt, self.speeds[j])
            if self.reactive:
                others = [i for i in range(len(p)) if i != j]
                delta = obs[others] - obs[j]
                distance = np.linalg.norm(delta, axis=1)
                opposite = (self.sides[others] != side).astype(float)
                in_lane = np.exp(-((obs[others, 1] - obs[j, 1]) / 0.5)**2)
                ahead = 1 / (1 + np.exp(np.clip(-8 * delta[:, 0] * side, -40, 40)))
                approach = np.clip(-last[others, 0] * side / cfg.speed, -1, 1)
                activation = 1 / (1 + np.exp(np.clip(6 * (distance - self.vigilance[j]), -40, 40)))
                assertion = np.clip(0.25 + 0.75 * approach, 0, 1)
                challenge = np.max(opposite * in_lane * ahead * activation * assertion)
                yield_fraction = np.clip((1 - self.boldness[j]) * 1.5 * challenge, 0, 1)
                # Cautious animals back away from an observed committed approach.
                retreat = np.array([-side * 0.10, 0])
                desired = (1 - yield_fraction) * desired + yield_fraction * retreat
                if cfg.strategic:
                    # An unknown, bounded smooth RESPONSE LAW, not IID actions.
                    # Hesitation invites entry; observed commitment makes a shy
                    # opponent retreat, whereas a bold opponent keeps advancing.
                    commitment = 0.85 * np.maximum(approach, 0) + 0.35 / (1 + np.exp(np.clip(
                        -6 * (abs(obs[j, 0]) - np.abs(obs[others, 0])), -40, 40)))
                    attention = opposite * in_lane * ahead * activation
                    response = np.tanh(8 * (0.2 + 1.2 * self.boldness[j] - commitment))
                    active = int(np.argmax(attention))
                    factor = 1 + attention[active] * (response[active] - 1)
                    desired = bounded((target - p[j]) / cfg.dt, self.speeds[j]) * factor
                # Public, local crowd avoidance, identical across focal methods.
                repulsion = np.sum(delta / np.maximum(distance[:, None], 1e-6)
                                   * np.exp(-(distance[:, None] / 0.34)**2), axis=0)
                desired -= 0.12 * repulsion
            desired += self.noise[j]
            desired = self.inertia[j] * previous[j] + (1 - self.inertia[j]) * desired
            output[j] = previous[j] + bounded(bounded(desired, self.speeds[j]) - previous[j], 0.10)
        return output


def initial_positions(seed, n):
    rng = np.random.default_rng(np.random.SeedSequence([seed, 941]))
    # Opposing fronts plus followers; >=.52m spacing before jitter.
    slots = [[-1.36, -0.03], [1.30, 0.04], [1.45, -0.62], [-1.55, -0.63],
             [1.45, 0.70], [-1.55, 0.70], [1.98, -0.62], [-2.0, -0.63],
             [1.98, 0.04], [-2.0, -0.03], [1.98, 0.70], [-2.0, 0.70]]
    if not 2 <= n <= len(slots):
        raise ValueError("Use 2..12 robots")
    return np.asarray(slots[:n]) + rng.uniform(-0.025, 0.025, (n, 2))
