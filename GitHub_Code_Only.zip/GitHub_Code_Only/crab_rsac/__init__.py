"""Independent recurrent SAC experiments; approved CV-MPC code is read-only."""
