"""Unseen threat-response polarity, independent of controller identity."""

import hashlib

import numpy as np

from . import native
from .scenarios import SwitchingPopulation
from .train import ROOT


class ChallengePopulation(SwitchingPopulation):
    """A bold challenger counters a threatening claw instead of yielding."""

    def choose(self, tick, x, previous):
        out = super().choose(tick, x, previous)
        for j in range(1, len(x)):
            if self.bold[j] < .8:
                continue
            distance = np.linalg.norm(x[:, :2] - x[j, :2], axis=-1)
            distance[j] = np.inf
            other = int(distance.argmin())
            d = distance[other]
            if d > .95:
                continue
            toward = (x[other, :2] - x[j, :2]) / max(d, .05)
            threat = x[other, 3] * (.4 + x[other, 4])
            approach = float(np.dot(previous[other, :2] - previous[j, :2], -toward))
            response = np.tanh(4 * (self.yield_at[j] - threat + .35 * approach))
            attention = np.exp(-(d / .8)**2)
            strength = (.10 + .05 * self.bold[j]) * self.response_gain[j]
            # Reverse ONLY the existing private threat-response contribution.
            # Geometry, route, attack FSM, timing, limits and scoring stay shared.
            out[j, :2] -= 2 * attention * strength * response * toward
        return np.clip(out, -self.cfg.limits, self.cfg.limits)


def scenario_fingerprint():
    return {"crab_rsac/challenge.py": hashlib.sha256((ROOT / "crab_rsac/challenge.py").read_bytes()).hexdigest()}


def main():
    native.SwitchingPopulation = ChallengePopulation
    original = native.fingerprint
    native.fingerprint = lambda: {**original(), **scenario_fingerprint()}
    native.main()


if __name__ == "__main__":
    main()
