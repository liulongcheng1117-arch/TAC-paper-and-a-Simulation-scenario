"""Fast PRETRAINING environment. No result here is a native-physics result."""

from types import SimpleNamespace

import numpy as np

from crab_defense.policy3d import feature_objective, features, predict_step
from crab_defense.randomized_strategy import random_positions
from crab_defense.territorial_strategy import TerritorialPopulation
from crab_interaction.arena import Arena

from .interface import CFG, GOAL, Guidance, observation


def reward(x, successor, control, old_distance, new_distance, contact_loss=0., risk_gain=1.):
    phi = features(successor[0], successor[1:], GOAL)
    cost = float(feature_objective(successor[0], phi, control, GOAL)[0])
    dense_risk = float(np.sum(phi[..., 1:] * [12., 3., 3.]))
    # Constant training normalization; original evaluation scores stay unscaled.
    return .1 * float(-CFG.dt * (cost + (risk_gain - 1) * dense_risk) - contact_loss + 2 * (old_distance - new_distance))


class FastEnv:
    fidelity = "kinematic randomized pretraining approximation, not native evaluation"

    def __init__(self, seed, steps=300):
        self.steps = steps
        self.reset(seed)

    def reset(self, seed):
        self.seed = int(seed)
        self.rng = np.random.default_rng(np.random.SeedSequence([seed, 4197]))
        p = random_positions(seed)
        self.x = np.zeros((4, 6))
        self.x[:, :2] = p
        self.x[:, 2] = self.rng.uniform(-np.pi, np.pi, 4)
        self.x[:, 3:] = self.rng.uniform([.35, 0, .35], [.8, .08, .8], (4, 3))
        world = SimpleNamespace(configs=[None] * 4, positions=np.c_[p, np.full(4, .11)])
        self.population = TerritorialPopulation(seed, world, CFG)
        self.gain = self.rng.uniform(.45, 1., (4, 6))
        self.gain[:, :2] = self.rng.uniform(.83, 1., (4, 2))
        self.risk_gain = self.rng.uniform(1., 2.)
        self.previous = np.zeros((4, 6))
        self.guide, self.tick, self.return_, self.benefit = Guidance(), 0, 0., 0.
        self.ref = self.guide.reference(self.x)
        return observation(self.x, self.previous, self.ref, self.guide, self.tick, self.steps)

    def step(self, action):
        x = self.x
        distance = float(self.guide.nav.distance(x[0, :2]))
        controls = self.population.choose(self.tick, x, self.previous)
        controls[0] = self.guide.control(action, x, self.ref)
        successor = predict_step(x, controls * self.gain, CFG)
        # Declared coarse body volume for pretraining only. Native evaluation
        # never uses this projection or treats it as a measured contact.
        for _ in range(3):
            for i in range(4):
                for j in range(i):
                    delta = successor[i, :2] - successor[j, :2]
                    length = np.linalg.norm(delta)
                    push = max(.32 - length, 0) * delta / max(length, 1e-6) / 2
                    successor[i, :2] += push
                    successor[j, :2] -= push
        for j in range(4):
            if Arena().clearance(successor[j, :2]) < .20:
                successor[j, :2] = x[j, :2]
        # Domain-randomized tracking error, not a simulated physical contact.
        successor[:, 3:] = np.clip(successor[:, 3:] + self.rng.normal(0, .004, (4, 3)), 0, 1)
        food = np.exp(-np.sum((successor[:, :2] - GOAL)**2, -1) / (2 * .6**2))
        self.benefit += CFG.dt * 3 * food[0] / (1 + food[1:].sum())
        after_distance = float(self.guide.nav.distance(successor[0, :2]))
        r = reward(x, successor, controls[0], distance, after_distance, risk_gain=self.risk_gain)
        self.return_ += r
        self.x, self.previous = successor, controls
        self.tick += 1
        self.ref = self.guide.reference(self.x)
        obs = observation(self.x, self.previous, self.ref, self.guide, self.tick, self.steps)
        return obs, r, self.tick >= self.steps, {"return": self.return_, "benefit": float(self.benefit),
                 "distance": float(np.linalg.norm(successor[0, :2] - GOAL)), "fidelity": self.fidelity}
