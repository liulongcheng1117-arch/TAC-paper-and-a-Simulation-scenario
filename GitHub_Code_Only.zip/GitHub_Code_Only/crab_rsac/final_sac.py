"""Final task-matched, full-authority recurrent SAC experiment."""

import hashlib
import sys

import numpy as np

from crab_interaction.arena import Arena

from .envs import FastEnv as OriginalFastEnv
from .envs import reward as physical_reward
from .full_authority import Guidance
from .full_authority import source as authority_source
from .interface import CFG, GOAL
from .train import ROOT

RUNS = ROOT / ".cache/rsac_final_research"


def task_reward(x, successor, control, old_distance, new_distance, contact_loss=0., risk_gain=1.):
    # Exact nominal risk weights, not randomized risk preferences and no LTheta.
    base = physical_reward(x, successor, control, old_distance, new_distance, contact_loss, 1.)
    navigation = 2 * max(new_distance - .25, 0)
    terrain = 35 * max(.23 - float(Arena().clearance(successor[0, :2])), 0)**2
    radial2 = float(np.sum((successor[0, :2] - GOAL)**2))
    keeping = 8 * radial2 + 2 * float(np.sum(control[:2]**2)) if radial2 < .44**2 else 0.
    return base - .1 * CFG.dt * (navigation + terrain + keeping)


class FastEnv(OriginalFastEnv):
    def step(self, action):
        obs, r, done, info = super().step(action)
        if done:
            terminal = .1 * max(float(self.guide.nav.distance(self.x[0, :2])) - .25, 0) / .18
            r -= terminal
            self.return_ -= terminal
            info["return"] = self.return_
        return obs, r, done, info


def source():
    path = ROOT / "crab_rsac/final_sac.py"
    return {**authority_source(), str(path.relative_to(ROOT)): hashlib.sha256(path.read_bytes()).hexdigest()}


def main():
    mode = sys.argv[1]
    sys.argv.pop(1)
    if mode == "train":
        from . import envs, train
        envs.Guidance, envs.reward = Guidance, task_reward
        train.FastEnv, train.RUNS = FastEnv, RUNS
        original = train.sources
        train.sources = lambda: {**original(), **source()}
        train.main()
    elif mode == "native":
        from . import native
        native.Guidance, native.RUNS, native.reward = Guidance, RUNS, task_reward
        original, replay = native.fingerprint, native.save_replay
        native.fingerprint = lambda: {**original(), **source()}

        def terminal_replay(data, path):
            replay(data, path)
            with np.load(path) as archive:
                arrays = {name: archive[name] for name in archive.files}
            final = np.asarray(data["trace"][-1]["state"])
            arrays["rewards"][-1] -= .1 * max(float(native.ACTIVE.guide.nav.distance(final[0, :2])) - .25, 0) / .18
            np.savez_compressed(path, **arrays)

        native.save_replay = terminal_replay
        if "--scenario" in sys.argv and sys.argv[sys.argv.index("--scenario") + 1] == "switching":
            from .challenge import ChallengePopulation, scenario_fingerprint
            native.SwitchingPopulation = ChallengePopulation
            previous = native.fingerprint
            native.fingerprint = lambda: {**previous(), **scenario_fingerprint()}
        native.main()
    elif mode == "finetune":
        from . import finetune
        finetune.RUNS = RUNS
        finetune.main()
    else:
        raise ValueError(mode)


if __name__ == "__main__":
    main()
