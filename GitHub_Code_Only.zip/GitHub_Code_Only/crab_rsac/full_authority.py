"""Final baseline: the policy can command every permitted body velocity.

The earlier narrow residual is kept as an internal integration diagnostic only.
This version gets full authority to reverse away from the navigation reference.
"""

import hashlib
import sys

import numpy as np

from crab_interaction.arena import Arena, bounded

from .interface import CFG, GOAL
from .interface import Guidance as OriginalGuidance
from .train import ROOT

RUNS = ROOT / ".cache/rsac_full_research"


class Guidance(OriginalGuidance):
    def control(self, action, x, ref):
        out = super().control(action, x, ref)
        a = np.clip(np.asarray(action), -1, 1)
        # At either mode the reachable set contains the entire permitted disk.
        v = bounded(ref + (.12 if self.hold else .36) * a[:2], .06 if self.hold else .18)
        p = x[0, :2]
        if self.hold:
            proposed = p + CFG.dt * v - GOAL
            if np.linalg.norm(proposed) > .365:
                v = bounded((GOAL + bounded(proposed, .365) - p) / CFG.dt, .06)
        threshold = min(.225, float(Arena().clearance(p)) - .005)
        for _ in range(4):
            line = p + np.linspace(0, CFG.dt, 5)[:, None] * v
            if Arena().clearance(line).min() >= threshold:
                break
            v *= .5
        out[:2] = v
        return out


def source():
    path = ROOT / "crab_rsac/full_authority.py"
    return {str(path.relative_to(ROOT)): hashlib.sha256(path.read_bytes()).hexdigest()}


def main():
    mode = sys.argv[1]
    sys.argv.pop(1)
    if mode == "train":
        from . import envs, train
        envs.Guidance, train.RUNS = Guidance, RUNS
        original = train.sources
        train.sources = lambda: {**original(), **source()}
        train.main()
    elif mode == "native":
        from . import native
        native.Guidance, native.RUNS = Guidance, RUNS
        original = native.fingerprint
        native.fingerprint = lambda: {**original(), **source()}
        if "--scenario" in sys.argv and sys.argv[sys.argv.index("--scenario") + 1] == "switching":
            from .challenge import ChallengePopulation, scenario_fingerprint
            native.SwitchingPopulation = ChallengePopulation
            previous = native.fingerprint
            native.fingerprint = lambda: {**previous(), **scenario_fingerprint()}
        native.main()
    elif mode == "finetune":
        from . import finetune
        finetune.RUNS = RUNS
        finetune.main()
    else:
        raise ValueError(mode)


if __name__ == "__main__":
    main()
