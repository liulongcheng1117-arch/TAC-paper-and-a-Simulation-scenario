"""Public observations and declared shared-map guidance for recurrent SAC.

The actor controls body residual velocities, yaw residual and three continuous
claw targets. Map guidance contains no opponent model or interaction decision.
"""

import numpy as np
from scipy.ndimage import distance_transform_edt

from crab_defense.navigation3d import GoalNavigation
from crab_defense.policy3d import NativeConfig, hand_point, wrap
from crab_interaction.arena import Arena, bounded

CFG = NativeConfig()
GOAL = np.array([1.6, .45])
OBS_DIM, ACT_DIM = 68, 6
_MAP = None


def map_data():
    global _MAP
    if _MAP is not None:
        return _MAP
    nav = GoalNavigation(1)
    grid = np.indices(tuple(nav.shape)).transpose(1, 2, 0)
    best, cost = grid.copy(), np.full(tuple(nav.shape), np.inf)
    for di, dj in nav.moves:
        a = np.clip(grid[..., 0] + di, 0, nav.shape[0] - 1)
        b = np.clip(grid[..., 1] + dj, 0, nav.shape[1] - 1)
        valid = nav.free[a, b]
        if di and dj:
            valid &= nav.free[a, grid[..., 1]] & nav.free[grid[..., 0], b]
        value = np.where(valid, nav.goal_field[a, b], np.inf)
        use = value < cost
        best[use] = np.stack((a, b), -1)[use]
        cost[use] = value[use]
    near = distance_transform_edt(~nav.free, return_distances=False, return_indices=True)
    next1 = best.copy()
    next3 = best.copy()
    for _ in range(2):
        next3 = best[next3[..., 0], next3[..., 1]]
    _MAP = nav, nav.lo + nav.resolution * next1, nav.lo + nav.resolution * next3, near
    return _MAP


class Guidance:
    """Own-map feasibility / goal holding only, shared aid explicitly reported."""

    def __init__(self):
        self.nav, self.next1, self.next3, self.near = map_data()
        self.hold = False

    def reference(self, x):
        p = x[0, :2]
        radial = np.linalg.norm(p - GOAL)
        if radial < .34:
            self.hold = True
        elif radial > .44:
            self.hold = False
        if self.hold:
            return bounded(.6 * (GOAL - p), .06)
        cell = tuple(self.nav.cell(p))
        if not self.nav.free[cell]:
            cell = tuple(self.near[:, cell[0], cell[1]])
        ref = bounded((self.next3[cell] - p) / .5, .18)
        if radial < .28:
            ref = bounded(1.2 * (GOAL - p), .12)
        line = p + np.linspace(0, CFG.dt, 5)[:, None] * ref
        if Arena().clearance(line).min() < min(.225, float(Arena().clearance(p)) - .005):
            ref = bounded((self.next1[cell] - p) / .5, .18)
        return ref

    def control(self, action, x, ref):
        a = np.clip(np.asarray(action), -1, 1)
        out = np.zeros(6)
        out[:2] = ref + (.065 if self.hold else .10) * a[:2]
        out[:2] = bounded(out[:2], .06 if self.hold else .18)
        p = x[0, :2]
        if self.hold:
            proposed = p + CFG.dt * out[:2] - GOAL
            if np.linalg.norm(proposed) > .365:
                out[:2] = (GOAL + bounded(proposed, .365) - p) / CFG.dt
                out[:2] = bounded(out[:2], .06)
        line = p + np.linspace(0, CFG.dt, 5)[:, None] * out[:2]
        threshold = min(.225, float(Arena().clearance(p)) - .005)
        for _ in range(4):
            if Arena().clearance(line).min() >= threshold:
                break
            out[:2] *= .5
            line = p + np.linspace(0, CFG.dt, 5)[:, None] * out[:2]
        nearest = 1 + np.argmin(np.linalg.norm(x[1:, :2] - p, axis=-1))
        bearing = np.arctan2(*(x[nearest, :2] - p)[::-1])
        out[2] = 2 * wrap(bearing - x[0, 2]) + .3 * a[2]
        target = .5 * (a[3:] + 1)
        out[3:] = (target - x[0, 3:]) / CFG.dt
        return np.clip(out, -CFG.limits, CFG.limits)


def observation(x, previous, ref, guidance, tick, steps=300):
    own = x[0]
    values = [own[:2] / 2, [np.cos(own[2]), np.sin(own[2])], own[3:], previous[0] / CFG.limits,
              (GOAL - own[:2]) / 3, ref / .18,
              [float(guidance.nav.distance(own[:2])) / 5, float(guidance.hold), tick / steps]]
    hands = hand_point(x)
    for j in range(1, 4):
        values += [(x[j, :2] - own[:2]) / 2, [np.cos(x[j, 2]), np.sin(x[j, 2])], x[j, 3:],
                   previous[j] / CFG.limits, (hands[j] - hands[0]) / .5]
    result = np.clip(np.concatenate(values), -5, 5).astype(np.float32)
    assert result.shape == (OBS_DIM,)
    return result
