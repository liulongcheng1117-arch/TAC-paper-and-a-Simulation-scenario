"""Independent SAC implementation with separate actor/critic LSTMs.

Twin Q targets, tanh-Gaussian reparameterization, learned entropy temperature,
sequence replay and no-gradient burn-in follow recurrent off-policy SAC.
"""

import copy
import json
from dataclasses import asdict, dataclass

import numpy as np
import torch
from torch import nn
from torch.nn import functional as F

from .interface import ACT_DIM, OBS_DIM


@dataclass
class Config:
    obs_dim: int = OBS_DIM
    act_dim: int = ACT_DIM
    hidden: int = 64
    gamma: float = .99
    tau: float = .005
    lr: float = .0003
    burn: int = 8
    learn: int = 16
    batch: int = 32


class Memory(nn.Module):
    def __init__(self, cfg):
        super().__init__()
        self.embed = nn.Sequential(nn.Linear(cfg.obs_dim + cfg.act_dim, cfg.hidden), nn.Tanh())
        self.rnn = nn.LSTM(cfg.hidden, cfg.hidden, batch_first=True)

    def forward(self, obs, previous, state=None):
        return self.rnn(self.embed(torch.cat((obs, previous), -1)), state)

    def contexts(self, obs, previous, burn):
        state = None
        if burn:
            with torch.no_grad():
                _, state = self(obs[:, :burn], previous[:, :burn])
        return self(obs[:, burn:], previous[:, burn:], state)[0]


class Actor(nn.Module):
    def __init__(self, cfg):
        super().__init__()
        self.memory = Memory(cfg)
        self.head = nn.Sequential(nn.Linear(cfg.hidden + cfg.obs_dim, 128), nn.SiLU(), nn.Linear(128, 128), nn.SiLU())
        self.mean, self.log_std = nn.Linear(128, cfg.act_dim), nn.Linear(128, cfg.act_dim)
        nn.init.normal_(self.mean.weight, std=.005)
        nn.init.zeros_(self.mean.bias)
        nn.init.zeros_(self.log_std.weight)
        nn.init.constant_(self.log_std.bias, -1.5)

    def distribution(self, context, obs):
        h = self.head(torch.cat((context, obs), -1))
        return self.mean(h), self.log_std(h).clamp(-5, 1)

    def sample(self, context, obs, deterministic=False):
        mean, log_std = self.distribution(context, obs)
        raw = mean if deterministic else mean + log_std.exp() * torch.randn_like(mean)
        action = raw.tanh()
        log_prob = (-.5 * ((raw - mean) / log_std.exp())**2 - log_std - .5 * np.log(2 * np.pi)
                    - 2 * (np.log(2) - raw - F.softplus(-2 * raw))).sum(-1, keepdim=True)
        return action, log_prob


class Critic(nn.Module):
    def __init__(self, cfg):
        super().__init__()
        self.memory = Memory(cfg)
        width = cfg.hidden + cfg.obs_dim + cfg.act_dim
        self.q1 = nn.Sequential(nn.Linear(width, 128), nn.SiLU(), nn.Linear(128, 128), nn.SiLU(), nn.Linear(128, 1))
        self.q2 = nn.Sequential(nn.Linear(width, 128), nn.SiLU(), nn.Linear(128, 128), nn.SiLU(), nn.Linear(128, 1))

    def forward(self, context, obs, action):
        z = torch.cat((context, obs, action), -1)
        return self.q1(z), self.q2(z)


class Agent:
    def __init__(self, cfg=None, seed=0):
        self.cfg = cfg or Config()
        torch.manual_seed(seed)
        self.actor, self.critic = Actor(self.cfg), Critic(self.cfg)
        self.target = copy.deepcopy(self.critic).requires_grad_(False)
        self.actor_opt = torch.optim.Adam(self.actor.parameters(), lr=self.cfg.lr)
        self.critic_opt = torch.optim.Adam(self.critic.parameters(), lr=self.cfg.lr)
        self.log_alpha = nn.Parameter(torch.tensor(np.log(.03), dtype=torch.float32))
        self.alpha_opt = torch.optim.Adam([self.log_alpha], lr=.0001)
        self.updates = 0

    @torch.no_grad()
    def act(self, obs, previous, state=None, deterministic=False):
        o, p = (torch.as_tensor(v, dtype=torch.float32)[:, None] for v in (obs, previous))
        context, state = self.actor.memory(o, p, state)
        a, _ = self.actor.sample(context, o, deterministic)
        return a[:, 0].numpy(), state

    def update(self, batch):
        c = self.cfg
        obs, previous, actions, rewards, dones = (torch.as_tensor(batch[k], dtype=torch.float32) for k in ("obs", "previous", "actions", "rewards", "dones"))
        o, acts = obs[:, c.burn:], actions[:, c.burn:]
        with torch.no_grad():
            ac = self.actor.memory.contexts(obs, previous, c.burn)
            na, lp = self.actor.sample(ac[:, 1:], o[:, 1:])
            tc = self.target.memory.contexts(obs, previous, c.burn)
            tq1, tq2 = self.target(tc[:, 1:], o[:, 1:], na)
            target = rewards[:, c.burn:] + c.gamma * (1 - dones[:, c.burn:]) * (torch.minimum(tq1, tq2) - self.log_alpha.exp() * lp)
        context = self.critic.memory.contexts(obs, previous, c.burn)
        q1, q2 = self.critic(context[:, :-1], o[:, :-1], acts)
        critic_loss = F.smooth_l1_loss(q1, target) + F.smooth_l1_loss(q2, target)
        self.critic_opt.zero_grad(set_to_none=True)
        critic_loss.backward()
        nn.utils.clip_grad_norm_(self.critic.parameters(), 10)
        self.critic_opt.step()
        self.critic.requires_grad_(False)
        with torch.no_grad():
            context = self.critic.memory.contexts(obs, previous, c.burn)[:, :-1]
        actor_context = self.actor.memory.contexts(obs, previous, c.burn)[:, :-1]
        a, logp = self.actor.sample(actor_context, o[:, :-1])
        q1, q2 = self.critic(context, o[:, :-1], a)
        actor_loss = (self.log_alpha.exp().detach() * logp - torch.minimum(q1, q2)).mean()
        self.actor_opt.zero_grad(set_to_none=True)
        actor_loss.backward()
        nn.utils.clip_grad_norm_(self.actor.parameters(), 5)
        self.actor_opt.step()
        self.critic.requires_grad_(True)
        alpha_loss = -(self.log_alpha * (logp.detach() - c.act_dim)).mean()
        self.alpha_opt.zero_grad(set_to_none=True)
        alpha_loss.backward()
        self.alpha_opt.step()
        with torch.no_grad():
            self.log_alpha.clamp_(-8, 0)
            for destination, source in zip(self.target.parameters(), self.critic.parameters()):
                destination.lerp_(source, c.tau)
        self.updates += 1
        return {"critic_loss": float(critic_loss.detach()), "actor_loss": float(actor_loss.detach()),
                "alpha": float(self.log_alpha.exp().detach()), "q": float(q1.detach().mean())}

    def save(self, path, metadata):
        path.parent.mkdir(parents=True, exist_ok=True)
        payload = {"config": asdict(self.cfg), "actor": self.actor.state_dict(), "critic": self.critic.state_dict(),
                   "target": self.target.state_dict(), "log_alpha": self.log_alpha.detach(), "updates": self.updates,
                   "actor_optimizer": self.actor_opt.state_dict(), "critic_optimizer": self.critic_opt.state_dict(),
                   "alpha_optimizer": self.alpha_opt.state_dict(), "metadata": metadata}
        torch.save(payload, path)
        path.with_suffix(".json").write_text(json.dumps(metadata, indent=2), "utf-8")

    @classmethod
    def load(cls, path, resume=False):
        p = torch.load(path, map_location="cpu", weights_only=False)
        model = cls(Config(**p["config"]))
        model.actor.load_state_dict(p["actor"])
        model.critic.load_state_dict(p["critic"])
        model.target.load_state_dict(p["target"])
        model.log_alpha.data.copy_(p["log_alpha"])
        model.updates = p["updates"]
        if resume:
            model.actor_opt.load_state_dict(p["actor_optimizer"])
            model.critic_opt.load_state_dict(p["critic_optimizer"])
            model.alpha_opt.load_state_dict(p["alpha_optimizer"])
        return model


class Replay:
    def __init__(self, seed=0, capacity=500000):
        self.episodes, self.count, self.capacity = [], 0, capacity
        self.rng = np.random.default_rng(seed)

    def add(self, obs, actions, rewards, dones):
        ep = {"obs": np.asarray(obs, np.float32), "actions": np.asarray(actions, np.float32),
              "rewards": np.asarray(rewards, np.float32)[:, None], "dones": np.asarray(dones, np.float32)[:, None]}
        assert len(ep["obs"]) == len(ep["actions"]) + 1
        ep["previous"] = np.concatenate((np.zeros((1, ACT_DIM), np.float32), ep["actions"]), 0)
        self.episodes.append(ep)
        self.count += len(ep["actions"])
        while self.count > self.capacity and len(self.episodes) > 1:
            self.count -= len(self.episodes.pop(0)["actions"])

    def sample(self, cfg):
        length = cfg.burn + cfg.learn
        eligible = [e for e in self.episodes if len(e["actions"]) >= length]
        batch = {k: [] for k in ("obs", "previous", "actions", "rewards", "dones")}
        for _ in range(cfg.batch):
            ep = eligible[self.rng.integers(len(eligible))]
            start = self.rng.integers(len(ep["actions"]) - length + 1)
            for key, values in batch.items():
                extra = int(key in ("obs", "previous"))
                values.append(ep[key][start:start + length + extra])
        return {k: np.stack(v) for k, v in batch.items()}
