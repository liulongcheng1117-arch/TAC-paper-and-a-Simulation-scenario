"""R-SAC on original native physics, separate outputs and unchanged scoring."""

import argparse
import hashlib
from pathlib import Path
from time import perf_counter

import mujoco
import numpy as np
import torch
from PIL import Image, ImageDraw, ImageFont
from threadpoolctl import threadpool_limits

from crab_defense.randomized_strategy import engine as native_engine
from crab_defense.randomized_strategy import fingerprint as approved_fingerprint

from .envs import reward
from .interface import ACT_DIM, CFG, GOAL, Guidance, observation
from .learning import Agent
from .scenarios import SwitchingPopulation
from .train import ROOT, RUNS

CHECKPOINT, AGENT, ACTIVE, STOCHASTIC = None, None, None, False


class NoOnlineWeights:
    def observe(self, *_args):
        pass


class ActorPolicy:
    def __init__(self, method, players, side, cfg, calibration=None):
        assert players == 4 and side == 1
        self.goal, self.guide, self.model = GOAL, Guidance(), NoOnlineWeights()
        self.state, self.previous_action, self.packet = None, np.zeros((1, ACT_DIM), np.float32), None
        global ACTIVE
        ACTIVE = self

    def choose(self, tick, x, previous):
        began = perf_counter()
        ref = self.guide.reference(x)
        obs = observation(x, previous, ref, self.guide, tick)
        a, self.state = AGENT.act(obs[None], self.previous_action, self.state, deterministic=not STOCHASTIC)
        command = self.guide.control(a[0], x, ref)
        self.previous_action = a.copy()
        elapsed = (perf_counter() - began) * 1000
        self.packet = {"rsac_observation": obs.tolist(), "rsac_raw_action": a[0].tolist(),
                       "executed_control": command.tolist(), "decision_ms": elapsed,
                       "memory_norm": float(self.state[0].norm()), "choice": ["r_sac", 0, 0, 0],
                       "controller": "LSTM actor plus declared public own-map guidance; no GP/DRO/opponent labels"}
        return command, dict(self.packet)


def fingerprint():
    result = approved_fingerprint()
    for name in ("interface.py", "envs.py", "learning.py", "native.py", "scenarios.py"):
        path = ROOT / "crab_rsac" / name
        result[str(path.relative_to(ROOT))] = hashlib.sha256(path.read_bytes()).hexdigest()
    if CHECKPOINT is not None:
        result[str(CHECKPOINT.relative_to(ROOT))] = hashlib.sha256(CHECKPOINT.read_bytes()).hexdigest()
    return result


def picture(world, method, elapsed, benefit, goal_dwell=0.):
    world.render(1280, 720)
    camera = mujoco.MjvCamera()
    camera.lookat[:] = [0, .15, .05]
    camera.distance, camera.azimuth, camera.elevation = 5., 105., -57.
    option = mujoco.MjvOption()
    option.geomgroup[1] = 0
    world._renderer.update_scene(world.data, camera=camera, scene_option=option)
    frame = world._renderer.render()
    canvas = Image.new("RGB", (1728, 832), "#101b2a")
    canvas.paste(Image.fromarray(frame), (0, 112))
    draw = ImageDraw.Draw(canvas)
    title = ImageFont.truetype("C:/Windows/Fonts/msyh.ttc", 25)
    font = ImageFont.truetype("C:/Windows/Fonts/msyh.ttc", 19)
    small = ImageFont.truetype("C:/Windows/Fonts/msyh.ttc", 16)
    draw.text((18, 12), f"原版三维交互 | R-SAC + LSTM | {elapsed:.1f}s", font=title, fill="white")
    distance = np.linalg.norm(world.positions[0, :2] - GOAL)
    draw.text((18, 54), f"蓝蟹距目标 {distance:.2f}m   稳定停留 {goal_dwell:.1f}s   受击 {world.ledger.hit_count[0]}   被夹 {world.ledger.grasp_count[0]}", font=font, fill="#d3e1f2")
    draw.text((18, 84), "相同公开观测、原版关节和真实接触计分 | 强化学习决策、共享公共地图导航", font=small, fill="#bdcfe3")
    draw.rectangle((1280, 0, 1728, 832), fill="#152235")
    draw.text((1300, 24), "循环强化学习策略", font=title, fill="white")
    if ACTIVE and ACTIVE.packet:
        p = ACTIVE.packet
        lines = ["LSTM利用公开历史更新记忆", "Actor直接输出连续动作", "", f"本次决策耗时 {p['decision_ms']:.2f} ms",
                 f"记忆状态范数 {p['memory_norm']:.2f}", "", "实际执行的高层控制量"]
        labels = ("前后速度", "侧向速度", "钳子朝向变化", "伸展变化", "闭合变化", "高度变化")
        lines += [f"{label}  {v:+.3f}" for label, v in zip(labels, p["executed_control"])]
        lines += ["", "网络参数在评估中保持固定", "记忆状态在本回合内持续更新", "", "最终得分来自原版物理接触"]
        for i, text in enumerate(lines):
            draw.text((1300, 90 + i * 34), text, font=font if i < 7 else small, fill="#c8d9ed")
    return np.asarray(canvas)


def save_replay(data, path):
    rows = data["trace"]
    obs = [r["decision"]["rsac_observation"] for r in rows]
    final = np.asarray(rows[-1]["state"])
    guide = ACTIVE.guide
    ref = guide.reference(final)
    obs.append(observation(final, np.asarray(rows[-1]["control"]), ref, guide, len(rows)).tolist())
    actions = [r["decision"]["rsac_raw_action"] for r in rows]
    before = np.asarray(data["physics"]["initialization"]["initial_public_state"])
    old_loss, rewards = 0., []
    for r in rows:
        successor, control = np.asarray(r["state"]), np.asarray(r["control"])
        new_loss = r["contact_loss"][0]
        rewards.append(reward(before, successor, control[0], float(guide.nav.distance(before[0, :2])),
                              float(guide.nav.distance(successor[0, :2])), new_loss - old_loss))
        before, old_loss = successor, new_loss
    np.savez_compressed(path, obs=np.asarray(obs, np.float32), actions=np.asarray(actions, np.float32),
                        rewards=np.asarray(rewards, np.float32), dones=np.r_[np.zeros(len(rows) - 1), 1].astype(np.float32))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--checkpoint", required=True)
    parser.add_argument("--seed", type=int, default=80000)
    parser.add_argument("--count", type=int, default=1)
    parser.add_argument("--seconds", type=float, default=120)
    parser.add_argument("--tag", default="validation")
    parser.add_argument("--record", action="store_true")
    parser.add_argument("--stochastic", action="store_true")
    parser.add_argument("--scenario", choices=("nominal", "switching"), default="nominal")
    args = parser.parse_args()
    global CHECKPOINT, AGENT, STOCHASTIC
    CHECKPOINT = Path(args.checkpoint).resolve()
    assert CHECKPOINT.is_relative_to(ROOT)
    torch.set_num_threads(1)
    AGENT = Agent.load(CHECKPOINT)
    STOCHASTIC = args.stochastic
    folder = RUNS / "native" / args.tag
    folder.mkdir(parents=True, exist_ok=True)
    runner = native_engine(False)
    runner.NativePolicy, runner.OUT, runner.fingerprint = ActorPolicy, folder, fingerprint
    if args.scenario == "switching":
        runner.ReactivePopulation = SwitchingPopulation
    if args.record:
        runner.picture = picture
    runtime = None
    try:
        from crab_defense.native import ClawRuntime
        runtime = ClawRuntime()
        with threadpool_limits(limits=1):
            for seed in range(args.seed, args.seed + args.count):
                torch.manual_seed(seed)
                data = runner.run(seed, 4, "r_sac", args.seconds, CFG, runtime, None, args.record, False, "original", False)
                save_replay(data, folder / f"native-{seed}-replay.npz")
    finally:
        if runtime:
            runtime.close()


if __name__ == "__main__":
    main()
