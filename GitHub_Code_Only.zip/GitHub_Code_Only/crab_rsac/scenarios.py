"""Prespecified unseen opponent roles and mid-episode strategy switches."""

import numpy as np

from crab_defense.territorial_strategy import TerritorialPopulation


class SwitchingPopulation(TerritorialPopulation):
    """Only the simulator knows private profiles; actors see the usual states."""

    def __init__(self, seed, world, cfg):
        super().__init__(seed, world, cfg)
        self.profile_rng = np.random.default_rng(np.random.SeedSequence([seed, 98254]))
        self.switch_ticks = (0, 75, 175)

    def choose(self, tick, x, previous):
        if tick in self.switch_ticks:
            rng = self.profile_rng
            self.bold[1:] = rng.permutation([rng.uniform(.02, .18), rng.uniform(.38, .65), rng.uniform(.85, .99)])
            self.yield_at[1:] = rng.uniform(.25, .9, 3)
            self.response_gain[1:] = rng.uniform(.6, 1.5, 3)
            self.grappler[1:] = rng.uniform(.25, .95, 3)
            self.windup[1:] = rng.uniform(.2, .8, 3)
            self.events.append({"tick": tick, "actor": -1, "phase": "private_profile_switch", "evaluation_only": True})
        return super().choose(tick, x, previous)
