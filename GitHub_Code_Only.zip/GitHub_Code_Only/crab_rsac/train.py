"""Reproducible CPU recurrent SAC pretraining, with held-out validation only."""

import argparse
import hashlib
import json
from pathlib import Path
from time import perf_counter

import numpy as np
import torch

from .envs import FastEnv
from .interface import ACT_DIM
from .learning import Agent, Config, Replay

ROOT = Path(__file__).resolve().parents[1]
RUNS = ROOT / ".cache/rsac_research"
VALIDATION_SEEDS = (80000, 80001, 80002, 80003)


def sources():
    return {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((ROOT / "crab_rsac").glob("*.py"))
            if p.name in ("interface.py", "envs.py", "learning.py", "train.py")}


def validate(agent, seeds=VALIDATION_SEEDS):
    values = []
    for seed in seeds:
        env = FastEnv(seed)
        obs = env.reset(seed)
        previous, state = np.zeros((1, ACT_DIM), np.float32), None
        for _ in range(env.steps):
            action, state = agent.act(obs[None], previous, state, deterministic=True)
            obs, _, _, info = env.step(action[0])
            previous = action
        values.append(info)
    return {"return": float(np.mean([v["return"] for v in values])), "benefit": float(np.mean([v["benefit"] for v in values])),
            "within_goal": sum(v["distance"] < .4 for v in values), "count": len(values), "fidelity": FastEnv.fidelity}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--seed", type=int, default=1)
    parser.add_argument("--steps", type=int, default=200000)
    parser.add_argument("--envs", type=int, default=16)
    parser.add_argument("--updates", type=int, default=1)
    parser.add_argument("--resume")
    args = parser.parse_args()
    torch.set_num_threads(1)
    torch.set_num_interop_threads(1)
    rng = np.random.default_rng(args.seed)
    folder = RUNS / f"seed-{args.seed}"
    folder.mkdir(parents=True, exist_ok=True)
    agent = Agent(Config(batch=16, burn=8, learn=8), args.seed) if not args.resume else Agent.load(Path(args.resume), resume=True)
    buffer = Replay(args.seed)
    envs = [FastEnv(int(rng.integers(70000, 80000))) for _ in range(args.envs)]
    obs = np.stack([e.reset(e.seed) for e in envs])
    previous, state = np.zeros((args.envs, ACT_DIM), np.float32), None
    episodes = [{"obs": [obs[i].copy()], "actions": [], "rewards": [], "dones": []} for i in range(args.envs)]
    began, original_sources = perf_counter(), sources()
    best, last_stats, recent = -np.inf, {}, []
    interval = max(1, 25000 // args.envs)
    for batch_step in range(1, args.steps // args.envs + 1):
        action, state = agent.act(obs, previous, state)
        if batch_step * args.envs < 3000:
            action = rng.uniform(-1, 1, action.shape).astype(np.float32)
        for i, env in enumerate(envs):
            successor, r, done, info = env.step(action[i])
            ep = episodes[i]
            ep["obs"].append(successor)
            ep["actions"].append(action[i].copy())
            ep["rewards"].append(r)
            ep["dones"].append(done)
            obs[i], previous[i] = successor, action[i]
            if done:
                buffer.add(**ep)
                recent.append(info["return"])
                recent = recent[-64:]
                obs[i] = env.reset(int(rng.integers(70000, 80000)))
                previous[i] = 0
                for h in state:
                    h[:, i] = 0
                episodes[i] = {"obs": [obs[i].copy()], "actions": [], "rewards": [], "dones": []}
        if buffer.count >= 1000:
            for _ in range(args.updates):
                last_stats = agent.update(buffer.sample(agent.cfg))
        if batch_step % interval == 0 or batch_step == args.steps // args.envs:
            validation = validate(agent)
            metadata = {"training_seed": args.seed, "training_steps": batch_step * args.envs, "gradient_updates": agent.updates,
                        "training_fidelity": FastEnv.fidelity, "native_training_steps": 0,
                        "validation_seeds": list(VALIDATION_SEEDS), "validation": validation,
                        "wall_seconds": perf_counter() - began, "source_sha256": original_sources,
                        "training_seed_range": [70000, 79999], "cv_frozen_test_seeds_excluded": [66000, 66011]}
            assert sources() == original_sources
            checkpoint = folder / f"pretrain-{batch_step * args.envs:07d}.pt"
            agent.save(checkpoint, metadata)
            if validation["return"] > best:
                best = validation["return"]
                agent.save(folder / "best_pretrain.pt", metadata)
            agent.save(folder / "last_pretrain.pt", metadata)
            print(json.dumps({**metadata, "source_sha256": "recorded", "recent_training_return": float(np.mean(recent)) if recent else None,
                              "optimization": last_stats}), flush=True)
    torch.save({"episodes": buffer.episodes, "count": buffer.count}, folder / "pretrain_replay.pt")


if __name__ == "__main__":
    main()
