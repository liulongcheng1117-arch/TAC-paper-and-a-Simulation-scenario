"""Shared-world Jumper physics; no game objectives or policies are defined here."""
