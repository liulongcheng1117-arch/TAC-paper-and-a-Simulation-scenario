"""Independent Jumper controllers in one native MuJoCo world.

The original meshes, inertias, joint limits, collision shapes and packaged ONNX
policies are retained. The NumPy servo below follows the upstream PD,
torque-speed and thermal laws; it does not prescribe body trajectories.

Run from the project root with the project's environment:
    python -m crab_sim.multi_crab --seconds 4 --output outputs/multi-crab-smoke
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import tempfile
import time
import zipfile
from dataclasses import dataclass
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REPO = ROOT / "upstream" / "jumper"
CACHE = ROOT / ".cache"
for _directory in (CACHE / "tmp", CACHE / "matplotlib"):
    _directory.mkdir(parents=True, exist_ok=True)
os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")
os.environ.setdefault("GIT_PYTHON_REFRESH", "quiet")
os.environ.setdefault("MPLCONFIGDIR", str(CACHE / "matplotlib"))

import mujoco
import numpy as np
import onnxruntime as ort


@dataclass(frozen=True)
class CrabConfig:
    name: str
    xy: tuple[float, float]
    color: tuple[float, float, float]
    yaw: float = 0.0


def servo_step_numpy(curve, position, velocity, target, kp, kd, heat, dt):
    """The upstream measured servo law, including its Euler thermal update."""
    demanded = kp * (target - position) - kd * velocity
    limit = curve.plateau_torque * np.exp(
        -np.maximum(np.abs(velocity) - curve.corner_speed, 0) / curve.decay_speed)
    limit = np.where(np.abs(velocity) >= curve.cutoff_speed, 0.0, limit)
    limit = np.minimum(limit, np.where(heat >= 1, curve.continuous_torque,
                                      curve.plateau_torque))
    torque = np.clip(demanded, -limit, limit)
    next_heat = np.maximum(heat + ((torque / curve.continuous_torque) ** 2 - heat)
                           * (dt / curve.thermal_time_constant), 0)
    return torque, next_heat


class BundleRuntime:
    """One immutable asset bundle and shared inference sessions, many fresh FSMs."""

    def __init__(self, path: Path | None = None) -> None:
        from mjrl.app_play import _load_extension

        path = path or REPO / "out" / "bundle_example" / "jumper.app"
        self._temporary = tempfile.TemporaryDirectory(
            prefix="multi-crab-app-", dir=CACHE / "tmp", ignore_cleanup_errors=True)
        self.root = Path(self._temporary.name)
        with zipfile.ZipFile(path) as archive:
            for item in archive.infolist():
                resolved = (self.root / item.filename).resolve()
                if not resolved.is_relative_to(self.root.resolve()):
                    raise ValueError(f"Unsafe archive entry: {item.filename}")
            archive.extractall(self.root)
        self.manifest = json.loads((self.root / "bundle.json").read_text("utf-8"))
        if self.manifest["schema"] != "kk-policy-bundle/1":
            raise ValueError("Unsupported policy bundle schema")
        for relative, record in self.manifest["files"].items():
            contents = (self.root / relative).read_bytes()
            if len(contents) != record["bytes"] or hashlib.sha256(contents).hexdigest() != record["sha256"]:
                raise ValueError(f"Bundle integrity failure: {relative}")
        self.module, self.controller_origin = _load_extension(self.root, self.manifest)
        self.contracts = {
            mode: (self.root / entry["contract"]).read_text("utf-8")
            for mode, entry in self.manifest["modes"].items()
        }
        self.layouts = {mode: json.loads(text) for mode, text in self.contracts.items()}
        self.trajectories = {
            mode: (self.root / entry["trajectory"]).read_text("utf-8")
            for mode, entry in self.manifest["modes"].items() if entry.get("trajectory")
        }
        self.layout = self.layouts["locomotion"]
        self.wire = self.layout["wire_joint_order"]
        if any(layout["wire_joint_order"] != self.wire for layout in self.layouts.values()):
            raise ValueError("Bundle modes disagree about wire joint order")
        self.control_hz = max(layout["control"]["control_hz"] for layout in self.layouts.values())
        self.options = ort.SessionOptions()
        self.options.intra_op_num_threads = 1
        self.options.inter_op_num_threads = 1
        unique_sessions = {}
        self.sessions = {}
        for mode, entry in self.manifest["modes"].items():
            relative = entry["models"]["onnx"]
            if relative not in unique_sessions:
                unique_sessions[relative] = ort.InferenceSession(
                    str(self.root / relative), sess_options=self.options,
                    providers=["CPUExecutionProvider"])
            self.sessions[mode] = unique_sessions[relative]
        reference = self.new_fsm().check_reference(
            (self.root / self.manifest["reference"]).read_text("utf-8"))
        if reference.observation > 1e-6 or reference.target > 1e-6 or reference.mode_mismatches:
            raise ValueError("Packaged controller failed its reference replay")
        self.reference = {
            "frames": reference.frames, "observation_error": reference.observation,
            "target_error": reference.target,
        }

    def new_fsm(self):
        limits = self.layout["joint_limits"]
        return self.module.Fsm(
            (self.root / self.manifest["fsm"]).read_text("utf-8"),
            self.contracts,
            {"joint_names": self.wire,
             "joint_pos_lo": [limits[name][0] for name in self.wire],
             "joint_pos_hi": [limits[name][1] for name in self.wire],
             "output_rate_hz": self.control_hz},
            trajectories=self.trajectories,
            operators=False,
        )

    def close(self) -> None:
        self.sessions.clear()
        self._temporary.cleanup()


class MultiCrabWorld:
    """A shared MjData; body motion comes entirely from articulated dynamics."""

    def __init__(self, configs: list[CrabConfig], *, physics_hz: int = 1000,
                 runtime: BundleRuntime | None = None, resources=None,
                 obstacles=None, resource_radius=0.42) -> None:
        from mjlab.scene.scene import Scene, SceneCfg
        from mjlab.sim.sim import MujocoCfg
        from tasks.jumper.common.actuator import CURVE
        from tasks.jumper.common.constants import get_jumper_robot_cfg

        if not 1 <= len(configs) <= 16:
            raise ValueError("Use 1 to 16 robots; collision channels are assigned per robot")
        if len({cfg.name for cfg in configs}) != len(configs):
            raise ValueError("Robot names must be unique")
        if any(not cfg.name or "/" in cfg.name for cfg in configs):
            raise ValueError("Robot names must be non-empty and contain no slash")
        self.runtime = runtime or BundleRuntime()
        self._owns_runtime = runtime is None
        self.configs = configs
        self.curve = CURVE
        ratio = physics_hz / self.runtime.control_hz
        if ratio < 1 or abs(ratio - round(ratio)) > 1e-9:
            raise ValueError("Physics rate must be an integer multiple of the fastest policy")
        self.substeps = round(ratio)
        self.control_dt = 1 / self.runtime.control_hz
        entities = {}
        for cfg in configs:
            entity = get_jumper_robot_cfg()
            entity.init_state.pos = (*cfg.xy, entity.init_state.pos[2])
            entity.init_state.rot = (math.cos(cfg.yaw / 2), 0.0, 0.0, math.sin(cfg.yaw / 2))
            entities[cfg.name] = entity
        # This scene has one physical world, containing every articulated robot.
        scene = Scene(SceneCfg(num_envs=1, entities=entities), device="cpu")
        spec = scene.spec
        spec.worldbody.add_geom(
            name="ground", type=mujoco.mjtGeom.mjGEOM_PLANE, size=[6, 6, 0.1],
            rgba=[0.17, 0.21, 0.25, 1], contype=1, conaffinity=1,
            friction=[1, 0.01, 0.01])
        spec.worldbody.add_light(name="sun", pos=[0, 0, 5], dir=[0, 0, -1],
                                 type=mujoco.mjtLightType.mjLIGHT_DIRECTIONAL)
        if obstacles is not None:
            for index, (xmin, xmax, ymin, ymax) in enumerate(obstacles):
                if xmax <= xmin or ymax <= ymin:
                    raise ValueError("Obstacle boxes need positive width and depth")
                spec.worldbody.add_geom(
                    name=f"terrain_rock_{index}", type=mujoco.mjtGeom.mjGEOM_BOX,
                    pos=[(xmin + xmax) / 2, (ymin + ymax) / 2, 0.20],
                    size=[(xmax - xmin) / 2, (ymax - ymin) / 2, 0.20],
                    rgba=[0.40, 0.35, 0.29, 1], contype=1, conaffinity=1,
                    friction=[1, 0.01, 0.01])
        if resources is not None:
            for index, xy in enumerate(resources):
                spec.worldbody.add_geom(
                    name=f"resource_{index}", type=mujoco.mjtGeom.mjGEOM_CYLINDER,
                    pos=[*xy, 0.002], size=[resource_radius, 0.001],
                    rgba=[0.12, 0.65, 0.32, 0.38], group=2, contype=0, conaffinity=0)
        # Preserve the original ground/self-leg channels, then add cross-robot
        # channels. In particular, same-named legs and base hulls must collide.
        robot_bits = [1 << (7 + index) for index in range(len(configs))]
        all_robot_bits = sum(robot_bits)
        for index, cfg in enumerate(configs):
            for geom in spec.geoms:
                if not geom.name.startswith(cfg.name + "/"):
                    continue
                if geom.contype:
                    geom.contype |= robot_bits[index]
                    geom.conaffinity |= all_robot_bits ^ robot_bits[index]
                if geom.rgba[0] > 0.4 and geom.rgba[1] < 0.2:
                    geom.rgba = [*cfg.color, 1.0]
        self.model = spec.compile()
        MujocoCfg(timestep=1 / physics_hz).apply(self.model)
        self.data = mujoco.MjData(self.model)
        if self.model.nkey != 1:
            raise ValueError("Expected a single merged home keyframe")
        mujoco.mj_resetDataKeyframe(self.model, self.data, 0)
        mujoco.mj_forward(self.model, self.data)
        self.fsms = [self.runtime.new_fsm() for _ in configs]
        self.q_adr = []
        self.v_adr = []
        self.ctrl_ids = []
        self.body_ids = []
        self.geom_owner = np.full(self.model.ngeom, -1, dtype=int)
        for index, cfg in enumerate(configs):
            joint_ids = np.array([self.model.joint(f"{cfg.name}/{name}").id for name in self.runtime.wire])
            self.q_adr.append(self.model.jnt_qposadr[joint_ids].copy())
            self.v_adr.append(self.model.jnt_dofadr[joint_ids].copy())
            controls = []
            for joint in joint_ids:
                found = np.flatnonzero(self.model.actuator_trnid[:, 0] == joint)
                if len(found) != 1:
                    raise ValueError("Each wire joint must map to one torque actuator")
                controls.append(found[0])
            self.ctrl_ids.append(np.array(controls))
            self.body_ids.append(self.model.body(f"{cfg.name}/base_link").id)
            for geom in range(self.model.ngeom):
                if self.model.geom(geom).name.startswith(cfg.name + "/"):
                    self.geom_owner[geom] = index
        self.q_adr = np.asarray(self.q_adr)
        self.v_adr = np.asarray(self.v_adr)
        self.ctrl_ids = np.asarray(self.ctrl_ids)
        self.body_ids = np.asarray(self.body_ids)
        if not np.allclose(self.model.actuator_gear[self.ctrl_ids, 0], 1):
            raise ValueError("NumPy servo assumes unit gear torque actuators")
        self.targets = self.data.qpos[self.q_adr].copy()
        self.kp = np.full_like(self.targets, 10.0)
        self.kd = np.full_like(self.targets, 0.5)
        self.heat = np.zeros_like(self.targets)
        self.tick = 0
        self.inferences = np.zeros(len(configs), dtype=int)
        self.max_joint_motion = np.zeros(len(configs))
        self.initial_joints = self.targets.copy()
        self.initial_xy = self.positions[:, :2].copy()
        self.max_contact_force = 0.0
        self.cross_contact_steps = 0
        self.robot_contact_substeps = np.zeros(len(configs), dtype=int)
        self.robot_max_contact_force = np.zeros(len(configs))
        self.min_heights = self.positions[:, 2].copy()
        self.max_tilts = self.tilts.copy()
        self._renderer = None
        self._render_size = None

    @property
    def positions(self) -> np.ndarray:
        return self.data.xpos[self.body_ids].copy()

    @property
    def yaws(self) -> np.ndarray:
        rotation = self.data.xmat[self.body_ids].reshape(-1, 3, 3)
        return np.arctan2(rotation[:, 1, 0], rotation[:, 0, 0])

    @property
    def tilts(self) -> np.ndarray:
        rotation = self.data.xmat[self.body_ids].reshape(-1, 3, 3)
        return np.arccos(np.clip(rotation[:, 2, 2], -1, 1))

    def step(self, commands: np.ndarray) -> None:
        """Advance one 200 Hz control period; commands are body-frame vx,vy,yaw."""
        commands = np.asarray(commands, dtype=float)
        if commands.shape != (len(self.configs), 3) or not np.isfinite(commands).all():
            raise ValueError("Commands must be a finite (robots, 3) array")
        ranges = self.runtime.layout["command_ranges"]["twist"]
        for axis, key in enumerate(("lin_vel_x", "lin_vel_y", "ang_vel_z")):
            if np.any(commands[:, axis] < ranges[key][0]) or np.any(commands[:, axis] > ranges[key][1]):
                raise ValueError(f"Command axis {key} exceeds the trained range")
        now_us = round(self.tick * self.control_dt * 1e6)
        for index, fsm in enumerate(self.fsms):
            velocity = np.zeros(6)
            mujoco.mj_objectVelocity(self.model, self.data, mujoco.mjtObj.mjOBJ_BODY,
                                    self.body_ids[index], velocity, 1)
            fsm.set_state(
                self.data.qpos[self.q_adr[index]].tolist(),
                self.data.qvel[self.v_adr[index]].tolist(),
                self.data.actuator_force[self.ctrl_ids[index]].tolist(),
                self.data.xquat[self.body_ids[index]].tolist(), velocity[:3].tolist(), now_us)
            fsm.set_command(*commands[index].tolist(), now_us=now_us)
            mode = fsm.tick(now_us)
            if mode is not None:
                session = self.runtime.sessions[mode]
                action = session.run(None, {session.get_inputs()[0].name:
                    np.asarray([fsm.observation()], dtype=np.float32)})[0][0]
                fsm.resume(action.tolist())
                self.inferences[index] += 1
            self.targets[index] = fsm.positions()
            self.kp[index] = fsm.kp()
            self.kd[index] = fsm.kd()
        for _ in range(self.substeps):
            self._servo_substep()
            mujoco.mj_step(self.model, self.data)
            self._record_cross_contacts()
        self.tick += 1
        self.max_joint_motion = np.maximum(
            self.max_joint_motion, np.max(np.abs(self.data.qpos[self.q_adr] - self.initial_joints), axis=1))
        self.min_heights = np.minimum(self.min_heights, self.positions[:, 2])
        self.max_tilts = np.maximum(self.max_tilts, self.tilts)
        if not np.isfinite(self.data.qpos).all():
            raise FloatingPointError("MuJoCo produced non-finite state")

    def _servo_substep(self) -> None:
        torque, self.heat = servo_step_numpy(
            self.curve, self.data.qpos[self.q_adr], self.data.qvel[self.v_adr],
            self.targets, self.kp, self.kd, self.heat, self.model.opt.timestep)
        self.data.ctrl[self.ctrl_ids] = torque

    def _record_cross_contacts(self) -> None:
        cross = False
        involved = np.zeros(len(self.configs), dtype=bool)
        force = np.zeros(6)
        for contact_id in range(self.data.ncon):
            contact = self.data.contact[contact_id]
            left, right = self.geom_owner[contact.geom1], self.geom_owner[contact.geom2]
            if left < 0 or right < 0 or left == right:
                continue
            cross = True
            involved[[left, right]] = True
            mujoco.mj_contactForce(self.model, self.data, contact_id, force)
            magnitude = float(np.linalg.norm(force[:3]))
            self.max_contact_force = max(self.max_contact_force, magnitude)
            self.robot_max_contact_force[[left, right]] = np.maximum(
                self.robot_max_contact_force[[left, right]], magnitude)
        self.cross_contact_steps += int(cross)
        self.robot_contact_substeps += involved

    def render(self, width: int = 960, height: int = 720, *, fixed=False) -> np.ndarray:
        if self._renderer is None or self._render_size != (width, height):
            if self._renderer is not None:
                self._renderer.close()
            self.model.vis.global_.offwidth = width
            self.model.vis.global_.offheight = height
            self._renderer = mujoco.Renderer(self.model, width=width, height=height)
            self._render_size = width, height
        camera = mujoco.MjvCamera()
        camera.lookat[:] = np.mean(self.positions, axis=0)
        span = np.max(np.ptp(self.positions[:, :2], axis=0))
        camera.distance = max(1.4, 1.5 * span + 0.5)
        camera.azimuth = 100
        camera.elevation = -45
        if fixed:
            camera.lookat[:] = [0.0, 0.0, 0.04]
            camera.distance, camera.azimuth, camera.elevation = 4.8, 100, -65
        option = mujoco.MjvOption()
        option.geomgroup[1] = 0  # Collision meshes remain physical, only hidden in drawing.
        self._renderer.update_scene(self.data, camera=camera, scene_option=option)
        return self._renderer.render().copy()

    def report(self) -> dict:
        return {
            "robots": [cfg.name for cfg in self.configs],
            "shared_physics_worlds": 1, "independent_fsms": len(self.fsms),
            "physics_hz": 1 / self.model.opt.timestep,
            "control_hz": self.runtime.control_hz, "control_steps": self.tick,
            "simulated_seconds": self.tick * self.control_dt,
            "positions": self.positions.tolist(),
            "displacement_xy": (self.positions[:, :2] - self.initial_xy).tolist(),
            "tilts_degrees": np.rad2deg(self.tilts).tolist(),
            "max_tilts_degrees": np.rad2deg(self.max_tilts).tolist(),
            "min_heights_m": self.min_heights.tolist(),
            "max_joint_motion_rad": self.max_joint_motion.tolist(),
            "inferences": self.inferences.tolist(),
            "modes": [fsm.mode for fsm in self.fsms],
            "running": [fsm.running_policy for fsm in self.fsms],
            "cross_contact_substeps": self.cross_contact_steps,
            "max_cross_contact_force_N": self.max_contact_force,
            "robot_contact_substeps": self.robot_contact_substeps.tolist(),
            "robot_max_contact_force_N": self.robot_max_contact_force.tolist(),
            "controller_origin": self.runtime.controller_origin,
            "controller_reference": self.runtime.reference,
        }

    def close(self) -> None:
        if self._renderer is not None:
            self._renderer.close()
        if self._owns_runtime:
            self.runtime.close()


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seconds", type=float, default=4)
    parser.add_argument("--physics-hz", type=int, default=1000)
    parser.add_argument("--output", type=Path, default=ROOT / "outputs" / "multi-crab-smoke")
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    world = MultiCrabWorld([
        CrabConfig("red", (-0.8, 0), (0.9, 0.12, 0.1)),
        CrabConfig("yellow", (0, 0), (0.95, 0.7, 0.08)),
        CrabConfig("blue", (0.8, 0), (0.08, 0.38, 0.95)),
    ], physics_hz=args.physics_hz)
    started = time.perf_counter()
    try:
        for _ in range(round(args.seconds / world.control_dt)):
            commands = np.zeros((3, 3))
            if world.tick * world.control_dt > 1:
                commands[0, 0] = 0.08
                commands[2, 0] = -0.06
            world.step(commands)
        import imageio.v2 as imageio

        imageio.imwrite(args.output / "preview.png", world.render())
        report = world.report()
        report["wall_seconds_excluding_setup"] = time.perf_counter() - started
        report["control_steps_per_wall_second"] = world.tick / report["wall_seconds_excluding_setup"]
        report["purpose"] = "Physics/independent low-level controller smoke test; no game or learned high-level policy."
        (args.output / "report.json").write_text(json.dumps(report, indent=2) + "\n", "utf-8")
        print(json.dumps(report, indent=2))
    finally:
        world.close()


if __name__ == "__main__":
    main()
