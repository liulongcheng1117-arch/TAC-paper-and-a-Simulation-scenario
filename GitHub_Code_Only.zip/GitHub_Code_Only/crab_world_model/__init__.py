"""Policy-conditioned neural world models with synchronized single-point adaptation."""
