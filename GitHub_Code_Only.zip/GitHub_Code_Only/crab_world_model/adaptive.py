"""Residual-prior adaptation followed by synchronized single-point GP updates."""
import numpy as np
from crab_defense.prediction import DualPoseGP
from .model import NeuralDualGP

class AdaptiveNeuralDualGP(NeuralDualGP):
    def __init__(self,*args,adapt_prior=True,**kwargs):
        super().__init__(*args,**kwargs);self.adapt_prior=adapt_prior
        dim=self.encode(np.zeros((1,len(self.scale)))).shape[-1]
        self.online=np.zeros((self.players-1,dim,12));self.cov=np.broadcast_to(np.eye(dim)*.3,(self.players-1,dim,dim)).copy();self.forgetting=.98;self.raw_history=[]
        self.memory=96
    def neural(self,query):
        mean,var=super().neural(query)
        if self.adapt_prior:mean=mean+np.einsum('jbd,jdk->bjk',self.encode(query),self.online)
        return mean,var
    def observe(self,tick,x,previous,applied,successor):
        query=np.r_[x.ravel(),previous.ravel()][None]/self.scale;f=self.encode(query)
        raw,var=NeuralDualGP.neural(self,query)
        target=np.c_[applied[1:]/self.cfg.limits,(successor[1:]-self.transition(x,applied,self.cfg)[1:])/self.cfg.state_scale]
        if self.adapt_prior:
            current=raw[0]+np.einsum('jd,jdk->jk',f[:,0],self.online)
            for j in range(self.players-1):
                projected=self.cov[j]@f[j,0];gain=projected/(self.forgetting+f[j,0]@projected)
                self.online[j]+=np.outer(gain,np.clip(target[j]-current[j],-1,1))
                self.cov[j]=(self.cov[j]-np.outer(gain,projected))/self.forgetting
            # A changed prior is a new prediction condition; invalidate its old tree.
            self.tree=None
        self.raw_history.append(raw[0]);self.raw_history=self.raw_history[-self.memory:]
        DualPoseGP.observe(self,tick,x,previous,applied,successor);self.sample_count+=1
        h,_,innov,residual=self.arrays;self.history_features=self.encode(h);self.history_norm=np.sum(self.history_features**2,-1)
        prior=np.asarray(self.raw_history)
        if self.adapt_prior:prior=prior+np.einsum('jnd,jdk->njk',self.history_features,self.online)
        past=h[:,6*self.players:].reshape(len(h),self.players,6)[:,1:]
        self.du=past+innov.reshape(len(h),self.players-1,6)-prior[...,:6]
        self.dr=residual.reshape(len(h),self.players-1,6)-prior[...,6:]
