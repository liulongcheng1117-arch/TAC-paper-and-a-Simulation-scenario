"""Adaptive-prior experiment with an independent prospective test cohort."""
import argparse
import hashlib
import json
import shutil
import torch
from threadpoolctl import threadpool_limits
from . import experiment as base
from .adaptive import AdaptiveNeuralDualGP
from .model import ROOT,WORK as ORIGINAL,NeuralPredictor

WORK=ROOT/'.cache/adaptive_world_model_research'
MODELS=['wm','wm_finetune','wm_adaptive','wm_adaptive_dsp','wm_adaptive_dsp_dr']

def factory(*args,**kwargs):
    from .online import factory as online_factory
    return online_factory(*args,**kwargs)

def fingerprint():
    d=base.original_fingerprint()
    for name in ['model.py','experiment.py','adaptive.py','adaptive_experiment.py','online.py']:
        p=ROOT/'crab_world_model'/name;d[p.relative_to(ROOT).as_posix()]=hashlib.sha256(p.read_bytes()).hexdigest()
    d['ensemble.pt']=hashlib.sha256((WORK/'ensemble.pt').read_bytes()).hexdigest();return d

def configure():
    WORK.mkdir(parents=True,exist_ok=True)
    for name in ['ensemble.pt','training.json']:
        if not (WORK/name).exists():shutil.copyfile(ORIGINAL/name,WORK/name)
    base.WORK=WORK;base.NeuralDualGP=factory;base.fingerprint=fingerprint

def calibrate():
    original=(ORIGINAL/'calibration.json').read_text('utf-8')
    # Base calibration evaluates the same completed records for each prior.
    results={}
    for adaptive in [False,True]:
        base.MODE='wm_adaptive' if adaptive else 'wm';base.calibrate()
        d=json.loads((WORK/'calibration.json').read_text('utf-8'))
        if adaptive:results['wm_adaptive']=d['wm'];results['wm_adaptive_dsp']=d['wm_dsp']
        else:results['wm']=d['wm']
    (WORK/'calibration.json').write_text(json.dumps(results,indent=2),'utf-8')

def run(args):
    from .online import OnlineWorldPolicy
    base.MODE=args.method;base.PREDICTOR=NeuralPredictor(WORK/'ensemble.pt');runner=base.engine(args.record);runner.NativePolicy=OnlineWorldPolicy;runner.fingerprint=fingerprint
    if args.scenario=='switching':runner.ReactivePopulation=base.ChallengePopulation
    runner.OUT=WORK/args.tag;runner.OUT.mkdir(parents=True,exist_ok=True)
    if args.record:
        from crab_defense import strategy_visual
        strategy_visual.NAMES[args.method]=args.method.replace('_',' ').upper()
    cal=json.loads((WORK/'calibration.json').read_text('utf-8'))['wm_adaptive_dsp' if 'dsp' in args.method else args.method];runtime=base.ClawRuntime()
    try:
        for seed in range(args.seed,args.seed+args.count):runner.run(seed,4,args.method,args.seconds,base.NativeConfig(),runtime,cal,args.record,False,'original',False)
    finally:runtime.close()

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--calibrate',action='store_true');p.add_argument('--method',choices=MODELS,default='wm_adaptive_dsp_dr');p.add_argument('--seed',type=int,default=81011);p.add_argument('--count',type=int,default=1);p.add_argument('--seconds',type=float,default=120);p.add_argument('--tag',default='validation');p.add_argument('--scenario',default='switching');p.add_argument('--record',action='store_true');args=p.parse_args();torch.set_num_threads(1);configure()
    with threadpool_limits(limits=1):calibrate() if args.calibrate else run(args)
