"""Causal particle MPC with synchronized singleton policy/dynamics learning.

The global neural plant receives CURRENT applied commands, including the focal
command. Velocity and command-dwell features are derived only from public past
transitions. The two GP residuals share an observed transition per opponent.
Aleatoric variance is retained outside the conditioned latent covariance.
"""
from time import perf_counter
from types import SimpleNamespace
import numpy as np
from scipy.special import ndtri
from scipy.stats import qmc
from crab_defense.policy3d import NativeConfig,predict_step,features,plans,wrap
from crab_defense.navigation3d import GoalNavigation
from crab_interaction.arena import Arena
from .embodied_model import Ensemble,context,next_age,difference

METHODS=['wm','wm_finetune','wm_rls','wm_dsp','wm_dsp_dr']
LABELS={'wm':'Neural world-model MPC','wm_finetune':'Online-tuned neural world model','wm_rls':'World model + RLS','wm_dsp':'World model + Dsp-GPR','wm_dsp_dr':'World model + Dsp-GPR-DR'}
LIPSCHITZ=float(np.sqrt(522))

def phi(states,goal):
    own=states[...,0,:];others=states[...,1:,:];food=np.exp(-np.sum((own[...,:2]-goal)**2,-1)/(2*.6**2));return np.concatenate((food[...,None],features(own,others,goal).reshape(*food.shape,12)),-1)

def stage(values,u):
    others=values[...,1:].reshape(*values.shape[:-1],3,4);base=.08+.15*np.sum(u[...,:2]**2,-1)+.025*np.sum(u[...,2:]**2,-1)
    return base+np.sum(others[...,1:]*[12,3,3],axis=(-1,-2))-3*values[...,0]/(1+others[...,0].sum(-1))

class Readout:
    def __init__(self,dim,out):self.P=np.eye(dim)*.05;self.W=np.zeros((dim,out))
    def update(self,f,y):
        f=f[0];gain=self.P@f/(.98+f@self.P@f);self.W+=np.outer(gain,y[0]-f@self.W);self.P=(self.P-np.outer(gain,f)@self.P)/.98

class EmbodiedModel:
    particles=8
    def __init__(self,method,cfg):
        self.method=method;self.cfg=cfg;self.policy=Ensemble('policy',method=='wm_finetune');self.dynamics=Ensemble('dynamics',method=='wm_finetune');self.velocity=np.zeros((4,6));self.age=np.zeros((4,3));self.history=[];self.sample_count=0;self.last_info=None
        self.readouts=[Readout(89,18),Readout(89,24)]
        self.noise=ndtri(qmc.Sobol(d=cfg.horizon*42,scramble=True,seed=773).random_base2(3)).reshape(self.particles,cfg.horizon,42).transpose(1,0,2)
        self.work={};self.last_update_ms=0
    def kernel(self,q,anchors,j):
        if j:
            ids=np.r_[0:6,j*6:j*6+6,24:30,24+j*6:30+j*6,48+j*6:54+j*6,72+j*3:75+j*3,84,84+j]
            weights=np.r_[np.array([1,1,.5,.5,.5,.5]),np.array([1,1,.5,1,1,1]),np.full(12,.3),np.full(6,.1),np.full(3,.7),.5,.5]
        else:
            ids=np.arange(88);weights=np.r_[np.tile([1,1,.3,.3,.3,.3],4),np.full(24,.3),np.full(24,.1),np.full(12,.5),np.full(4,.3)]
        a=q[:,ids]*weights/1.5;b=anchors[:,ids]*weights/1.5
        return np.exp(-.5*np.maximum(np.sum(a*a,1)[:,None]+np.sum(b*b,1)[None]-2*a@b.T,0))
    def correction(self,which,q,mu,alea,epi,tick,anchors=None):
        latent=epi+(.35**2 if which==0 else .006**2)
        if 'dsp' not in self.method:return mu,alea+epi,None
        if not self.history:return mu,alea+latent,None
        history=self.history;hist=np.array([r[which]['q'] for r in history]);delta=np.array([r[which]['delta'] for r in history]);anchor_alea=np.array([r[which]['alea'] for r in history]);anchor_latent=np.array([r[which]['epi'] for r in history])+(.35**2 if which==0 else .006**2);ages=(tick-np.array([r['tick'] for r in history]))/4;temporal=np.exp(-.5*ages**2);result=mu.copy();variance=alea+latent;chosen=[]
        for j in range(1 if which==0 else 0,4):
            sl=slice((j-1)*6,j*6) if which==0 else slice(j*6,(j+1)*6);rho=self.kernel(q,hist,j)*temporal
            index=anchors[j] if anchors is not None and j in anchors else np.argmax(rho,1);chosen.append(index);r=rho[np.arange(len(q)),index,None];s=latent[:,sl];sa=anchor_latent[index,sl];den=sa+anchor_alea[index,sl]+.04*sa;cov=r*np.sqrt(s*sa)
            result[:,sl]+=cov/den*delta[index,sl];variance[:,sl]=alea[:,sl]+np.maximum(s-cov**2/den,0)
        return result,np.maximum(variance,1e-8),chosen
    def observe(self,tick,x,previous,applied,successor):
        if tick!=self.sample_count:raise ValueError('Transitions must be supplied in chronological order')
        start=perf_counter();qp=context(x,previous,self.velocity,self.age,self.cfg)[None];qd=context(x,applied,self.velocity,self.age,self.cfg)[None];ys=[(applied[1:]/self.cfg.limits).reshape(1,18),(difference(successor,predict_step(x,applied,self.cfg))/self.cfg.state_scale).reshape(1,24)];row={'tick':tick}
        for which,(net,q,y) in enumerate(zip([self.policy,self.dynamics],[qp,qd],ys)):
            m,a,e=net.predict(q);row[which]={'q':q[0],'delta':y[0]-m[0],'alea':a[0],'epi':e[0]}
            if self.method=='wm_finetune':net.update(q,y)
            if self.method=='wm_rls':self.readouts[which].update(net.inputs(q),y-m)
        self.history.append(row);self.history=self.history[-96:];self.velocity=difference(successor,x)/self.cfg.dt;self.age=next_age(self.age,applied,previous,self.cfg);self.sample_count+=1;self.last_update_ms=(perf_counter()-start)*1000
        if self.last_info is not None:self.last_info['update_ms']=self.last_update_ms
    def forecast(self,tick,x,previous,actions):
        if tick<self.sample_count:raise ValueError('A forecast cannot use observations from its future')
        b,h=actions.shape[:2];p=self.particles;world=np.broadcast_to(x,(b,p,4,6)).copy();prev=np.broadcast_to(previous,world.shape).copy();vel=np.broadcast_to(self.velocity,world.shape).copy();age=np.broadcast_to(self.age,(b,p,4,3)).copy();states=[];controls=[];self.work={'new_queries':0,'prefix_hits':0,'temporal_hits':0,'network_rows':0}
        for k in range(h):
            keys=[actions[i,:k+1].tobytes() for i in range(b)];lookup={};ids=[];inverse=[]
            for i,key in enumerate(keys):
                if key not in lookup:lookup[key]=len(ids);ids.append(i)
                inverse.append(lookup[key])
            ids=np.array(ids);inverse=np.array(inverse);n=len(ids);w=world[ids];v=vel[ids];a=age[ids];old=prev[ids];qp=context(w,old,v,a,self.cfg).reshape(n*p,88);m,va,ep=self.policy.predict(qp)
            if self.method=='wm_rls':m+=self.policy.inputs(qp)@self.readouts[0].W
            m,variance,anchors=self.correction(0,qp,m,va,ep,tick+k);u=np.zeros((n,p,4,6));u[:,:,0]=actions[ids,k,None];u[:,:,1:]=np.clip((m+np.sqrt(variance)*np.broadcast_to(self.noise[k,:,:18],(n,p,18)).reshape(n*p,18)).reshape(n,p,3,6),-1,1)*self.cfg.limits
            qd=context(w,u,v,a,self.cfg).reshape(n*p,88);m,va,ep=self.dynamics.predict(qd)
            if self.method=='wm_rls':m+=self.dynamics.inputs(qd)@self.readouts[1].W
            # The focal plant selects its own transition. Every opponent's
            # state GP conditions on the SAME transition as its policy GP.
            paired={j:anchors[j-1] for j in range(1,4)} if anchors is not None else None
            m,variance,_=self.correction(1,qd,m,va,ep,tick+k,anchors=paired)
            residual=(m+np.sqrt(variance)*np.broadcast_to(self.noise[k,:,18:],(n,p,24)).reshape(n*p,24)).reshape(n,p,4,6)*self.cfg.state_scale;z=predict_step(w,u,self.cfg)+residual;z[...,2]=wrap(z[...,2]);z[...,3:]=np.clip(z[...,3:],0,1);vel=(difference(z,w)/self.cfg.dt)[inverse];age=next_age(a,u,old,self.cfg)[inverse];world=z[inverse];prev=u[inverse];states.append(world.copy());controls.append(u[:,:,1:].mean(1)[inverse]);self.work['new_queries']+=n;self.work['prefix_hits']+=b-n;self.work['network_rows']+=n*p*2
        particles=np.stack(states,1);mean=particles.mean(2);angles=particles[...,2];mean[...,2]=np.arctan2(np.sin(angles).mean(2),np.cos(angles).mean(2));variance=(difference(particles,mean[:,:,None])/self.cfg.state_scale).var(2)
        return SimpleNamespace(particles=particles,inputs=np.stack(controls,1),own=mean[:,:,0],others=mean[:,:,1:],variance=variance[:,:,1:],own_variance=variance[:,:,0],radius=np.zeros((b,h)),reused=np.zeros((b,h),bool))
    def commit(self,chosen):pass

class EmbodiedPolicy:
    def __init__(self,method,players,side,cfg,calibration=None):
        self.method=method;self.cfg=cfg;self.side=side;self.calibration=calibration;self.goal=np.array([1.6*side,.45]);self.model=EmbodiedModel(method,cfg);self.navigation=GoalNavigation(side);self.continuation=None;self.goal_hold=False;self.progress=[];self.north_committed=False;self.last_packet=None
        from crab_defense import strategy_policy
        strategy_policy.ACTIVE_POLICY=self
    def choose(self,tick,x,previous):
        start=perf_counter();remaining=float(self.navigation.distance(x[0,:2]));radial=np.linalg.norm(x[0,:2]-self.goal)
        if radial<.34:self.goal_hold=True
        elif radial>.44:self.goal_hold=False
        self.progress.append(remaining);self.navigation.north_target(x[0,:2])
        if not self.north_committed and self.navigation.north_phase<2 and len(self.progress)>25 and remaining>.4 and min(self.progress[-10:])>min(self.progress[-25:-10])-.08:self.north_committed=True
        force=self.north_committed and self.navigation.north_phase<2;actions,labels=plans(x,previous,self.side,self.cfg,self.continuation,self.navigation,force,self.goal_hold);pred=self.model.forecast(tick,x,previous,actions);values=phi(pred.particles,self.goal);center=values.mean(2);variance=values.var(2).sum(-1);expected=stage(values,actions[:,:,None,:]).mean(2);penalty=np.zeros_like(expected)
        if self.method.endswith('dr'):
            fit=np.array(self.calibration['moment_fit']);mse=np.max(fit[:,0,None,None]+fit[:,1,None,None]*variance[None]/self.calibration['variance_scale'],0);pred.radius=np.sqrt(mse+variance);penalty=LIPSCHITZ*pred.radius
        target=self.navigation.north_target(x[0,:2]) if force else self.goal;distances=self.navigation.distance_to(pred.own[...,:2],target) if force else self.navigation.distance(pred.own[...,:2]);navigation=2*np.maximum(distances-.25,0);terrain=35*np.maximum(.23-Arena().clearance(pred.own[...,:2]),0)**2;task=self.cfg.dt*(navigation+terrain).sum(1)+np.maximum(distances[:,-1]-.25,0)/.18
        if self.goal_hold:task+=self.cfg.dt*(8*np.sum((pred.own[...,:2]-self.goal)**2,-1)+2*np.sum(actions[...,:2]**2,-1)).sum(1)
        nominal=self.cfg.dt*expected.sum(1);robust=self.cfg.dt*penalty.sum(1);total=nominal+robust+task;feasible=self.navigation.feasible(pred.own,x[0,:2])
        if self.goal_hold:
            inside=np.linalg.norm(pred.own[...,:2]-self.goal,axis=-1).max(1)<.38
            if np.any(feasible&inside):feasible&=inside
        early=float(self.navigation.distance_to(x[0,:2],target))-distances[:,1];progressive=feasible&(early>.012)
        if radial>self.cfg.goal_radius:
            if np.any(progressive):feasible&=progressive
            elif np.any(feasible):feasible&=early>=np.max(early[feasible])-.005
        if not np.any(feasible):feasible[:]=True
        masked=np.where(feasible,total,np.inf);chosen=int(masked.argmin());self.continuation=actions[chosen].copy();ranked=np.argsort(masked);labels=[(r,w,p) for r,w,_,p in labels];display=[chosen]
        for cond in [lambda i:labels[i][2]!=labels[chosen][2],lambda i:labels[i][0]!=labels[chosen][0]]:
            match=next((int(i) for i in ranked if feasible[i] and i not in display and cond(i)),None)
            if match is not None:display.append(match)
        for i in ranked:
            if len(display)==3:break
            if feasible[i] and int(i) not in display:display.append(int(i))
        packet={'selected':chosen,'labels':labels,'feasible':feasible.tolist(),'expected':nominal.tolist(),'regularizer':robust.tolist(),'task':task.tolist(),'total':total.tolist(),'ranked':[int(i) for i in ranked if feasible[i]],'display':display,'own':pred.own[display].tolist(),'opponents':pred.others[display].tolist(),'variance':pred.variance[display].tolist(),'theta':pred.radius[display].tolist(),'candidate_reaction_spread_m':max(float(np.linalg.norm(pred.others[i,:,:,:2]-pred.others[chosen,:,:,:2],axis=-1).max()) for i in display),'empirical_position_scale':self.calibration.get('position_scale90',[2]*8) if self.calibration else [2]*8,'nominal_winner':int(np.where(feasible,nominal+task,np.inf).argmin()),'prior_samples':self.model.sample_count,'work':dict(self.model.work)};self.last_packet=packet;self.last_prediction=pred;self.last_center=center;self.last_variance=variance
        info={'choice':labels[chosen],'expected':float(nominal[chosen]),'regularizer':float(robust[chosen]),'work':dict(self.model.work),'decision_ms':(perf_counter()-start)*1000,'goal_geodesic_m':remaining,'navigation_cost':float(navigation[chosen].sum()*self.cfg.dt),'force_north':bool(force),'feasible_candidates':int(feasible.sum()),'progressive_candidates':int(progressive.sum()),'goal_hold_mode':self.goal_hold,'explanation':packet,'world_model':{'method':self.method,'update_ms':0}}
        self.model.last_info=info['world_model'];return actions[chosen,0].copy(),info
