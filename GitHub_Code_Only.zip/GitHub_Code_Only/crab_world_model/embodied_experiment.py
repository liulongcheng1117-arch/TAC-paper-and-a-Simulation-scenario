"""Reproducible native-physics deployment; original comparisons stay frozen."""
import argparse
import hashlib
import json
import torch
from threadpoolctl import threadpool_limits
from crab_defense.randomized_strategy import engine,fingerprint as original_fingerprint
from crab_defense.native import ClawRuntime
from crab_defense.policy3d import NativeConfig
from crab_rsac.challenge import ChallengePopulation
from .embodied_model import ROOT,WORK
from .embodied import EmbodiedPolicy,METHODS,LABELS

def fingerprint():
    result=original_fingerprint()
    for name in ['embodied_model.py','embodied.py','embodied_experiment.py']:
        p=ROOT/'crab_world_model'/name;result[p.relative_to(ROOT).as_posix()]=hashlib.sha256(p.read_bytes()).hexdigest()
    for name in ['challenge.py','scenarios.py']:
        p=ROOT/'crab_rsac'/name;result[p.relative_to(ROOT).as_posix()]=hashlib.sha256(p.read_bytes()).hexdigest()
    result['models.pt']=hashlib.sha256((WORK/'models.pt').read_bytes()).hexdigest();return result

def run(args):
    runner=engine(args.record or args.live);runner.NativePolicy=EmbodiedPolicy;runner.ReactivePopulation=ChallengePopulation;runner.fingerprint=fingerprint;runner.OUT=WORK/args.tag;runner.OUT.mkdir(parents=True,exist_ok=True)
    if args.record or args.live:
        from crab_defense import strategy_visual
        from . import record
        record.LABELS.update(LABELS);strategy_visual.NAMES.update(LABELS);runner.picture=record.picture
    cal=json.loads((WORK/'calibration.json').read_text('utf-8'))[args.method.removesuffix('_dr')];runtime=ClawRuntime()
    try:
        for seed in range(args.seed,args.seed+args.count):runner.run(seed,4,args.method,args.seconds,NativeConfig(),runtime,cal,args.record,args.live,'original',False)
    finally:runtime.close()

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--method',choices=METHODS,default='wm_dsp_dr');p.add_argument('--seed',type=int,default=101000);p.add_argument('--count',type=int,default=1);p.add_argument('--seconds',type=float,default=120);p.add_argument('--tag',default='development');p.add_argument('--record',action='store_true');p.add_argument('--live',action='store_true');args=p.parse_args();torch.set_num_threads(1)
    with threadpool_limits(limits=1):run(args)
