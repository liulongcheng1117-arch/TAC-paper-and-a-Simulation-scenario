"""Algebraically equivalent singleton conditioning with cached history geometry.

Nearest-correlation search operates in log space. Paired dynamics evaluates
only its selected anchor, rather than building an unused history covariance.
The neural models, particle noise, posterior formula and MPC remain unchanged.
"""
import numpy as np
from time import perf_counter
from .embodied import EmbodiedModel,EmbodiedPolicy

class FastModel(EmbodiedModel):
    def __init__(self,method,cfg):super().__init__(method,cfg);self.refresh()
    def refresh(self):
        self.tables={};self.geometry={};self.ticks=np.array([r['tick'] for r in self.history])
        if not self.history:return
        for which in [0,1]:
            self.tables[which]={key:np.array([r[which][key] for r in self.history]) for key in ['q','delta','alea','epi']};self.tables[which]['latent']=self.tables[which]['epi']+(.35**2 if which==0 else .006**2)
            for j in range(1 if which==0 else 0,4):
                if j:
                    ids=np.r_[0:6,j*6:j*6+6,24:30,24+j*6:30+j*6,48+j*6:54+j*6,72+j*3:75+j*3,84,84+j];weights=np.r_[np.array([1,1,.5,.5,.5,.5]),np.array([1,1,.5,1,1,1]),np.full(12,.3),np.full(6,.1),np.full(3,.7),.5,.5]
                else:ids=np.arange(88);weights=np.r_[np.tile([1,1,.3,.3,.3,.3],4),np.full(24,.3),np.full(24,.1),np.full(12,.5),np.full(4,.3)]
                b=self.tables[which]['q'][:,ids]*weights/1.5;self.geometry[which,j]=(ids,weights,b,np.sum(b*b,1))
    def observe(self,*args,**kwargs):
        start=perf_counter();super().observe(*args,**kwargs);self.refresh();self.last_update_ms=(perf_counter()-start)*1000
        if self.last_info is not None:self.last_info['update_ms']=self.last_update_ms
    def correction(self,which,q,mu,alea,epi,tick,anchors=None):
        latent=epi+(.35**2 if which==0 else .006**2)
        if not self.history:return mu,alea+latent,None
        table=self.tables[which];result=mu.copy();variance=alea+latent;chosen=[];age2=((tick-self.ticks)/4)**2;temporal=np.exp(-.5*age2)
        for j in range(1 if which==0 else 0,4):
            sl=slice((j-1)*6,j*6) if which==0 else slice(j*6,(j+1)*6);ids,weights,b,bnorm=self.geometry[which,j];a=q[:,ids]*weights/1.5;anorm=np.sum(a*a,1)
            if anchors is None or j not in anchors:
                d=np.maximum(anorm[:,None]+bnorm[None]-2*a@b.T,0);total=d+age2;index=np.argmin(total,1)
                # Resolve floating-point ties using the reference correlation.
                near=total<=np.min(total,1)[:,None]+1e-12;ties=np.where(near.sum(1)>1)[0]
                if len(ties):index[ties]=np.argmax(np.exp(-.5*d[ties])*temporal,1)
                rho=np.exp(-.5*d[np.arange(len(q)),index])*temporal[index]
                underflow=rho==0;index[underflow]=0;rho[underflow]=np.exp(-.5*d[underflow,0])*temporal[0]
            else:
                index=anchors[j];d=np.maximum(anorm+bnorm[index]-np.einsum('ij,ij->i',2*a,b[index]),0);rho=np.exp(-.5*d)*temporal[index]
            chosen.append(index);sa=table['latent'][index,sl];s=latent[:,sl];den=sa+table['alea'][index,sl]+.04*sa;cov=rho[:,None]*np.sqrt(s*sa);result[:,sl]+=cov/den*table['delta'][index,sl];variance[:,sl]=alea[:,sl]+np.maximum(s-cov**2/den,0)
        return result,np.maximum(variance,1e-8),chosen

class FastPolicy(EmbodiedPolicy):
    def __init__(self,method,players,side,cfg,calibration=None):
        super().__init__(method,players,side,cfg,calibration)
        if 'dsp' in method:self.model=FastModel(method,cfg)
