"""Released native runtime with verified equivalent singleton computation."""
import argparse
import hashlib
import torch
from threadpoolctl import threadpool_limits
from . import embodied_experiment as reference
from .embodied_fast import FastPolicy
from .embodied_model import ROOT
from .embodied import METHODS,LABELS

original_fingerprint=reference.fingerprint
def fingerprint():
    d=original_fingerprint()
    for name in ['embodied_fast.py','embodied_fast_experiment.py']:
        p=ROOT/'crab_world_model'/name;d[p.relative_to(ROOT).as_posix()]=hashlib.sha256(p.read_bytes()).hexdigest()
    return d
def run(args):
    LABELS['wm_dr']='Robust neural world-model MPC';reference.EmbodiedPolicy=FastPolicy;reference.fingerprint=fingerprint;return reference.run(args)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--method',choices=METHODS+['wm_dr'],default='wm_dsp_dr');p.add_argument('--seed',type=int,default=101002);p.add_argument('--count',type=int,default=1);p.add_argument('--seconds',type=float,default=120);p.add_argument('--tag',default='optimized_native');p.add_argument('--record',action='store_true');p.add_argument('--live',action='store_true');a=p.parse_args();torch.set_num_threads(1)
    with threadpool_limits(limits=1):run(a)
