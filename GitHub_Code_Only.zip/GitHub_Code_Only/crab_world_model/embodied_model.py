"""Action-conditioned global dynamics and history-aware opponent models."""
import json
from pathlib import Path
import numpy as np
import torch
from torch import nn
from crab_defense.policy3d import NativeConfig,predict_step

ROOT=Path(__file__).resolve().parents[1];WORK=ROOT/'.cache/embodied_world_model_research'

def context(x,u,velocity,age,cfg):
    shape=x.shape[:-2]
    state=x/cfg.state_scale;state=state.copy();state[...,2]=np.sin(x[...,2])
    return np.concatenate((state.reshape(*shape,24),(u/cfg.limits).reshape(*shape,24),(velocity/cfg.limits).reshape(*shape,24),(age/2).reshape(*shape,12),np.cos(x[...,2])),-1)

def difference(a,b):
    delta=a-b;delta[...,2]=np.arctan2(np.sin(delta[...,2]),np.cos(delta[...,2]));return delta

def next_age(age,u,previous,cfg):
    signature=lambda v:np.where(np.abs(v[...,3:]/cfg.limits[3:])>.15,np.sign(v[...,3:]),0)
    return np.minimum(np.where(signature(u)==signature(previous),age+cfg.dt,0),4)

class Net(nn.Module):
    def __init__(self,dim,out):
        super().__init__();self.out=out;self.layers=nn.Sequential(nn.Linear(dim,128),nn.SiLU(),nn.Linear(128,128),nn.SiLU(),nn.Linear(128,2*out))
    def forward(self,x):
        z=self.layers(x);return z[...,:self.out],torch.clamp(z[...,self.out:],-7,2)

class Ensemble:
    def __init__(self,kind,trainable=False):
        d=torch.load(WORK/'models.pt',map_location='cpu',weights_only=False)[kind];self.xm=d['xm'];self.xs=d['xs'];self.ym=d['ym'];self.ys=d['ys'];self.out=len(self.ym);self.members=[];self.trainable=trainable;self.memory=[]
        for state in d['members']:
            m=Net(len(self.xm),self.out);m.load_state_dict(state);m.eval();self.members.append(m)
        if trainable:self.optimizers=[torch.optim.AdamW(m.parameters(),lr=.0001,weight_decay=.0001) for m in self.members]
    def inputs(self,q):return np.c_[np.ones(len(q)),np.clip((q-self.xm)/self.xs,-10,10)]
    def predict(self,q):
        x=torch.from_numpy(np.clip((q-self.xm)/self.xs,-10,10).astype('float32'))
        with torch.inference_mode():
            z=[m(x) for m in self.members];means=torch.stack([v[0] for v in z]).numpy();alea=torch.stack([v[1].exp() for v in z]).numpy().mean(0)*self.ys**2
        return means.mean(0)*self.ys+self.ym,np.maximum(alea,1e-8),np.maximum(means.var(0)*self.ys**2,1e-8)
    def update(self,q,y):
        self.memory.append((q.copy(),y.copy()));self.memory=self.memory[-96:]
        x=np.concatenate([p[0] for p in self.memory]);z=np.concatenate([p[1] for p in self.memory]);x=torch.from_numpy(np.clip((x-self.xm)/self.xs,-10,10).astype('float32'));z=torch.from_numpy(((z-self.ym)/self.ys).astype('float32'))
        for m,opt in zip(self.members,self.optimizers):
            mean,lv=m(x);loss=((mean-z)**2*(-lv).exp()+lv).mean();opt.zero_grad();loss.backward();nn.utils.clip_grad_norm_(m.parameters(),5);opt.step()

def dataset(paths):
    cfg=NativeConfig();polx=[];poly=[];dynx=[];dyny=[]
    for path in paths:
        d=json.loads(path.read_text('utf-8'));x=np.array(d['physics']['initialization']['initial_public_state']);prev=np.zeros((4,6));velocity=np.zeros((4,6));age=np.zeros((4,3))
        for r in d['trace']:
            u=np.array(r['control']);z=np.array(r['state']);polx.append(context(x,prev,velocity,age,cfg));poly.append((u[1:]/cfg.limits).ravel());dynx.append(context(x,u,velocity,age,cfg));dyny.append((difference(z,predict_step(x,u,cfg))/cfg.state_scale).ravel());age=next_age(age,u,prev,cfg);velocity=difference(z,x)/cfg.dt;x,prev=z,u
    return {k:(np.array(a,np.float32),np.array(b,np.float32)) for k,a,b in [('policy',polx,poly),('dynamics',dynx,dyny)]}
