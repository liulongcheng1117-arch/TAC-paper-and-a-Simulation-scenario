"""Matched native-physics closed-loop experiments for learned world models."""
import argparse
import hashlib
import json
from pathlib import Path
import numpy as np
import torch
from scipy.optimize import nnls
from threadpoolctl import threadpool_limits
from crab_defense.randomized_strategy import engine,fingerprint as original_fingerprint
from crab_defense.policy3d import NativeConfig,predict_step,features,moments
from crab_defense.territorial_strategy import TerritorialPolicy
from crab_defense.strategy_policy import ForecastRecorder
from crab_defense.native import ClawRuntime
from crab_rsac.challenge import ChallengePopulation
from .model import ROOT,WORK,NeuralPredictor,NeuralDualGP

PREDICTOR=None
MODE='wm'

class WorldPolicy(TerritorialPolicy):
    def __init__(self,method,players,side,cfg,calibration=None):
        super().__init__('dual_dro' if MODE.endswith('dr') else 'dual_gp',players,side,cfg,calibration)
        self.model=ForecastRecorder(NeuralDualGP(players,cfg,PREDICTOR,'dsp' in MODE,transition_fn=predict_step))
    def choose(self,tick,x,previous):
        controls,info=super().choose(tick,x,previous)
        m=self.model.model
        info['world_model']={'method':MODE,'network_rows':m.network_rows,'single_point_rows':m.gp_rows,'model_sha256':hashlib.sha256((WORK/'ensemble.pt').read_bytes()).hexdigest()}
        return controls,info

def fingerprint():
    result=original_fingerprint()
    result.update({p.relative_to(ROOT).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in [ROOT/'crab_world_model/model.py',ROOT/'crab_world_model/experiment.py']})
    result['ensemble.pt']=hashlib.sha256((WORK/'ensemble.pt').read_bytes()).hexdigest()
    return result

def calibrate():
    global PREDICTOR
    PREDICTOR=NeuralPredictor();cfg=NativeConfig();result={}
    files=sorted((ROOT/'.cache/rsac_final_research/native/validation-2-fine-round1-final').glob('native-original*.json'))
    for mode in ['wm','wm_dsp']:
        errors=[[] for _ in range(cfg.horizon)];variances=[[] for _ in errors];positions=[[] for _ in errors];predrows=[]
        for path in files:
            d=json.loads(path.read_text('utf-8'));trace=d['trace'];x=np.array(d['physics']['initialization']['initial_public_state']);previous=np.zeros((4,6));model=NeuralDualGP(4,cfg,PREDICTOR,mode=='wm_dsp',transition_fn=predict_step)
            nodes=TerritorialPolicy('dual_gp',4,1,cfg).nodes;goal=np.array([1.6,.45])
            for t,row in enumerate(trace):
                if t+cfg.horizon<=len(trace):
                    actions=np.array([r['control'][0] for r in trace[t:t+cfg.horizon]])[None]
                    p=model.forecast(t,x,previous,actions);center,var=moments(p,cfg,nodes,goal)
                    for k in range(cfg.horizon):
                        truth=np.array(trace[t+k]['state']);phi=features(p.own[0,k],truth[1:],goal)
                        errors[k].append(float(np.sum((phi-center[0,k])**2)));variances[k].append(float(var[0,k]))
                        delta=truth[1:,:2]-p.others[0,k,:,:2];sigma=np.maximum(np.sqrt(p.variance[0,k,:,:2])*cfg.state_scale[:2],.003)
                        positions[k].extend(np.linalg.norm(delta/sigma,axis=-1).tolist())
                    predrows.append({'seed':d['seed'],'tick':t,'position_error_1':float(np.mean(np.linalg.norm(np.array(trace[t]['state'])[1:,:2]-p.others[0,0,:,:2],axis=-1))),'position_error_8':float(np.mean(np.linalg.norm(np.array(trace[t+7]['state'])[1:,:2]-p.others[0,7,:,:2],axis=-1)))})
                u=np.array(row['control']);successor=np.array(row['state']);model.observe(t,x,previous,u,successor);x,previous=successor,u
        scale=max(float(np.max(variances)),1e-10)
        fits=[nnls(np.c_[np.ones(len(v)),np.array(v)/scale],e)[0].tolist() for v,e in zip(variances,errors)]
        result[mode]={'domain':'original articulated MuJoCo','moment_fit':fits,'variance_scale':scale,'position_scale90':[float(np.quantile(p,.90)) for p in positions],'seeds':[80000,80001,80002,80003],'calibration_forecasts':len(predrows),'source_sha256':fingerprint()}
        (WORK/f'calibration_accuracy_{mode}.json').write_text(json.dumps(predrows),'utf-8')
        print('Calibrated',mode,len(predrows),flush=True)
    (WORK/'calibration.json').write_text(json.dumps(result,indent=2),'utf-8')

def run(args):
    global MODE,PREDICTOR
    MODE=args.method;PREDICTOR=NeuralPredictor();runner=engine(args.record);runner.NativePolicy=WorldPolicy;runner.fingerprint=fingerprint
    if args.scenario=='switching':runner.ReactivePopulation=ChallengePopulation
    runner.OUT=WORK/args.tag;runner.OUT.mkdir(parents=True,exist_ok=True)
    if args.record:
        from crab_defense import strategy_visual
        strategy_visual.NAMES.update({MODE:MODE.replace('_',' ').upper()})
    cfg=NativeConfig();cal=json.loads((WORK/'calibration.json').read_text('utf-8'))['wm_dsp' if 'dsp' in MODE else 'wm']
    runtime=ClawRuntime()
    try:
        for seed in range(args.seed,args.seed+args.count):runner.run(seed,4,MODE,args.seconds,cfg,runtime,cal,args.record,False,'original',False)
    finally:runtime.close()

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--calibrate',action='store_true');p.add_argument('--method',default='wm',choices=['wm','wm_dr','wm_dsp','wm_dsp_dr']);p.add_argument('--seed',type=int,default=91000);p.add_argument('--count',type=int,default=1);p.add_argument('--seconds',type=float,default=120);p.add_argument('--scenario',choices=['nominal','switching'],default='switching');p.add_argument('--tag',default='development');p.add_argument('--record',action='store_true');args=p.parse_args();torch.set_num_threads(1)
    with threadpool_limits(limits=1):calibrate() if args.calibrate else run(args)
