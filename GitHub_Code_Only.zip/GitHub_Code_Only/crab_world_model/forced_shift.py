"""Forced time-shift reuse of each own-strategy branch's opponent beliefs.

Overlap nodes are copied by absolute time, even after observations and posterior
updates. Only a new terminal opponent node is evaluated. Own-body prediction
still starts from the current physical observation. Existing controller logic,
model weights, calibration and physical limits are retained.
"""
import inspect
import textwrap
from time import perf_counter
from types import SimpleNamespace

import numpy as np
from scipy.special import ndtri
from scipy.stats import qmc

from . import embodied as base
from .embodied_fast import FastModel
from .embodied_model import context, difference, next_age
from crab_defense.policy3d import predict_step, wrap


class ShiftModel(FastModel):
    def __init__(self, method, cfg):
        super().__init__(method, cfg)
        self.bank = {}
        self.selected_key = None
        self.keys = []
        self.sources = []
        self.terminal_noise = {}

    def set_branches(self, tick, labels):
        self.keys, self.sources = [], []
        for route, wait, _, posture in labels:
            if route == 'continuation':
                key, source = ('continuation', tick), self.selected_key
            elif route == 'hold' or wait == 0:
                key = ('feedback', route, posture)
                source = key
            else:
                # A newly scheduled wait changes the own strategy's activation
                # time. It is a new branch, rather than a failed cache test.
                key = ('scheduled', route, posture, tick + int(wait))
                source = key
            self.keys.append(key)
            self.sources.append(source)

    def _new_noise(self, target_tick):
        if target_tick not in self.terminal_noise:
            seed = int(np.random.SeedSequence([773, target_tick]).generate_state(1)[0])
            self.terminal_noise[target_tick] = ndtri(
                qmc.Sobol(d=42, scramble=True, seed=seed).random_base2(3))
        return self.terminal_noise[target_tick]

    def _own_correction(self, q, mean, alea, epi, tick):
        latent = epi[:, :6] + .006**2
        if not self.history:
            return mean[:, :6], alea[:, :6] + latent
        table = self.tables[1]
        ids, weights, b, bnorm = self.geometry[1, 0]
        a = q[:, ids] * weights / 1.5
        d = np.maximum(np.sum(a*a, 1)[:, None] + bnorm[None] - 2*a@b.T, 0)
        age2 = ((tick - self.ticks) / 4)**2
        total = d + age2
        index = np.argmin(total, 1)
        ties = np.where((total <= total.min(1)[:, None] + 1e-12).sum(1) > 1)[0]
        temporal = np.exp(-.5*age2)
        if len(ties):
            index[ties] = np.argmax(np.exp(-.5*d[ties])*temporal, 1)
        rho = np.exp(-.5*d[np.arange(len(q)), index])*temporal[index]
        zero = rho == 0
        index[zero] = 0
        rho[zero] = np.exp(-.5*d[zero, 0])*temporal[0]
        sa = table['latent'][index, :6]
        den = sa + table['alea'][index, :6] + .04*sa
        cov = rho[:, None]*np.sqrt(latent*sa)
        result = mean[:, :6].copy()
        result += cov/den*table['delta'][index, :6]
        variance = (alea[:, :6] + latent).copy()
        variance[:] = alea[:, :6] + np.maximum(latent-cov**2/den, 0)
        return result, np.maximum(variance, 1e-8)

    def _fresh_step(self, tick, k, world, previous, velocity, age, own_u,
                    appended=False):
        n, p = world.shape[:2]
        noise = self.noise[k].copy()
        if appended:
            # Preserve the Gaussian law and master seed. Absolute-time terminal
            # draws avoid repeatedly applying one relative-horizon disturbance
            # to a particle carried through the entire episode.
            fresh = self._new_noise(tick + k + 1)
            noise[:, :18] = fresh[:, :18]
            noise[:, 24:] = fresh[:, 24:]
        qp = context(world, previous, velocity, age, self.cfg).reshape(n*p, 88)
        m, a, e = self.policy.predict(qp)
        m, variance, anchors = self.correction(0, qp, m, a, e, tick+k)
        u = np.zeros((n, p, 4, 6))
        u[:, :, 0] = own_u[:, None]
        u[:, :, 1:] = np.clip((m + np.sqrt(variance)*np.broadcast_to(
            noise[:, :18], (n, p, 18)).reshape(n*p, 18)).reshape(n, p, 3, 6),
            -1, 1)*self.cfg.limits
        qd = context(world, u, velocity, age, self.cfg).reshape(n*p, 88)
        m, a, e = self.dynamics.predict(qd)
        paired = {j: anchors[j-1] for j in range(1, 4)} if anchors is not None else None
        m, variance, _ = self.correction(1, qd, m, a, e, tick+k, paired)
        residual = (m + np.sqrt(variance)*np.broadcast_to(
            noise[:, 18:], (n, p, 24)).reshape(n*p, 24)).reshape(n, p, 4, 6)
        z = predict_step(world, u, self.cfg) + residual*self.cfg.state_scale
        z[..., 2] = wrap(z[..., 2])
        z[..., 3:] = np.clip(z[..., 3:], 0, 1)
        v = difference(z, world)/self.cfg.dt
        ages = next_age(age, u, previous, self.cfg)
        return z, u, v, ages

    def _warm_step(self, tick, k, world, previous, velocity, age, own_u, nodes):
        n, p = world.shape[:2]
        u = np.zeros((n, p, 4, 6))
        u[:, :, 0] = own_u[:, None]
        u[:, :, 1:] = np.stack([node['control'] for node in nodes])
        qd = context(world, u, velocity, age, self.cfg).reshape(n*p, 88)
        m, a, e = self.dynamics.predict(qd)
        m0, v0 = self._own_correction(qd, m, a, e, tick+k)
        own = predict_step(world[:, :, 0], u[:, :, 0], self.cfg)
        own += (m0 + np.sqrt(v0)*np.broadcast_to(
            self.noise[k, :, 18:24], (n, p, 6)).reshape(n*p, 6)
            ).reshape(n, p, 6)*self.cfg.state_scale
        own[..., 2] = wrap(own[..., 2])
        own[..., 3:] = np.clip(own[..., 3:], 0, 1)
        z = world.copy()
        z[:, :, 0] = own
        z[:, :, 1:] = np.stack([node['states'] for node in nodes])
        v = difference(z, world)/self.cfg.dt
        v[:, :, 1:] = np.stack([node['velocity'] for node in nodes])
        ages = next_age(age, u, previous, self.cfg)
        ages[:, :, 1:] = np.stack([node['age'] for node in nodes])
        return z, u, v, ages

    def forecast(self, tick, x, previous, actions):
        if tick < self.sample_count:
            raise ValueError('A forecast cannot use future observations')
        b, h = actions.shape[:2]
        assert len(self.keys) == b
        p = self.particles
        world = np.broadcast_to(x, (b, p, 4, 6)).copy()
        prev = np.broadcast_to(previous, world.shape).copy()
        vel = np.broadcast_to(self.velocity, world.shape).copy()
        age = np.broadcast_to(self.age, (b, p, 4, 3)).copy()
        sources = [self.bank.get(key) for key in self.sources]
        warm = np.array([s is not None and s['tick'] == tick-1 for s in sources])
        cold_ids, warm_ids = np.flatnonzero(~warm), np.flatnonzero(warm)
        states, controls, nodes_by_time = [], [], []
        radius = np.zeros((b, h))
        reused = np.zeros((b, h), bool)
        self.work = {'new_queries': 0, 'prefix_hits': 0, 'temporal_hits': 0,
                     'network_rows': 0, 'own_rollout_nodes': b*h,
                     'warm_branches': len(warm_ids), 'new_branches': len(cold_ids),
                     'reuse_max_abs_error': 0.0}
        for k in range(h):
            next_world, next_u, next_vel, next_age_value = (
                world.copy(), prev.copy(), vel.copy(), age.copy())
            if len(cold_ids):
                lookup, ids, inv = {}, [], []
                for i in cold_ids:
                    key = actions[i, :k+1].tobytes()
                    if key not in lookup:
                        lookup[key] = len(ids)
                        ids.append(i)
                    inv.append(lookup[key])
                ids, inv = np.array(ids), np.array(inv)
                result = self._fresh_step(tick, k, world[ids], prev[ids], vel[ids],
                                          age[ids], actions[ids, k])
                for target, value in zip((next_world, next_u, next_vel, next_age_value), result):
                    target[cold_ids] = value[inv]
                self.work['new_queries'] += len(ids)
                self.work['prefix_hits'] += len(cold_ids)-len(ids)
                self.work['network_rows'] += 2*len(ids)*p
            if len(warm_ids):
                if k < h-1:
                    old_nodes = [sources[i]['nodes'][k+1] for i in warm_ids]
                    assert all(node['target_tick'] == tick+k+1 for node in old_nodes)
                    result = self._warm_step(tick, k, world[warm_ids], prev[warm_ids],
                                            vel[warm_ids], age[warm_ids],
                                            actions[warm_ids, k], old_nodes)
                    radius[warm_ids, k] = [node['radius'] for node in old_nodes]
                    reused[warm_ids, k] = True
                    self.work['temporal_hits'] += len(warm_ids)
                    self.work['network_rows'] += len(warm_ids)*p
                    assert np.array_equal(result[0][:, :, 1:],
                                          np.stack([n['states'] for n in old_nodes]))
                else:
                    result = self._fresh_step(tick, k, world[warm_ids], prev[warm_ids],
                                             vel[warm_ids], age[warm_ids],
                                             actions[warm_ids, k], appended=True)
                    self.work['new_queries'] += len(warm_ids)
                    self.work['network_rows'] += 2*len(warm_ids)*p
                for target, value in zip((next_world, next_u, next_vel, next_age_value), result):
                    target[warm_ids] = value
            world, prev, vel, age = next_world, next_u, next_vel, next_age_value
            states.append(world.copy())
            controls.append(prev[:, :, 1:].mean(1))
            nodes_by_time.append([
                {'target_tick': tick+k+1, 'states': world[i, :, 1:].copy(),
                 'control': prev[i, :, 1:].copy(), 'velocity': vel[i, :, 1:].copy(),
                 'age': age[i, :, 1:].copy(), 'radius': 0.0}
                for i in range(b)])
        particles = np.stack(states, 1)
        mean = particles.mean(2)
        angles = particles[..., 2]
        mean[..., 2] = np.arctan2(np.sin(angles).mean(2), np.cos(angles).mean(2))
        variance = (difference(particles, mean[:, :, None])/self.cfg.state_scale).var(2)
        self.pending = {key: {'tick': tick, 'nodes': [nodes_by_time[k][i] for k in range(h)]}
                        for i, key in enumerate(self.keys)}
        self.prediction = SimpleNamespace(particles=particles, inputs=np.stack(controls, 1),
            own=mean[:, :, 0], others=mean[:, :, 1:], variance=variance[:, :, 1:],
            own_variance=variance[:, :, 0], radius=radius, reused=reused)
        return self.prediction

    def commit(self, chosen):
        for i, key in enumerate(self.keys):
            for k, node in enumerate(self.pending[key]['nodes']):
                node['radius'] = float(self.prediction.radius[i, k])
        self.bank = self.pending
        self.selected_key = self.keys[chosen]


# Keep every objective, constraint and solver operation from the existing
# controller. Only branch bookkeeping and the radius's forced shift are added.
source = textwrap.dedent(inspect.getsource(base.EmbodiedPolicy.choose))
needle = 'pred=self.model.forecast(tick,x,previous,actions)'
assert source.count(needle) == 1
source = source.replace(needle, 'self.model.set_branches(tick,labels);'+needle)
needle = 'pred.radius=np.sqrt(mse+variance)'
assert source.count(needle) == 1
source = source.replace(needle, 'pred.radius=np.where(pred.reused,pred.radius,np.sqrt(mse+variance))')
namespace = dict(base.__dict__)
exec(compile(source, '<forced-shift-controller>', 'exec'), namespace)
shift_choose = namespace['choose']


class ShiftPolicy(base.EmbodiedPolicy):
    def __init__(self, method, players, side, cfg, calibration=None):
        canonical = 'wm_dsp_dr' if method.endswith('dr') else 'wm_dsp'
        super().__init__(canonical, players, side, cfg, calibration)
        self.model = ShiftModel(canonical, cfg)

    def choose(self, tick, x, previous):
        start = perf_counter()
        u, info = shift_choose(self, tick, x, previous)
        self.model.commit(info['explanation']['selected'])
        info['decision_ms'] = (perf_counter()-start)*1000
        return u, info
