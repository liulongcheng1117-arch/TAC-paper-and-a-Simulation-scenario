"""Supplementary forced-shift comparison; previous release stays untouched."""
import argparse
import hashlib
import json
import torch
from threadpoolctl import threadpool_limits
from crab_defense.randomized_strategy import engine
from crab_defense.native import ClawRuntime
from crab_defense.policy3d import NativeConfig
from crab_rsac.challenge import ChallengePopulation
from .embodied_model import ROOT,WORK as ORIGINAL
from .embodied_fast_experiment import fingerprint as original_fingerprint
from .forced_shift import ShiftPolicy

WORK=ROOT/'.cache/forced_shift_reuse'
METHODS=['wm_dsp_shift','wm_dsp_shift_dr']
LABELS={'wm_dsp_shift':'Dsp-GPR / forced shift','wm_dsp_shift_dr':'Dsp-GPR-DR / forced shift'}

def fingerprint():
    result=original_fingerprint()
    for name in ['forced_shift.py','forced_shift_experiment.py']:
        p=ROOT/'crab_world_model'/name;result[p.relative_to(ROOT).as_posix()]=hashlib.sha256(p.read_bytes()).hexdigest()
    return result

def run(args):
    runner=engine(args.record);runner.NativePolicy=ShiftPolicy;runner.ReactivePopulation=ChallengePopulation;runner.fingerprint=fingerprint;runner.OUT=WORK/args.tag;runner.OUT.mkdir(parents=True,exist_ok=True)
    if args.record:
        from crab_defense import strategy_visual
        from . import record
        record.LABELS.update(LABELS);strategy_visual.NAMES.update(LABELS);runner.picture=record.picture
    cal=json.loads((ORIGINAL/'calibration.json').read_text('utf-8'))['wm_dsp'];runtime=ClawRuntime()
    try:runner.run(args.seed,4,args.method,args.seconds,NativeConfig(),runtime,cal,args.record,False,'original',False)
    finally:runtime.close()

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--method',choices=METHODS,default='wm_dsp_shift_dr');p.add_argument('--seed',type=int,default=101002);p.add_argument('--seconds',type=float,default=120);p.add_argument('--tag',default='test');p.add_argument('--record',action='store_true');a=p.parse_args();torch.set_num_threads(1)
    with threadpool_limits(limits=1):run(a)
