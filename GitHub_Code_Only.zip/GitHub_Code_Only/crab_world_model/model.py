"""A probabilistic interaction ensemble and paired single-anchor GP corrections."""
import json
from pathlib import Path
import numpy as np
import torch
from torch import nn
from crab_defense.territorial_strategy import CrowdInteractionGP

ROOT=Path(__file__).resolve().parents[1]
WORK=ROOT/'.cache/world_model_research'

class Network(nn.Module):
    def __init__(self,dim):
        super().__init__();self.net=nn.Sequential(nn.Linear(dim,128),nn.SiLU(),nn.Linear(128,128),nn.SiLU(),nn.Linear(128,24))
    def forward(self,x):
        y=self.net(x);return y[...,:12],torch.clamp(y[...,12:],-7,2)

class NeuralPredictor:
    def __init__(self,path=None):
        d=torch.load(path or WORK/'ensemble.pt',map_location='cpu',weights_only=False)
        self.xmean=d['xmean'];self.xstd=d['xstd'];self.ymean=d['ymean'];self.ystd=d['ystd'];self.members=[]
        for state in d['members']:
            m=Network(len(self.xmean));m.load_state_dict(state);m.eval();self.members.append(m)
    def predict(self,feature):
        shape=feature.shape[:-1];x=torch.from_numpy(np.clip((feature.reshape(-1,feature.shape[-1])-self.xmean)/self.xstd,-10,10).astype('float32'))
        with torch.inference_mode():
            pred=[m(x) for m in self.members];means=torch.stack([p[0] for p in pred]).numpy();variances=torch.stack([p[1].exp() for p in pred]).numpy()
        mean=means.mean(0)*self.ystd+self.ymean;var=(variances.mean(0)+means.var(0))*self.ystd**2
        return mean.reshape(*shape,12),var.reshape(*shape,12)

class NeuralDualGP(CrowdInteractionGP):
    def __init__(self,players,cfg,predictor,adapt,**kwargs):
        super().__init__(players,cfg,**kwargs);self.predictor=predictor;self.adapt=adapt
        self.cached_means=[];self.network_rows=0;self.gp_rows=0
    def neural(self,query):
        feature=self.encode(query);mean,var=self.predictor.predict(feature);self.network_rows+=int(np.prod(feature.shape[:-1]));return mean.transpose(1,0,2),var.transpose(1,0,2)
    def observe(self,tick,x,previous,applied,successor):
        query=np.r_[x.ravel(),previous.ravel()][None]/self.scale
        mean,_=self.neural(query);self.cached_means.append(mean[0]);self.cached_means=self.cached_means[-self.memory:]
        # Preserve the synchronized completed-transition labels and cache rules.
        from crab_defense.prediction import DualPoseGP
        DualPoseGP.observe(self,tick,x,previous,applied,successor)
        self.sample_count+=1
        h,_,innov,residual=self.arrays
        self.history_features=self.encode(h);self.history_norm=np.sum(self.history_features**2,-1)
        prior=np.asarray(self.cached_means)
        past=h[:,6*self.players:].reshape(len(h),self.players,6)[:,1:]
        self.du=past+innov.reshape(len(h),self.players-1,6)-prior[...,:6]
        self.dr=residual.reshape(len(h),self.players-1,6)-prior[...,6:]
    def posterior(self,query):
        mean,var=self.neural(query);b=len(query);j=self.players-1
        previous=query[:,6*self.players:].reshape(b,self.players,6)[:,1:]
        correction_u=np.zeros((b,j,6));correction_r=np.zeros_like(correction_u)
        vu=np.mean(var[...,:6],-1);vr=np.mean(var[...,6:],-1)
        if self.adapt and self.arrays is not None:
            feature=self.encode(query)
            dist=np.maximum(np.sum(feature**2,-1)[...,None]+self.history_norm[:,None]-2*feature@self.history_features.transpose(0,2,1),0)
            nearest=dist.argmin(-1).T;corr=np.exp(-dist.min(-1)/self.length**2).T
            gu=corr/(1+self.nu**2);gr=corr/(1+self.nr**2);col=np.arange(j)[None]
            correction_u=gu[...,None]*self.du[nearest,col];correction_r=gr[...,None]*self.dr[nearest,col]
            # GP residual uncertainty retains the neural predictive variance.
            vu=vu+self.su**2*(1-corr*gu);vr=vr+self.sr**2*(1-corr*gr);self.gp_rows+=b*j
        u=np.clip(mean[...,:6]+correction_u,-1,1)
        r=np.clip(mean[...,6:]+correction_r,-.4,.4)
        return u-previous,r,np.maximum(vu,1e-6),np.maximum(vr,1e-6)
