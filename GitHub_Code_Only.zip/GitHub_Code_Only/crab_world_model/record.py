"""English native 3D recording with unchanged control and articulated physics."""
import argparse
import json
import numpy as np
import torch
from PIL import Image,ImageDraw,ImageFont
from threadpoolctl import threadpool_limits
from crab_defense import strategy_visual,strategy_policy
from . import adaptive_experiment as ex

LABELS={'wm':'Neural WM-MPC','wm_finetune':'Online-tuned neural WM','wm_adaptive':'WM + adaptive readout','wm_adaptive_dsp':'WM + Dsp-GPR','wm_adaptive_dsp_dr':'WM + Dsp-GPR-DR'}
POSTURES={0:'Fold',1:'Guard',2:'Grasp',3:'Raise',-1:'Continue'}
original_engine=ex.base.engine
FONTS={s:ImageFont.truetype('C:/Windows/Fonts/arial.ttf',s) for s in [14,16,18,22,26]}

def picture(world,method,elapsed,benefit,goal_dwell=0):
    old=strategy_visual.picture(world,method,elapsed,benefit,goal_dwell)
    canvas=Image.new('RGB',(1728,832),'#101b2a');canvas.paste(Image.fromarray(old).crop((0,112,1280,832)),(0,112));d=ImageDraw.Draw(canvas)
    def text(x,y,s,size=18,color='#c8d8eb'):d.text((x,y),str(s),font=FONTS[size],fill=color)
    text(18,10,LABELS[method],26,'#6cdaff');text(930,16,f'Time {elapsed:.1f} s',22)
    distance=np.linalg.norm(world.positions[0,:2]-[1.6,.45]);loss=world.ledger.loss[0]
    text(18,50,f'Blue focal robot | Net return {benefit-loss:.2f} | Contact loss {loss:.2f} | Goal distance {distance:.2f} m')
    text(18,81,f'Stable dwell {goal_dwell:.1f} s | Native 22-joint motion and physical contacts | Orange rings: empirical 90% position bands',16)
    d.rectangle((1280,0,1728,832),fill='#152235');text(1295,16,'Conditional candidate objectives',22,'white')
    packet=getattr(strategy_policy.ACTIVE_POLICY,'last_packet',None)
    if packet:
        for px,label in [(1295,'Action'),(1450,'Mean'),(1520,'Robust'),(1590,'Task'),(1660,'Total')]:text(px,78,label,14)
        for n,j in enumerate(packet['ranked'][:6]):
            route,wait,posture=packet['labels'][j];color='#6cdaff' if j==packet['selected'] else '#c8d8eb';y=116+n*57
            text(1295,y,route.replace('_',' ').title(),14,color);text(1295,y+20,POSTURES[posture]+(' / Wait' if wait else ''),14,color)
            for px,key in [(1450,'expected'),(1520,'regularizer'),(1590,'task'),(1660,'total')]:text(px,y,f'{packet[key][j]:.2f}',14,color)
        text(1295,494,'Prediction / online adaptation',22,'white')
        w=packet['work']
        for y,s in [(536,f"Public transitions: {packet['prior_samples']}"),(571,f"New queries: {w['new_queries']}"),(606,f"Shared prefixes: {w['prefix_hits']}"),(641,f"Temporal reuse: {w['temporal_hits']}"),(676,f"Reaction spread: {packet['candidate_reaction_spread_m']:.3f} m"),(737,'Lower total objective is preferred'),(773,'Mean + robust penalty + task cost')]:text(1295,y,s,16)
    return np.asarray(canvas)

def engine(visual=False):
    runner=original_engine(visual)
    if visual:runner.picture=picture
    return runner

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--method',choices=ex.MODELS,required=True);p.add_argument('--seed',type=int,required=True);p.add_argument('--tag',default='recording');p.add_argument('--seconds',type=float,default=120);args=p.parse_args();args.count=1;args.record=True;args.scenario='switching';torch.set_num_threads(1);ex.configure();ex.base.engine=engine
    strategy_visual.NAMES.update(LABELS)
    with threadpool_limits(limits=1):ex.run(args)
