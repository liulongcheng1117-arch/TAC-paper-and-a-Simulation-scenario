"""Regenerate the native 3D comparison videos from simulation, without input videos."""
from __future__ import annotations
import argparse
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
from types import SimpleNamespace

ROOT=Path(__file__).resolve().parent


def prepare():
    from bootstrap import verify_assets
    verify_assets()
    for source,target in [('assets/world_model/models.pt','.cache/embodied_world_model_research/models.pt'),
                          ('assets/world_model/calibration.json','.cache/embodied_world_model_research/calibration.json'),
                          ('assets/randomized_calibration.json','.cache/randomized_strategy/calibration.json')]:
        destination=ROOT/target;destination.parent.mkdir(parents=True,exist_ok=True)
        if not destination.exists() or destination.read_bytes()!=(ROOT/source).read_bytes():
            shutil.copyfile(ROOT/source,destination)


def portable_fonts():
    from PIL import ImageFont
    original=ImageFont.truetype
    candidates=['C:/Windows/Fonts/arial.ttf','/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',
                '/usr/share/fonts/truetype/liberation2/LiberationSans-Regular.ttf',
                '/System/Library/Fonts/Supplemental/Arial.ttf','DejaVuSans.ttf']
    def load(font,size=10,*args,**kwargs):
        try:return original(font,size,*args,**kwargs)
        except OSError:
            for candidate in candidates:
                try:return original(candidate,size,*args,**kwargs)
                except OSError:pass
            return ImageFont.load_default(size=size)
    ImageFont.truetype=load


def raw_paths(method,seed):
    stem=ROOT/'.cache/video_reproduction'/f'{seed}-{method}'/f'native-original-n4-{seed}-{method}'
    return stem.with_suffix('.mp4'),stem.with_suffix('.json')


def worker(a):
    import numpy as np
    import torch
    from threadpoolctl import threadpool_limits
    torch.set_num_threads(1);portable_fonts();prepare()
    from crab_defense.native import ClawRuntime
    from crab_defense.randomized_strategy import engine,fingerprint
    from crab_defense.policy3d import NativeConfig
    from crab_defense import strategy_visual
    method=a.worker
    runner=engine(True);runner.OUT=raw_paths(method,a.seed)[0].parent;runner.OUT.mkdir(parents=True,exist_ok=True)
    calibration=json.loads((ROOT/'assets/randomized_calibration.json').read_text('utf-8'))
    if method.startswith('wm') or method.endswith('_shift') or method.endswith('_shift_dr'):
        from crab_world_model.embodied_fast import FastPolicy
        from crab_world_model.embodied_fast_experiment import fingerprint as wm_fingerprint
        from crab_world_model.embodied import LABELS
        from crab_world_model import record
        from crab_rsac.challenge import ChallengePopulation
        runner.NativePolicy=FastPolicy;runner.ReactivePopulation=ChallengePopulation;runner.fingerprint=wm_fingerprint
        runner.picture=record.picture;record.LABELS.update(LABELS);strategy_visual.NAMES.update(LABELS)
        calibration=json.loads((ROOT/'assets/world_model/calibration.json').read_text('utf-8'))['wm_dsp']
        if 'shift' in method:
            from crab_world_model.forced_shift import ShiftPolicy
            from crab_world_model.forced_shift_experiment import fingerprint as shift_fingerprint,LABELS as shift_labels
            runner.NativePolicy=ShiftPolicy;runner.fingerprint=shift_fingerprint;record.LABELS.update(shift_labels);strategy_visual.NAMES.update(shift_labels)
    elif method=='r_sac':
        from crab_rsac import native,final_sac
        from crab_rsac.learning import Agent
        from crab_rsac.full_authority import Guidance
        native.CHECKPOINT=ROOT/'assets/sac/seed-2.pt';native.AGENT=Agent.load(native.CHECKPOINT)
        native.STOCHASTIC=False;native.Guidance=Guidance;native.reward=final_sac.task_reward
        runner.NativePolicy=native.ActorPolicy;runner.picture=native.picture
        runner.fingerprint=lambda:{**native.fingerprint(),**final_sac.source()}
        calibration=None;torch.manual_seed(a.seed)
    else:
        if calibration['source_sha256']!=fingerprint():
            raise RuntimeError('Frozen controller source differs from the calibration source.')
    strategy_visual.NAMES.update({'dual_gp':'Dsp-GPR','dual_dro':'Dsp-GPR-DR','pose_cv':'CV-MPC'})
    runtime=ClawRuntime()
    try:
        with threadpool_limits(limits=1):
            runner.run(a.seed,4,method,a.seconds,NativeConfig(),runtime,calibration,True,False,'original',False)
    finally:runtime.close()


def compose(left,right,seed,seconds,name):
    portable_fonts()
    spec=importlib.util.spec_from_file_location('source_release_composer',ROOT/'tools/compose.py')
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    module.paths=raw_paths;module.DURATION=seconds
    module.NAMES.update({'wm_dsp':'WM + Dsp-GPR','wm_dsp_dr':'WM + Dsp-GPR-DR',
                         'wm_finetune':'Online-tuned WM','wm_dsp_shift':'Dsp / forced shift',
                         'wm_dsp_shift_dr':'DR / forced shift'})
    (ROOT/'videos').mkdir(exist_ok=True)
    return module.render((left,right,seed,'',name))


def jobs(suite,seed):
    wm_seed=101002 if seed is None else seed;old_seed=66004 if seed is None else seed
    result=[]
    if suite in ['world-model','all']:
        result.extend([('wm_dsp','wm_finetune',wm_seed,'Dsp_GPR_vs_Online_Tuned_World_Model.mp4'),
                       ('wm_dsp_dr','wm_finetune',wm_seed,'Dsp_GPR_DR_vs_Online_Tuned_World_Model.mp4')])
    if suite in ['cv-mpc','all']:
        result.extend([('dual_gp','pose_cv',old_seed,'Dsp_GPR_vs_CV_MPC.mp4'),
                       ('dual_dro','pose_cv',old_seed,'Dsp_GPR_DR_vs_CV_MPC.mp4')])
    if suite in ['sac','all']:
        result.extend([('dual_gp','r_sac',old_seed,'Dsp_GPR_vs_Recurrent_SAC.mp4'),
                       ('dual_dro','r_sac',old_seed,'Dsp_GPR_DR_vs_Recurrent_SAC.mp4')])
    if suite=='forced-shift':
        result.extend([('wm_dsp','wm_dsp_shift',wm_seed,'Dsp_GPR_Full_vs_Forced_Shift.mp4'),
                       ('wm_dsp_dr','wm_dsp_shift_dr',wm_seed,'Dsp_GPR_DR_Full_vs_Forced_Shift.mp4')])
    return result


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--suite',choices=['world-model','cv-mpc','sac','forced-shift','all'],default='world-model')
    p.add_argument('--seed',type=int);p.add_argument('--seconds',type=float,default=120)
    p.add_argument('--worker');p.add_argument('--force',action='store_true')
    a=p.parse_args()
    if a.seconds<=0 or abs(a.seconds/.4-round(a.seconds/.4))>1e-7:
        p.error('--seconds must be a positive multiple of 0.4')
    if a.worker:
        worker(a);return
    if not (ROOT/'upstream/jumper/out/bundle_example/jumper.app').exists():
        p.error('Run setup.cmd or python bootstrap.py first.')
    selected=jobs(a.suite,a.seed)
    for method,seed in dict.fromkeys((m,s) for left,right,s,_ in selected for m in [left,right]):
        mp4,trace=raw_paths(method,seed)
        reusable=mp4.is_file() and trace.is_file()
        if reusable:
            d=json.loads(trace.read_text('utf-8'));reusable=len(d['trace'])==round(a.seconds/.4)
        if a.force or not reusable:
            print(f'Simulating {method}, seed {seed}, {a.seconds:g} seconds',flush=True)
            subprocess.run([sys.executable,'-B',str(Path(__file__).resolve()),'--worker',method,
                            '--seed',str(seed),'--seconds',str(a.seconds)],cwd=ROOT,check=True)
    outputs=[]
    for left,right,seed,name in selected:outputs.append(compose(left,right,seed,a.seconds,name))
    (ROOT/'videos/reproduction.json').write_text(json.dumps(outputs,indent=2),'utf-8')
    print('Generated comparison videos:',ROOT/'videos',flush=True)


if __name__=='__main__':main()
