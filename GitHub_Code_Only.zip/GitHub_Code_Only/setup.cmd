@echo off
cd /d "%~dp0"
where py >nul 2>&1
if errorlevel 1 goto use_python
py -3.12 bootstrap.py %*
goto done
:use_python
python bootstrap.py %*
:done
if errorlevel 1 pause
