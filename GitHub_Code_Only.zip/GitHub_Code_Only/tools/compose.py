"""Create English overlays over the existing, unmodified 3D recordings."""
import json
import sys
from pathlib import Path
import imageio.v2 as iio
import numpy as np
from PIL import Image, ImageDraw, ImageFont

ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'videos';DURATION=120
FONTPATH='C:/Windows/Fonts/arial.ttf'
FONT={s:ImageFont.truetype(FONTPATH,s) for s in (16,18,20,22,26,30)}
NAMES={'dual_gp':'Dsp-GPR','dual_dro':'Dsp-GPR-DR','pose_cv':'CV-MPC','r_sac':'Recurrent SAC'}
POSTURES={0:'Fold',1:'Guard',2:'Grasp',3:'Raise',-1:'Continue'}
COLORS=['#6cdaff','#f8ba62']

def paths(method,seed):
    if method=='dual_gp':
        stem=ROOT/f'.cache/report_organization/native_dsp/native-original-n4-{seed}-dual_gp'
    elif method=='pose_cv':stem=ROOT/f'outputs/randomized_strategy/videos/{seed}-pose_cv'
    else:
        base=ROOT/'outputs/rsac_comparison'
        if seed==90007:base=base/'stress'
        return base/f'videos/{method}_full_explanation.mp4',base/f'videos/recorded-{method}.json'
    if method=='dual_gp':return stem.with_suffix('.mp4'),stem.with_suffix('.json')
    return stem.with_suffix('.mp4'),ROOT/f'.cache/randomized_strategy/native-original-n4-{seed}-pose_cv.json'

def text(d,xy,s,size=18,color='#c8d8eb'):
    d.text(xy,str(s),font=FONT[size],fill=color)

def series(data):
    return np.array([[0,0,0]]+[[r['time'],r['benefit']-r['contact_loss'][0],r['contact_loss'][0]] for r in data['trace']],float)

def render(job):
    a,b,seed,folder,name=job;ma,ja=paths(a,seed);mb,jb=paths(b,seed)
    datasets=[json.loads(p.read_text('utf-8')) for p in (ja,jb)];streams=[iio.get_reader(str(p)) for p in (ma,mb)];curves=[series(x) for x in datasets]
    target=OUT/folder/name;writer=iio.get_writer(str(target),fps=10,codec='libx264',quality=7,macro_block_size=1,ffmpeg_params=['-threads','2','-pix_fmt','yuv420p'])
    length=min(x.count_frames() for x in streams)
    for index in range(length):
        t=index/10;canvas=Image.new('RGB',(1920,1080),'#101b2a');d=ImageDraw.Draw(canvas)
        for side,(method,stream,data) in enumerate(zip((a,b),streams,datasets)):
            x=960*side;color=COLORS[side];frame=stream.get_next_data();scene=Image.fromarray(frame).crop((0,112,1280,832)).resize((960,540),Image.Resampling.LANCZOS);canvas.paste(scene,(x,66))
            text(d,(x+18,9),NAMES[method],30,color);text(d,(x+420,18),f'Seed {seed} | {t:05.1f} / {DURATION:.1f} s',20)
            k=max(0,min(int(t/.4+1e-7)-1,len(data['trace'])-1));row=data['trace'][k];benefit=row['benefit'] if t>=.4 else 0;loss=row['contact_loss'][0] if t>=.4 else 0
            text(d,(x+18,618),f"NET RETURN {benefit-loss:7.2f}    CONTACT LOSS {loss:6.2f}    STABLE DWELL {row['goal_stable_dwell_s'] if t>=.4 else 0:5.1f} s",20,color)
            decision=data['trace'][max(0,min(int((t-1e-5)/.4),len(data['trace'])-1))]['decision'];packet=decision.get('explanation')
            if packet:
                text(d,(x+18,654),'Candidate action',20);text(d,(x+410,654),'Expected',18);text(d,(x+530,654),'Robust',18);text(d,(x+650,654),'Task',18);text(d,(x+775,654),'Total',18)
                for n,j in enumerate(packet['ranked'][:5]):
                    route,wait,posture=packet['labels'][j];label=route.replace('_',' ').title()+' / '+POSTURES[posture]+(' / Wait' if wait else '');y=686+n*31;col=color if j==packet['selected'] else '#b4c4d8'
                    if j==packet['selected']:d.rounded_rectangle((x+10,y-2,x+940,y+27),5,fill='#263f56')
                    text(d,(x+18,y),label,18,col)
                    for px,key in [(410,'expected'),(530,'regularizer'),(650,'task'),(775,'total')]:text(d,(x+px,y),f'{packet[key][j]:.2f}',18,col)
                work=packet.get('work',{});text(d,(x+18,855),f"Queries {work.get('new_queries',0)} | Reused prefixes {work.get('prefix_hits',0)} | Temporal reuse {work.get('temporal_hits',0)}",18)
                text(d,(x+18,882),f"Opponent-response spread: {packet.get('candidate_reaction_spread_m',0):.3f} m | Lower objective is preferred",18)
            else:
                control=np.array(row['control'])[0]
                text(d,(x+18,665),'Recurrent SAC: public-state history -> continuous body/claw control',20)
                for n,(label,v) in enumerate(zip(['Body vx','Body vy','Claw heading','Extension','Closure','Height'],control)):
                    px=x+18+(n%3)*310;py=714+(n//3)*55;text(d,(px,py),f'{label}: {v:+.3f}',20)
                text(d,(x+18,855),'Independent LSTM actor | Validation-selected policy 2',18)
                text(d,(x+18,882),'Shared physical scoring: hits, grasps, holding and instability',18)
        d.line((960,0,960,914),fill='#687c8e',width=2)
        for column,title in [(1,'Cumulative net return'),(2,'Cumulative contact loss')]:
            left=20 if column==1 else 980;top=953;width=895;height=75
            text(d,(left,922),title,18)
            lo=min(0,min(c[:,column].min() for c in curves));hi=max(1,max(c[:,column].max() for c in curves))*1.05
            d.rectangle((left,top,left+width,top+height),outline='#43566d')
            for curve,color in zip(curves,COLORS):
                known=curve[curve[:,0]<=t+1e-7];points=[(left+v[0]/DURATION*width,top+height-(v[column]-lo)/(hi-lo)*height) for v in known]
                if len(points)>1:d.line(points,fill=color,width=3)
            text(d,(left,1031),f'{lo:.0f}',16);text(d,(left+width-42,1031),f'{DURATION:g} s',16)
        text(d,(20,1056),'Original articulated MuJoCo simulation | Blue: focal robot | Orange rings: empirical 90% position bands | Colored lines: conditional forecasts',16)
        writer.append_data(np.array(canvas))
        if index in (80,length-1):canvas.save(target.with_suffix('.png') if index==80 else target.with_name(target.stem+'_final.png'))
        if index%300==0:print(name,index,flush=True)
    writer.close()
    for stream in streams:stream.close()
    return {'video':str(target.relative_to(OUT)).replace('\\','/'),'frames':length,'fps':10,'seed':seed,'methods':[a,b],'source_videos':[str(p.relative_to(ROOT)).replace('\\','/') for p in (ma,mb)]}

